﻿namespace EuropeTrackX.ViewModels
{
    public class ReportViewModel
    {
        public DateTime start_date { get; set; }
        public DateTime end_date { get; set; }
    }
}

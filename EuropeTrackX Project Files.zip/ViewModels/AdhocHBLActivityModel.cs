﻿namespace EuropeTrackX.ViewModels
{
    public class AdhocHBLActivityModel
    {
        public string Id { get; set; } = Guid.NewGuid().ToString();
        public string AdhocCountryId { get; set; } = null!;
        public string AdhocHBLNumber { get; set; } = null!;
        public string AdhocBooking { get; set; } = null!;
        public string? AdhocFileNumber { get; set; } = null;
        public string? AdhocContainer { get; set; } = null;
        public DateTime EnterDate { get; set; }
        public bool? IsActive { get; set; } = true;
        public bool IsDelete { get; set; } = false;
        public List<AdhocHBLActivityLogItem> AdhocHBLActivities { get; set; }
    }

    public class AdhocHBLActivityLogItem
    {
        public string Id { get; set; } = Guid.NewGuid().ToString();

        public string ActivityId { get; set; }

        public string StatusId { get; set; }

        public string? Comment { get; set; }

        public string? UserId { get; set; } = null!;

        public DateTime? StartDate { get; set; }

        public DateTime? EndDate { get; set; }
    }
}

﻿using System.ComponentModel.DataAnnotations;

namespace EuropeTrackX.ViewModels
{
	public class LoginViewModel
	{
		[Required]
		
		public string CitrixId { get; set; }

		[Required]
		[DataType(DataType.Password)]
		public string Password { get; set; }
	}
}

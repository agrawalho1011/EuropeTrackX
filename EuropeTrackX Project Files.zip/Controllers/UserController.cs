﻿using EuropeTrackX.DataModel;
using EuropeTrackX.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;
using System.Linq.Dynamic.Core;
using Microsoft.AspNetCore.Authorization;

namespace EuropeTrackX.Controllers
{
    [Authorize]
    public class UserController : Controller
    {
        ApplicationDBContext _context;
        private readonly IHttpContextAccessor _httpContextAccessor;
        public UserController(ApplicationDBContext context, IHttpContextAccessor httpContextAccessor)
        {
            _context = context;
            _httpContextAccessor = httpContextAccessor;
        }
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Files()
        {
            ViewBag.ActivityMaster = _context.ActivityMaster.ToList();
            ViewBag.Countries = _context.CountryMaster.ToList();
            return View();

        }

        [HttpPost]
        public IActionResult AddActivity(FileActivityLogModel fileActivity)
        {
            string Msg = "";
            if (ModelState.IsValid)
            {
                var fileactivityIsexits = _context.FileActivityLog.Where(x=>x.ActivityId==fileActivity.ActivityId && x.FileId==fileActivity.FileId).FirstOrDefault();
                
                if (fileactivityIsexits==null)
                {
                    _context.FileActivityLog.Add(new FileActivityLog
                    {
                        Id = fileActivity.Id,
                        FileId = fileActivity.FileId,
                        ActivityId = fileActivity.ActivityId,
                        StatusId = fileActivity.StatusId,
                        Comment = fileActivity.Comment,
                        UserId = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier),
                        StartDate = DateTime.UtcNow,
                        EndDate = DateTime.UtcNow,
                    });
                    Msg="";
                    _context.SaveChanges();

                    return Json(fileActivity.FileId);
                }
                else
                {

                    _context.FileAcitivityLogHistory.Add(new FileAcitivityLogHistory
                    {
                        FileLogId= fileactivityIsexits.Id,
                        ActivityId = fileactivityIsexits.ActivityId,
                        StatusId = fileactivityIsexits.StatusId,
                        Comment = fileactivityIsexits.Comment,
                        UserId = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier),
                        StartDate = DateTime.UtcNow,
                        EndDate = DateTime.UtcNow,
                    });

                    fileactivityIsexits.StatusId=fileActivity.StatusId;
                    fileactivityIsexits.Comment=fileActivity.Comment;
                    fileactivityIsexits.StartDate = DateTime.UtcNow;
                    fileactivityIsexits.EndDate = DateTime.UtcNow;
                    fileactivityIsexits.UserId = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
                   
                    Msg ="Status Update Successfully.";
                    _context.SaveChanges();

                    return Json(Msg);
                }
              
            }
            else
            {
                return Json("Something went wrong");
            }
        }

        [HttpGet]
        public IActionResult FileActivity(string Id)
        {
            ViewData["fileId"] = Id;
            ViewData["fileDtls"] = _context.FileMaster.Where(x => x.Id == Id).Include(x => x.Country).FirstOrDefault();

            ViewData["FileActivityList"] = _context.FileActivityLog.Where(x => x.FileId == Id)
                                                        .Include(x => x.Activity).Include(x => x.Status).Include(x => x.ApplicationUser)
                                                        .Select(x => new FileActivityLogModel
                                                        {
                                                            Id = x.Id,
                                                            FileId = x.File.Id,
                                                            ActivityId = x.ActivityId,
                                                            ActivityName = x.Activity.NameOfActivity,
                                                            StatusId = x.StatusId,
                                                            StatusName = x.Status.Status,
                                                            UserId = x.UserId,
                                                            UserName = x.ApplicationUser.UserName,
                                                            Comment = x.Comment,
                                                            StartDate = x.StartDate,
                                                            EndDate = x.EndDate,
                                                        }).ToList();
            ViewBag.Activity = _context.ActivityMaster.Where(x => x.ActivityType == "File" && x.Source == "Upload").ToList();
            ViewBag.Status = _context.StatusMaster.ToList();

            return PartialView();
        }

        [HttpGet]
        public IActionResult HBL(string fileNumber)
        {
            IEnumerable<HBLUserViewModel> data = null;

            if (fileNumber != null)
            {
                data = _context.HBLMaster.Include(x => x.File).Where(x => x.File.FileNumber == fileNumber).Select(x =>
                new HBLUserViewModel
                {
                    Id = x.Id,
                    FileNo = x.File.FileNumber,
                    BookingNo = x.Booking,
                    HBL_No = x.HBLNumber,
                    CountryName = x.File.Country.CountryName,
                    CustomerName = x.CustomerName,
                   
                });
            }
            else
            {
                data = _context.HBLMaster.Include(x => x.File).Select(x =>
                new HBLUserViewModel
                {
                    Id = x.Id,
                    FileNo = x.File.FileNumber,
                    BookingNo = x.Booking,
                    HBL_No = x.HBLNumber,
                    CountryName = x.File.Country.CountryName,
                    CustomerName = x.CustomerName,
                });
            }

            ViewBag.Activity = _context.ActivityMaster.Where(x => x.ActivityType == "HBL" && x.Source == "Upload").ToList();
            ViewBag.Status = _context.StatusMaster.ToList();

            return View(data);
        }

        [HttpPost]
        public IActionResult GetFiles(DataTableAjaxPostModel model, string country, string fileNumber, string status,string activity)
        {
            var draw = model.draw;
            var sortColumn = string.IsNullOrEmpty(model.columns[model.order[0].column].data) ? "id" : model.columns[model.order[0].column].data;
            var sortColumnDirection = model.order[0].dir;
            var searchValue = model.search.value;
            int pageSize = model.length.HasValue ? model.length.Value : 100;
            int skip = model.start.HasValue ? model.start.Value : 0;
            var role = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.Role);

            ViewBag.Status = _context.StatusMaster.ToList();
            
            if (role!="User")
            {  // Get the data for the DataTable
               //var data = _context.FileMaster.Include(x => x.Country).Include(x => x.FileActivityLogs).AsQueryable();
                var data = (from fa in _context.FileActivityLog
                            join fm in _context.FileMaster
                            on fa.FileId equals fm.Id
                            join am in _context.ActivityMaster
                            on fa.ActivityId equals am.Id
                            join um in _context.Users
                            on fa.UserId equals um.Id
                            select new FileDashModel
                            {
                                Id=fm.Id,
                                CountryName=fm.Country.CountryName,
                                DraftCutOff=fm.DraftCutoff,
                                ETD=fm.Etd,
                                FileNumber=fm.FileNumber,
                                ActivityId=am.NameOfActivity,
                                StatusId=fa.Status.Status,
                                Comment=fa.Comment,
                                UserId=um.UserName

                            });

                //var data = _context.FileActivityLog
                //      .Include(x => x.File)
                //      .Include(x => x.Activity)
                //      .Include(x => x.Status)
                //      .Include(x => x.ApplicationUser)                     
                //      .Select(x => new FileDashModel
                //      {
                //          Id = x.Activity.Id,
                //          CountryName = x.File.Country.CountryName,
                //          DraftCutOff = x.File.DraftCutoff,
                //          ETD = x.File.Etd,
                //          FileNumber = x.File.FileNumber,
                //          ActivityId = x.Activity.NameOfActivity,
                //          StatusId = x.Status.Status,
                //          Comment = x.Comment,
                //          UserId = x.ApplicationUser.UserName
                //      });


                if (!string.IsNullOrEmpty(country) && country != "-- Select Country --")
                {
                    data = data.Where(x => x.CountryName.Contains(country));
                }
                if (!string.IsNullOrEmpty(fileNumber))
                {
                    data = data.Where(x => x.FileNumber.Contains(fileNumber));
                }
                if (!string.IsNullOrEmpty(status))
                {
                    data = data.Where(x => x.StatusId.Contains(status));
                }
                if (!string.IsNullOrEmpty(activity))
                {
                    data = data.Where(x => x.ActivityId.Contains(activity));
                }

                IEnumerable<FileDashModel> files = data.Select(
                    x => new FileDashModel
                    {
                        Id=x.Id,
                        CountryName=x.CountryName,
                        FileNumber=x.FileNumber,
                        ETD=x.ETD,
                        DraftCutOff=x.DraftCutOff,
                        ActivityId=x.ActivityId,
                        UserId=x.UserId,
                        StatusId=x.StatusId,
                        Comment=x.Comment,
                    }).OrderBy(sortColumn + " " + sortColumnDirection)
                   .Skip(skip)
                   .Take(pageSize).AsQueryable().ToList();
                    return Json(new
                    {
                        draw = model.draw,
                        recordsTotal = files.Count(),
                        recordsFiltered = files.Count(),
                        data = files
                    });
            }
            else
            {
                // Get the data for the DataTable
                //var data = _context.FileMaster.Include(x => x.Country).Include(x => x.FileActivityLogs).AsQueryable();
                var data = _context.FileActivityLog
                          .Include(x => x.File)
                          .Include(x => x.Activity)
                          .Include(x => x.Status)
                          .Include(x => x.ApplicationUser)
                          .Where(x => x.ApplicationUser.UserName == User.Identity.Name)
                          .Select(x => new FileDashModel
                          {
                              Id = x.Activity.Id,
                              CountryName = x.File.Country.CountryName,
                              DraftCutOff = x.File.DraftCutoff,
                              ETD = x.File.Etd,
                              FileNumber = x.File.FileNumber,
                              ActivityId = x.Activity.NameOfActivity,
                              StatusId = x.Status.Status,
                              Comment = x.Comment,
                              UserId = x.ApplicationUser.UserName
                          });
                          



                    //var data = (from fa in _context.FileActivityLog
                    //            join fm in _context.FileMaster
                    //            on fa.FileId equals fm.Id
                    //            join am in _context.ActivityMaster
                    //            on fa.ActivityId equals am.Id
                    //            join um in _context.Users
                    //            on fa.UserId equals um.Id
                    //            where (um.UserName==User.Identity.Name)
                    //            select new FileDashModel
                    //            {
                    //                Id=fm.Id,
                    //                CountryName=fm.Country.CountryName,
                    //                DraftCutOff=fm.DraftCutoff,
                    //                ETD=fm.Etd,
                    //                FileNumber=fm.FileNumber,
                    //                ActivityId=am.NameOfActivity,
                    //                StatusId=fa.Status.Status,
                    //                Comment=fa.Comment,
                    //                UserId=um.UserName

                    //            });
                        if (!string.IsNullOrEmpty(country) && country != "-- Select Country --")
                        {
                            data = data.Where(x => x.CountryName.Contains(country));
                        }
                        if (!string.IsNullOrEmpty(fileNumber))
                        {
                            data = data.Where(x => x.FileNumber.Contains(fileNumber));
                        }
                        if (!string.IsNullOrEmpty(status))
                        {
                            data = data.Where(x => x.StatusId.Contains(status));
                        }
                        if (!string.IsNullOrEmpty(activity))
                        {
                            data = data.Where(x => x.ActivityId.Contains(activity));
                        }

                        IEnumerable<FileDashModel> files = data.Select(
                            x => new FileDashModel
                            {
                                Id=x.Id,
                                CountryName=x.CountryName,
                                FileNumber=x.FileNumber,
                                ETD=x.ETD,
                                DraftCutOff=x.DraftCutOff,
                                ActivityId=x.ActivityId,
                                UserId=x.UserId,
                                StatusId=x.StatusId,
                                Comment=x.Comment,
                            }).OrderBy(sortColumn + " " + sortColumnDirection)
                           .Skip(skip)
                           .Take(pageSize).AsQueryable().ToList();
                            return Json(new
                            {
                                draw = model.draw,
                                recordsTotal = files.Count(),
                                recordsFiltered = files.Count(),
                                data = files
                            });
            }

            // Return the data in the format required by DataTables
           
        }


        public IActionResult Adhoc()
        {
            //ViewBag.ActivityMaster = _context.ActivityMaster.ToList();
            ViewBag.Countries = _context.CountryMaster.ToList();
            return View();

        }

        [HttpGet]
        public IActionResult AdhocFileActivity()
        {
            //ViewData["fileId"] = Id;
            //ViewData["fileDtls"] = _context.FileMaster.Where(x => x.Id == Id).Include(x => x.Country).FirstOrDefault();

            //ViewData["FileActivityList"] = _context.FileActivityLog.Where(x => x.FileId == Id)
            //                                            .Include(x => x.Activity).Include(x => x.Status).Include(x => x.ApplicationUser)
            //                                            .Select(x => new FileActivityLogModel
            //                                            {
            //                                                Id = x.Id,
            //                                                FileId = x.File.Id,
            //                                                ActivityId = x.ActivityId,
            //                                                ActivityName = x.Activity.NameOfActivity,
            //                                                StatusId = x.StatusId,
            //                                                StatusName = x.Status.Status,
            //                                                UserId = x.UserId,
            //                                                UserName = x.ApplicationUser.UserName,
            //                                                Comment = x.Comment,
            //                                                StartDate = x.StartDate,
            //                                                EndDate = x.EndDate,
            //                                            }).ToList();

            ViewBag.Countries = _context.CountryMaster.ToList();
            ViewBag.Activity = _context.ActivityMaster.Where(x => x.ActivityType == "File" && x.Source == "Adhoc").ToList();
            ViewBag.Status = _context.StatusMaster.ToList();

            return PartialView();
        }


        [HttpPost]
        public IActionResult AdhocFileActivity(AdhocFileActivityModel adhocfileActivity)
        {
            if (ModelState.IsValid)
            {
                AdhocFile adhocfile = _context.AdhocFile.Where(x => x.AdhocFileNumber == adhocfileActivity.AdhocFileNumber.ToUpper().Trim()).FirstOrDefault();

                if (adhocfile == null)
                {
                    adhocfile = new AdhocFile
                    {
                        Id = adhocfileActivity.Id,
                        CountryId = adhocfileActivity.CountryId,
                        AdhocFileNumber = adhocfileActivity.AdhocFileNumber.ToUpper().Trim(),
                        AdhocContainer = adhocfileActivity.AdhocContainer.ToUpper().Trim(),
                        EnterDate = DateTime.UtcNow,
                        IsActive = true,
                        IsDelete = false
                    };
                    _context.AdhocFile.Add(adhocfile);
                }


                foreach (AdhocFileActivityLogItem log in adhocfileActivity.AdhocFileActivities)
                {
                    _context.AdhocFileActivityLog.Add(new AdhocFileActivityLog
                    {
                        Id = log.Id,
                        AdhocFileId = adhocfile.Id,
                        ActivityId = log.ActivityId,
                        StatusId = log.StatusId,
                        Comment = log.Comment,
                        UserId = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier),
                        StartDate = DateTime.UtcNow,
                        EndDate = DateTime.UtcNow,
                    });

                }
                _context.SaveChanges();

                return Json(adhocfileActivity.Id);
            }
            else
            {
                return Json("Something went wrong");
            }
        }


        [HttpGet]
        public IActionResult AdhocHBLActivity()
        {
            ViewBag.Countries = _context.CountryMaster.ToList();
            ViewBag.Activity = _context.ActivityMaster.Where(x => x.ActivityType == "HBL" && x.Source == "Adhoc").ToList();
            ViewBag.Status = _context.StatusMaster.ToList();

            return PartialView();
        }

        [HttpPost]
        public IActionResult AdhocHBLActivity(AdhocHBLActivityModel adhocHBLActivity)
        {
            if (ModelState.IsValid)
            {
                AdhocHBL adhochbl = _context.AdhocHBL.Where(x => x.AdhocBooking == adhocHBLActivity.AdhocBooking.ToUpper().Trim() || x.AdhocHBLNumber == adhocHBLActivity.AdhocHBLNumber.ToUpper().Trim()).FirstOrDefault();

                if (adhochbl == null)
                {
                    adhochbl = new AdhocHBL
                    {
                        Id = adhocHBLActivity.Id,
                        AdhocCountryId = adhocHBLActivity.AdhocCountryId,
                        AdhocBooking = adhocHBLActivity.AdhocBooking.ToUpper().Trim(),
                        AdhocHBLNumber = adhocHBLActivity.AdhocHBLNumber.ToUpper().Trim(),
                        //AdhocFileNumber = adhocHBLActivity.AdhocFileNumber,
                        //AdhocContainer = adhocHBLActivity.AdhocContainer,
                        EnterDate = DateTime.UtcNow,
                        IsActive = true,
                        IsDelete = false

                    };
                    _context.AdhocHBL.Add(adhochbl);
                }

                foreach (AdhocHBLActivityLogItem log in adhocHBLActivity.AdhocHBLActivities)
                {
                    _context.AdhocHBLActivityLog.Add(new AdhocHBLActivityLog
                    {
                        Id = log.Id,
                        AdhocHBLId = adhochbl.Id,
                        ActivityId = log.ActivityId,
                        StatusId = log.StatusId,
                        Comment = log.Comment,
                        UserId = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier),
                        StartDate = DateTime.UtcNow,
                        EndDate = DateTime.UtcNow,
                    });

                }
                _context.SaveChanges();

                return Json(adhocHBLActivity.Id);
            }
            else
            {
                return Json("Something went wrong");
            }
        }


        [HttpPost]
        //public IActionResult GetAdhocFiles(DataTableAjaxPostModel model, string country, string fileNumber, string container)
        public IActionResult GetAdhocFiles(DataTableAjaxPostModel model, string country, string fileNumber, string container)
        {
            var draw = model.draw;
            var sortColumn = string.IsNullOrEmpty(model.columns[model.order[0].column].data) ? "id" : model.columns[model.order[0].column].data;
            var sortColumnDirection = model.order[0].dir;
            var searchValue = model.search.value;
            int pageSize = model.length.HasValue ? model.length.Value : 10;
            int skip = model.start.HasValue ? model.start.Value : 0;

            // Get the data for the DataTable
            var data = _context.AdhocFileActivityLog
            .Join(_context.AdhocFile, fileActivity => fileActivity.AdhocFileId, fileMaster => fileMaster.Id, (fileActivity, fileMaster) => new { fileActivity, fileMaster })
            .Join(_context.ActivityMaster, activityJoin => activityJoin.fileActivity.ActivityId, activityMaster => activityMaster.Id, (activityJoin, activityMaster) => new { activityJoin, activityMaster })
            .Join(_context.StatusMaster, statusjoin => statusjoin.activityJoin.fileActivity.StatusId, statusMaster => statusMaster.Id, (statusjoin, statusMaster) => new { statusjoin, statusMaster })
            .Join(_context.CountryMaster, countryjoin => countryjoin.statusjoin.activityJoin.fileMaster.CountryId, countryMaster => countryMaster.Id, (countryjoin, countryMaster) => new { countryjoin, countryMaster })
            .Join(_context.Users, userjoin => userjoin.countryjoin.statusjoin.activityJoin.fileActivity.ApplicationUser.Id, User => User.Id, (userjoin, User) => new
            AdhocFileDashModel
            {

                Id = userjoin.countryjoin.statusjoin.activityJoin.fileMaster.Id,
                CountryName = userjoin.countryMaster.CountryName,
                FileNumber = userjoin.countryjoin.statusjoin.activityJoin.fileMaster.AdhocFileNumber,
                Container = userjoin.countryjoin.statusjoin.activityJoin.fileMaster.AdhocContainer,
                LastActivityPerformed = userjoin.countryjoin.statusjoin.activityMaster.NameOfActivity,
                LastActivityStatus = userjoin.countryjoin.statusMaster.Status,
                LastProcessedDate = userjoin.countryjoin.statusjoin.activityJoin.fileActivity.EndDate,
                LastFileHandler = User.UserName
                //Comment = countryjoin.statusjoin.activityJoin.fileActivity.Comment,
            })
            .GroupBy(x => x.FileNumber)
            .Select(group => group.OrderByDescending(x => x.LastProcessedDate).First()).ToList().AsQueryable();

            if (!string.IsNullOrEmpty(country) && country != "-- Select Country --")
            {
                data = data.Where(x => x.CountryName.Contains(country));
            }
            if (!string.IsNullOrEmpty(fileNumber))
            {
                data = data.Where(x => x.FileNumber.Contains(fileNumber));
            }
            if (!string.IsNullOrEmpty(container))
            {
                data = data.Where(x => x.Container.Contains(container));
            }
            int filteredrecords = data.Count();

            List<AdhocFileDashModel> files = data.Select(
                x => new AdhocFileDashModel
                {
                    Id = x.Id,
                    CountryName = x.CountryName,
                    FileNumber = x.FileNumber,
                    Container = x.Container,
                    LastActivityPerformed = x.LastActivityPerformed,
                    LastActivityStatus = x.LastActivityStatus,
                    LastProcessedDate = x.LastProcessedDate,
                }).OrderBy(sortColumn + " " + sortColumnDirection)
               .Skip(skip)
               .Take(pageSize == -1 ? 10 : pageSize).AsQueryable().ToList();

            
            // Return the data in the format required by DataTables
            return Json(new
            {
                draw = model.draw,
                recordsTotal = data.Count(),
                recordsFiltered = filteredrecords,
                data = files
            });

           
        }

        [HttpPost]
        //public IActionResult GetAdhocHBLs(DataTableAjaxPostModel model, string country, string fileNumber, string container)
        public IActionResult GetAdhocHBLs(DataTableAjaxPostModel model, string country, string booking, string hblNumber)
        {
            var draw = model.draw;
            var sortColumn = string.IsNullOrEmpty(model.columns[model.order[0].column].data) ? "id" : model.columns[model.order[0].column].data;
            var sortColumnDirection = model.order[0].dir;
            var searchValue = model.search.value;
            int pageSize = model.length.HasValue ? model.length.Value : 10;
            int skip = model.start.HasValue ? model.start.Value : 0;

            // Get the data for the DataTable
            var data = _context.AdhocHBLActivityLog
            .Join(_context.AdhocHBL, hblActivity => hblActivity.AdhocHBLId, hblMaster => hblMaster.Id, (hblActivity, hblMaster) => new { hblActivity, hblMaster })
            .Join(_context.ActivityMaster, activityJoin => activityJoin.hblActivity.ActivityId, activityMaster => activityMaster.Id, (activityJoin, activityMaster) => new { activityJoin, activityMaster })
            .Join(_context.StatusMaster, statusjoin => statusjoin.activityJoin.hblActivity.StatusId, statusMaster => statusMaster.Id, (statusjoin, statusMaster) => new { statusjoin, statusMaster })
            .Join(_context.CountryMaster, countryjoin => countryjoin.statusjoin.activityJoin.hblMaster.AdhocCountryId, countryMaster => countryMaster.Id, (countryjoin, countryMaster) => new { countryjoin, countryMaster })
            .Join(_context.Users, userjoin => userjoin.countryjoin.statusjoin.activityJoin.hblActivity.ApplicationUser.Id, User => User.Id, (userjoin, User) => new
            AdhocHBLDashModel
            {

                Id = userjoin.countryjoin.statusjoin.activityJoin.hblMaster.Id,
                CountryName = userjoin.countryMaster.CountryName,
                HBLNo = userjoin.countryjoin.statusjoin.activityJoin.hblMaster.AdhocHBLNumber,
                BookingNo = userjoin.countryjoin.statusjoin.activityJoin.hblMaster.AdhocBooking,
                LastActivityPerformed = userjoin.countryjoin.statusjoin.activityMaster.NameOfActivity,
                LastActivityStatus = userjoin.countryjoin.statusMaster.Status,
                LastProcessedDate = userjoin.countryjoin.statusjoin.activityJoin.hblActivity.EndDate,
                LastHBLHandler = User.UserName
                //Comment = countryjoin.statusjoin.activityJoin.hblActivity.Comment,
            })
            .GroupBy(x => x.HBLNo)
            .Select(group => group.OrderByDescending(x => x.LastProcessedDate).First()).ToList().AsQueryable();

            if (!string.IsNullOrEmpty(country) && country != "--Select--")
            {
                data = data.Where(x => x.CountryName.Contains(country));
            }
            if (!string.IsNullOrEmpty(booking))
            {
                data = data.Where(x => x.BookingNo.Contains(booking));
            }
            if (!string.IsNullOrEmpty(hblNumber))
            {
                data = data.Where(x => x.HBLNo.Contains(hblNumber));
            }

            int filteredrecords = data.Count();

            List<AdhocHBLDashModel> files = data.Select(
                x => new AdhocHBLDashModel
                {
                    Id = x.Id,
                    CountryName = x.CountryName,
                    BookingNo = x.BookingNo,
                    HBLNo = x.HBLNo,
                    LastActivityPerformed = x.LastActivityPerformed,
                    LastActivityStatus = x.LastActivityStatus,
                    LastProcessedDate = x.LastProcessedDate,
                }).OrderBy(sortColumn + " " + sortColumnDirection)
               .Skip(skip)
               .Take(pageSize == -1 ? 10 : pageSize).AsQueryable().ToList(); 

            // Return the data in the format required by DataTables
            return Json(new
            {
                draw = model.draw,
                recordsTotal = data.Count(),
                recordsFiltered = filteredrecords,
                data = files
            });
        }

        [HttpGet]
        public IActionResult GetFileActivityData(string Id)
        {
            var adhocFile = _context.AdhocFileActivityLog.Where(fileActivity => fileActivity.AdhocFile.Id == Id)
            .Join(_context.ActivityMaster, activityJoin => activityJoin.ActivityId, activityMaster => activityMaster.Id, (activityJoin, activityMaster) => new { activityJoin, activityMaster })
            .Join(_context.StatusMaster, statusjoin => statusjoin.activityJoin.StatusId, statusMaster => statusMaster.Id, (statusjoin, statusMaster) => new { statusjoin, statusMaster })
            .Join(_context.Users, userjoin => userjoin.statusjoin.activityJoin.ApplicationUser.Id, User => User.Id, (userjoin, User) => new
            {

                Id = userjoin.statusjoin.activityMaster.Id,
                ActivityName = userjoin.statusjoin.activityMaster.NameOfActivity,
                Status = userjoin.statusMaster.Status,
                ProcessedDate = userjoin.statusjoin.activityJoin.EndDate,
                User = User.UserName,
                Comment = userjoin.statusjoin.activityJoin.Comment==null?"":userjoin.statusjoin.activityJoin.Comment,
            }).OrderByDescending(x=>x.ProcessedDate).ToList().AsQueryable();

            return Json(new { adhocFile });
        }

        [HttpGet]
        public IActionResult GetHBLActivityData(string Id)
        {
            var adhocHBL = _context.AdhocHBLActivityLog.Where(fileActivity => fileActivity.AdhocHBLId == Id)
            .Join(_context.ActivityMaster, activityJoin => activityJoin.ActivityId, activityMaster => activityMaster.Id, (activityJoin, activityMaster) => new { activityJoin, activityMaster })
            .Join(_context.StatusMaster, statusjoin => statusjoin.activityJoin.StatusId, statusMaster => statusMaster.Id, (statusjoin, statusMaster) => new { statusjoin, statusMaster })
            .Join(_context.Users, userjoin => userjoin.statusjoin.activityJoin.ApplicationUser.Id, User => User.Id, (userjoin, User) => new
            {

                Id = userjoin.statusjoin.activityMaster.Id,
                ActivityName = userjoin.statusjoin.activityMaster.NameOfActivity,
                Status = userjoin.statusMaster.Status,
                ProcessedDate = userjoin.statusjoin.activityJoin.EndDate,
                User = User.UserName,
                Comment = userjoin.statusjoin.activityJoin.Comment == null ? "" : userjoin.statusjoin.activityJoin.Comment,
            }).OrderByDescending(x => x.ProcessedDate).ToList().AsQueryable();


            return Json(new { adhocHBL });
        }

        [HttpGet]
        public IActionResult GetHBLActivity(string Id)
        {
                                var HBL = _context.HBLActivityLog.Where(x=>x.HBLId==Id)
                                .Include(activity => activity.Activity)
                                .Include(status => status.Status)
                                .Include(user => user.ApplicationUser)
                                .Select(x => new {
                                    Id = x.Activity.Id,
                                    ActivityName =x.Activity.NameOfActivity, 
                                    Status = x.Status.Status,
                                    ProcessedDate = x.EndDate,
                                    User = x.ApplicationUser.UserName,
                                    Comment = x.Comment == null ? "" : x.Comment,
                                })
                               .OrderByDescending(x => x.ProcessedDate).ToList().AsQueryable()
                               .ToList();


            //var HBL = _context.HBLActivityLog.Where(fileActivity => fileActivity.HBLId == Id)
            //.Join(_context.ActivityMaster, activityJoin => activityJoin.ActivityId, activityMaster => activityMaster.Id, (activityJoin, activityMaster) => new { activityJoin, activityMaster })
            //.Join(_context.StatusMaster, statusjoin => statusjoin.activityJoin.StatusId, statusMaster => statusMaster.Id, (statusjoin, statusMaster) => new { statusjoin, statusMaster })
            //.Join(_context.Users, userjoin => userjoin.statusjoin.activityJoin.ApplicationUser.Id, User => User.Id, (userjoin, User) => new
            //{

            //    Id = userjoin.statusjoin.activityMaster.Id,
            //    ActivityName = userjoin.statusjoin.activityMaster.NameOfActivity,
            //    Status = userjoin.statusMaster.Status,
            //    ProcessedDate = userjoin.statusjoin.activityJoin.EndDate,
            //    User = User.UserName,
            //    Comment = userjoin.statusjoin.activityJoin.Comment == null ? "": userjoin.statusjoin.activityJoin.Comment,
            //}).OrderByDescending(x => x.ProcessedDate).ToList().AsQueryable();


            return Json(new { HBL });
        }

        [HttpPost]
        public JsonResult AddHblActivities(HBLActivityLogViewModel model)
        {
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);

            var found = _context.HBLActivityLog.Where(x=>x.HBLId==model.HblId && x.ActivityId==model.ActivityId).FirstOrDefault();
            
            if (ModelState.IsValid)
            {
                if (found==null)
                {
                    _context.HBLActivityLog.Add(new HBLActivityLog
                    {
                        HBLId = model.HblId,
                        ActivityId = model.ActivityId,
                        StatusId = model.StatusId,
                        UserId = userid,
                        StartDate = DateTime.Parse(model.StartDate.ToString()),
                        EndDate = DateTime.UtcNow,
                        Comment = model.Comment

                    });

                }
                else
                {
                    var hbllog = _context.HBLActivityLog.FirstOrDefault(x => x.HBLId == model.HblId);

                    if (hbllog != null)
                    {
                        hbllog.ActivityId = model.ActivityId;
                        hbllog.StatusId = model.StatusId;
                        hbllog.UserId = userid;
                        hbllog.StartDate = DateTime.Parse(model.StartDate.ToString());
                        hbllog.EndDate = DateTime.UtcNow;
                        hbllog.Comment = model.Comment;

                        
                    }
                }
                
                _context.SaveChanges();
                return Json("Success");
            }
            else
            {
                return Json("Error while processing the request");
            }
            
        }

        [HttpGet]
        public IActionResult CreateFile()
        {
            ViewBag.Countries = _context.CountryMaster.ToList();
            ViewBag.Activity = _context.ActivityMaster.Where(x => x.ActivityType == "File" && x.Source == "Upload").ToList();
            ViewBag.Status = _context.StatusMaster.ToList();

            return PartialView();
        }
        [HttpPost]
        public IActionResult AddFileNewActivity(FileAddActivityLogModel file)
        {
            if (ModelState.IsValid)
            {
                FileMaster fileMaster = _context.FileMaster.Where(x => x.FileNumber == file.FileNumber.ToUpper().Trim()).FirstOrDefault();

                if (fileMaster == null)
                {
                    fileMaster = new FileMaster
                    {
                        Id = file.Id,
                        CountryId = file.CountryId,
                        FileNumber = file.FileNumber.ToUpper().Trim(),
                        Etd = file.ETD,
                        DraftCutoff = file.DraftCutOff,
                        EnterDate = DateTime.UtcNow,
                        IsActive = true,
                        IsDelete = false
                    };
                    _context.FileMaster.Add(fileMaster);
                }

                foreach (FileActivityLogItem log in file.FileActivities)
                {
                    _context.FileActivityLog.Add(new FileActivityLog
                    {
                        Id = log.Id,
                        FileId = fileMaster.Id,
                        ActivityId = log.ActivityId,
                        StatusId = log.StatusId,
                        Comment = log.Comment,
                        UserId = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier),
                        StartDate = DateTime.UtcNow,
                        EndDate = DateTime.UtcNow,
                    });
                }

                _context.SaveChanges();

                return Json(file.Id);
            }
            else
            {
                return Json("Something went wrong");

            }
        }

        [HttpGet]
        public IActionResult CreateHBL()
        {
            ViewBag.Countries = _context.CountryMaster.ToList();
            ViewBag.Activity = _context.ActivityMaster.Where(x => x.ActivityType == "HBL" && x.Source == "Upload").ToList();
            ViewBag.Status = _context.StatusMaster.ToList();

            return PartialView();
        }


        [HttpPost]
        public IActionResult AddNewHBLActivity(HBLUserViewModel hbl)
        {
            string Msg = "";
            if (ModelState.IsValid)
            {
                var file = _context.FileMaster.Where(x => x.FileNumber == hbl.FileNo.ToUpper().Trim()).FirstOrDefault();

                if (file==null)
                {
                    Msg="File does not exist first insert file";
                }
                else
                {
                    HBLMaster hblMaster = _context.HBLMaster.Where(x => x.HBLNumber == hbl.HBL_No.ToUpper().Trim()).FirstOrDefault();

                    if (hblMaster == null)
                    {
                        hblMaster = new HBLMaster
                        {
                            Id = hbl.Id,
                            HBLNumber = hbl.HBL_No,
                            FileId = _context.FileMaster.Where(x => x.FileNumber == hbl.FileNo.ToUpper().Trim()).Select(x => x.Id).FirstOrDefault(),
                            Container = hbl.Container,
                            Booking = hbl.BookingNo,
                            CustomerName = hbl.CustomerName,
                            EnterDate = DateTime.UtcNow,
                            IsActive = true,
                            IsDelete = false
                        };
                        _context.HBLMaster.Add(hblMaster);
                        _context.SaveChanges();
                        Msg="HBL Inserted Successfully..!!";
                    }
                    else
                    {
                        Msg="HBL no is already added";
                    }

                    //foreach (HBLActivityLogs log in hbl.HBLActivities)
                    //{
                    //    _context.HBLActivityLog.Add(new HBLActivityLog
                    //    {
                    //        Id = log.Id,
                    //        HBLId = hbl.Id,
                    //        ActivityId = log.ActivityId,
                    //        StatusId = log.StatusId,
                    //        Comment = log.Comment,
                    //        UserId = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier),
                    //        StartDate = DateTime.UtcNow,
                    //        EndDate = DateTime.UtcNow,
                    //    });
                    //}
                   
                }
                return Json(Msg);

            }
            else
            {
                return Json("Error while processing the request");

            }
        }

        [HttpGet]
        public IActionResult InsertFile()
        {
            ViewBag.Countries = _context.CountryMaster.ToList();
            ViewBag.Activity = _context.ActivityMaster.Where(x => x.ActivityType == "File" && x.Source == "Upload").ToList();
            ViewBag.Status = _context.StatusMaster.ToList();

            return PartialView();
        }
        public IActionResult InsertNewFile(FileInsertModel file)
        {
            if (ModelState.IsValid)
            {
                FileMaster fileMaster = _context.FileMaster.Where(x => x.FileNumber == file.FileNumber.ToUpper().Trim()).FirstOrDefault();

                if (fileMaster == null)
                {
                    fileMaster = new FileMaster
                    {
                        Id = file.Id,
                        CountryId = file.CountryId,
                        FileNumber = file.FileNumber.ToUpper().Trim(),
                        Etd = file.ETD,
                        DraftCutoff = file.DraftCutOff,
                        EnterDate = DateTime.UtcNow,
                        IsActive = true,
                        IsDelete = false
                    };
                    _context.FileMaster.Add(fileMaster);
                }
                _context.SaveChanges();

                return Json(file.Id);
            }
            else
            {
                return Json("Something went wrong");

            }
        }
      
        public IActionResult FileQuery()
        {
            ViewBag.StatusMaster = _context.StatusMaster.OrderBy(x=>x.Status).ToList();
            ViewBag.ActivityMaster = _context.ActivityMaster.OrderBy(x=>x.NameOfActivity).Where(x=>x.ActivityType=="File"&&x.Source=="Upload").ToList();
            ViewBag.Countries = _context.CountryMaster.OrderBy(x=>x.CountryName).ToList();
            return View();

        }

        [HttpGet]
        public IActionResult GetfileData(string fileNumber)
        {
            var hbl = _context.HBLMaster.Where(x => x.File.FileNumber == fileNumber).ToList();
            var file = _context.FileMaster.Where(x => x.FileNumber==fileNumber).Select(x => new {x.Id }).FirstOrDefault();
            var sm = _context.StatusMaster.ToList();

            var fm = _context.FileActivityLog.Include(x => x.File).Include(x => x.Activity).Include(x => x.Status).Include(x => x.ApplicationUser).Where(x => x.FileId == file.Id).ToList();
            IQueryable<FileActivityLog> fileActivityLog = fm.AsQueryable();
            //foreach (var item in fm)
            //{
            //    fileActivityLog.Select(x => new FileActivityLog
            //    {
            //        ActivityId = _context.FileActivityLog.Where(x => x.Activity.Id == item.ActivityId).Select(x => x.Activity.NameOfActivity).FirstOrDefault(),
            //        StatusId = _context.FileActivityLog.Where(x => x.Status.Id == item.StatusId).Select(x => x.Status.Status).FirstOrDefault(),
            //        UserId = _context.FileActivityLog.Where(x => x.ApplicationUser.Id == item.UserId).Select(x => x.ApplicationUser.UserName).FirstOrDefault(),


            //    }).ToList();
            //}

            return Json(new { fm, hbl, sm });
        }

        [HttpGet]
        public IActionResult GetHblActivityData(string hblnumber)
        {
            var hblact = _context.HBLActivityLog.Include(x => x.Hbl).Include(x => x.Activity).Include(x => x.Status).Where(x => x.Hbl.HBLNumber == hblnumber).ToList();
            IQueryable<HBLActivityLog> hblActivityLog = hblact.AsQueryable();
            foreach (var item in hblact)
            {
                hblActivityLog.Select(x => new HBLActivityLog
                {
                    ActivityId = _context.HBLActivityLog.Where(x => x.Activity.Id == item.ActivityId).Select(x => x.Activity.NameOfActivity).FirstOrDefault(),
                    StatusId = _context.HBLActivityLog.Where(x => x.Status.Id == item.StatusId).Select(x => x.Status.Status).FirstOrDefault(),
                    UserId = _context.HBLActivityLog.Where(x => x.ApplicationUser.Id == item.UserId).Select(x => x.ApplicationUser.UserName).FirstOrDefault(),

                }).ToList();
            }
            return Json(hblact);
        }
        public IActionResult HBLQuery(string fileNumber)
        {
            ViewBag.ActivityMaster = _context.ActivityMaster.OrderBy(x => x.NameOfActivity).Where(x => x.ActivityType=="HBL"&&x.Source=="Upload").ToList();
            ViewBag.Countries = _context.CountryMaster.ToList();
            IEnumerable<HBLQueryActivity> data = null;
            var username = _httpContextAccessor.HttpContext.User.Identity.Name;
            var role = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.Role);
            if (fileNumber != null)
            {

                if (role!="User")
                {
                    data = (from fa in _context.HBLActivityLog
                            join am in _context.ActivityMaster
                            on fa.ActivityId equals am.Id
                            join sm in _context.StatusMaster
                            on fa.StatusId equals sm.Id
                            join um in _context.Users
                            on fa.UserId equals um.Id                           
                            join hm in _context.HBLMaster
                            on fa.HBLId equals hm.Id

                            select (new HBLQueryActivity
                            {
                                Id = hm.Id,
                                FileNo =hm.File.ToString(),
                                BookingNo = hm.Booking,
                                HBL_No = hm.HBLNumber,
                                CountryName = hm.File.Country.CountryName,
                                CustomerName = hm.CustomerName,
                                UserId=um.UserName,
                                ActivityId=fa.Activity.NameOfActivity,
                                StatusId=fa.Status.Status,
                                Comment=fa.Comment,
                                ProcessDate=fa.StartDate
                            }));

                }
                else
                {
                    data = (from fa in _context.HBLActivityLog
                            join am in _context.ActivityMaster
                            on fa.ActivityId equals am.Id
                            join sm in _context.StatusMaster
                            on fa.StatusId equals sm.Id
                            join um in _context.Users
                            on fa.UserId equals um.Id
                            where (um.UserName==User.Identity.Name)
                            join hm in _context.HBLMaster
                            on fa.HBLId equals hm.Id

                            select (new HBLQueryActivity
                            {
                                Id = hm.Id,
                                FileNo =hm.File.ToString(),
                                BookingNo = hm.Booking,
                                HBL_No = hm.HBLNumber,
                                CountryName = hm.File.Country.CountryName,
                                CustomerName = hm.CustomerName,
                                UserId=um.UserName,
                                ActivityId=fa.Activity.NameOfActivity,
                                StatusId=fa.Status.Status,
                                Comment=fa.Comment,
                                ProcessDate=fa.StartDate
                            }));
                }
            }
            else
            {
                ViewBag.Status = _context.StatusMaster.ToList();

                if (role!="User")
                {
                    data = (from fa in _context.HBLActivityLog
                            join am in _context.ActivityMaster
                            on fa.ActivityId equals am.Id
                            join sm in _context.StatusMaster
                            on fa.StatusId equals sm.Id
                            join um in _context.Users
                            on fa.UserId equals um.Id                          
                            join hm in _context.HBLMaster
                            on fa.HBLId equals hm.Id

                            select (new HBLQueryActivity
                            {
                                Id = hm.Id,
                                FileNo =hm.File.ToString(),
                                BookingNo = hm.Booking,
                                HBL_No = hm.HBLNumber,
                                CountryName = hm.File.Country.CountryName,
                                CustomerName = hm.CustomerName,
                                UserId=um.UserName,
                                ActivityId=fa.Activity.NameOfActivity,
                                StatusId=fa.Status.Status,
                                Comment=fa.Comment,
                                ProcessDate=fa.StartDate
                            }));

                }
                else
                {
                    data = (from fa in _context.HBLActivityLog
                            join am in _context.ActivityMaster
                            on fa.ActivityId equals am.Id
                            join sm in _context.StatusMaster
                            on fa.StatusId equals sm.Id
                            join um in _context.Users
                            on fa.UserId equals um.Id
                            where (um.UserName==User.Identity.Name)
                            join hm in _context.HBLMaster
                            on fa.HBLId equals hm.Id

                            select (new HBLQueryActivity
                            {
                                Id = hm.Id,
                                FileNo =hm.File.ToString(),
                                BookingNo = hm.Booking,
                                HBL_No = hm.HBLNumber,
                                CountryName = hm.File.Country.CountryName,
                                CustomerName = hm.CustomerName,
                                UserId=um.UserName,
                                ActivityId=fa.Activity.NameOfActivity,
                                StatusId=fa.Status.Status,
                                Comment=fa.Comment,
                                ProcessDate=fa.StartDate
                            }));
                }
            }
            ViewBag.StatusMaster = _context.StatusMaster.ToList();
            return View(data);

        }

        [HttpGet]
        public IActionResult GetHBLActivityQuery(string Id)
        {
            var sm = _context.StatusMaster.ToList();
            var HBL = _context.HBLActivityLog.Where(fileActivity => fileActivity.HBLId == Id)
            .Join(_context.ActivityMaster, activityJoin => activityJoin.ActivityId, activityMaster => activityMaster.Id, (activityJoin, activityMaster) => new { activityJoin, activityMaster })
            .Join(_context.StatusMaster, statusjoin => statusjoin.activityJoin.StatusId, statusMaster => statusMaster.Id, (statusjoin, statusMaster) => new { statusjoin, statusMaster })
            .Join(_context.Users, userjoin => userjoin.statusjoin.activityJoin.ApplicationUser.Id, User => User.Id, (userjoin, User) => new
            {

                Id = userjoin.statusjoin.activityMaster.Id,
                ActivityName = userjoin.statusjoin.activityMaster.NameOfActivity,
                Status = userjoin.statusMaster.Status,
                ProcessedDate = userjoin.statusjoin.activityJoin.EndDate,
                User = User.UserName,
                Comment = userjoin.statusjoin.activityJoin.Comment == null ? "" : userjoin.statusjoin.activityJoin.Comment,
            }).OrderByDescending(x => x.ProcessedDate).ToList().Where(x=>x.Status=="Query").AsQueryable();


            return Json(new { HBL, sm , Id });
        }

        public IActionResult HBLActivityChangeStatus(HBLQueryActivity hbl)
        {
            string Msg = "";
           
                var activityId = _context.ActivityMaster.Where(x => x.NameOfActivity == hbl.ActivityId).Select(x => x.Id).FirstOrDefault();
                var statusId = _context.StatusMaster.Where(x => x.Status == hbl.StatusId).Select(x => x.Id).FirstOrDefault();
                var userId = _context.Users.Where(x => x.UserName == hbl.UserId).Select(x => x.Id).FirstOrDefault();
                var hbldata= _context.HBLActivityLog.Where(x => x.Id == hbl.Id && x.ActivityId==activityId).FirstOrDefault();
                var hblActivityLog = _context.HBLActivityLog.FirstOrDefault(x => x.HBLId == hbl.Id);

                _context.HBLActivitylogHistory.Add(new HBLActivitylogHistory
                {
                    
                    HBLogId = hbl.Id,
                    ActivityId = hblActivityLog.ActivityId,
                    StatusId = hblActivityLog.StatusId,
                    Comment = hblActivityLog.Comment,
                    UserId = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier),
                    StartDate = DateTime.UtcNow,
                    EndDate = DateTime.UtcNow,
                });

            if (hblActivityLog != null)
                {
                    hblActivityLog.ActivityId = hblActivityLog.ActivityId;
                    hblActivityLog.StatusId = statusId;
                    hblActivityLog.StartDate = DateTime.UtcNow;
                    hblActivityLog.Comment = hbl.Comment;
                    hblActivityLog.UserId = userId;
                    _context.SaveChanges();
                    Msg ="Status Update Successfully.";
                }
                else
                {
                    Msg ="Error while processing the request.";
                }
            

            return Json(Msg);
        }

        public IActionResult FileActivityChangeStatus(FileQueryActivity filequery)
        {
            string Msg = "";

            var activityId = _context.ActivityMaster.Where(x => x.NameOfActivity == filequery.ActivityId).Select(x => x.Id).FirstOrDefault();
            var statusId = _context.StatusMaster.Where(x => x.Status == filequery.StatusId).Select(x => x.Id).FirstOrDefault();
            var userId = _context.Users.Where(x => x.UserName == filequery.UserId).Select(x => x.Id).FirstOrDefault();
           
            var fileActivityLog = _context.FileActivityLog.Where(x => x.FileId == filequery.Id && x.ActivityId==activityId).FirstOrDefault();


            _context.FileAcitivityLogHistory.Add(new FileAcitivityLogHistory
            {   FileLogId= fileActivityLog.Id,        
                ActivityId = fileActivityLog.ActivityId,
                StatusId = statusId,
                Comment = fileActivityLog.Comment,
                UserId = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier),
                StartDate = DateTime.UtcNow,
                EndDate = DateTime.UtcNow,
            });

            if (fileActivityLog != null)
            {
                fileActivityLog.ActivityId = fileActivityLog.ActivityId;
                fileActivityLog.StatusId = filequery.StatusId;
                //fileActivityLog.StartDate = filequery.ProcessDate;
                fileActivityLog.Comment = filequery.Comment;
                fileActivityLog.UserId = userId;

                _context.SaveChanges();
                Msg ="Status Update Successfully.";
            }
            else
            {
                Msg ="Error while processing the request.";
            }            

            return Json(Msg);
        }

    }
}

﻿using EuropeTrackX.DataModel;
using EuropeTrackX.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Threading.Tasks;

namespace EuropeTrackX.Controllers
{
	public class StatusMasterController : Controller
	{
		private readonly ApplicationDBContext _context;

		public StatusMasterController(ApplicationDBContext context)
		{
			_context = context;
		}

		// GET: StatusMaster
		public async Task<IActionResult> Index()
		{
			return View(await _context.StatusMaster.ToListAsync());
		}

		// GET: StatusMaster/Details/5
		public async Task<IActionResult> Details(string? id)
		{
			if (id == null || id.Trim()=="")
			{
				return NotFound();
			}

			var statusMaster = await _context.StatusMaster
				.FirstOrDefaultAsync(m => m.Id == id);
			if (statusMaster == null)
			{
				return NotFound();
			}

			return View(statusMaster);
		}

		// GET: StatusMaster/Create
		public IActionResult Create()
		{
			return View();
		}

		// POST: StatusMaster/Create
		// To protect from overposting
		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> Create([Bind("Id,Status,Value")] StatusMaster statusMaster)
		{
			if (ModelState.IsValid)
			{
				_context.Add(statusMaster);
				await _context.SaveChangesAsync();
				return RedirectToAction(nameof(Index));
			}
			return View(statusMaster);
		}

		// GET: StatusMaster/Edit/5
		public async Task<IActionResult> Edit(string? id)
		{
			if (id == null || id.Trim()=="")
			{
				return NotFound();
			}

			var statusMaster = await _context.StatusMaster.FindAsync(id);
			if (statusMaster == null)
			{
				return NotFound();
			}
			return View(statusMaster);
		}

		// POST: StatusMaster/Edit/5
		// To protect from overposting attacks, enable the specific properties you want to bind to, for 
		// more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
		[HttpPost]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> Edit(string id, [Bind("Id,Status,Value")] StatusMaster statusMaster)
		{
			if (id != statusMaster.Id)
			{
				return NotFound();
			}

			if (ModelState.IsValid)
			{
				try
				{
					_context.Update(statusMaster);
					await _context.SaveChangesAsync();
				}
				catch (DbUpdateConcurrencyException)
				{
					if (!StatusMasterExists(statusMaster.Id))
					{
						return NotFound();
					}
					else
					{
						throw;
					}
				}
				return RedirectToAction(nameof(Index));
			}
			return View(statusMaster);
		}

		// GET: StatusMaster/Delete/5
		public async Task<IActionResult> Delete(string? id)
		{
			if (id == null || id.Trim()=="")
			{
				return NotFound();
			}

			var statusMaster = await _context.StatusMaster
				.FirstOrDefaultAsync(m => m.Id == id);
			if (statusMaster == null)
			{
				return NotFound();
			}

			return View(statusMaster);
		}

		// POST: StatusMaster/Delete/5
		[HttpPost, ActionName("Delete")]
		[ValidateAntiForgeryToken]
		public async Task<IActionResult> DeleteConfirmed(string id)
		{
			var statusMaster = await _context.StatusMaster.FindAsync(id);
			_context.StatusMaster.Remove(statusMaster);
			await _context.SaveChangesAsync();
			return RedirectToAction(nameof(Index));
		}
		private bool StatusMasterExists(string id)
		{
			return _context.StatusMaster.Any(e => e.Id == id);
		}
	}
}
﻿using ClosedXML.Excel;
using EuropeTrackX.DataModel;
using EuropeTrackX.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Data;
using System.Linq.Dynamic.Core;
using System.Reflection;

namespace EuropeTrackX.Controllers
{
    [Authorize]
    public class DashboardController : Controller
    {
        ApplicationDBContext _context;
        public DashboardController(ApplicationDBContext context)
        {
            _context = context;
        }
        public async Task<IActionResult> Index()
        {
            ViewBag.StatusMaster = _context.StatusMaster.ToList();
            ViewBag.ActivityMaster = _context.ActivityMaster.ToList();
            ViewBag.Countries = _context.CountryMaster.ToList();
            return View();
        }

        [HttpPost]
        public IActionResult GetFiles(DataTableAjaxPostModel model, string country, string fileNumber, string hBLNumber)
        {
            var draw = model.draw;
            var sortColumn = string.IsNullOrEmpty(model.columns[model.order[0].column].data) ? "id" : model.columns[model.order[0].column].data;
            var sortColumnDirection = model.order[0].dir;
            var searchValue = model.search.value;
            int pageSize = model.length.HasValue ? model.length.Value : 100;
            int skip = model.start.HasValue ? model.start.Value : 0;

            if (fileNumber!=null)
            {
                searchValue="";
            }
            else if(country!=null)
            {
                searchValue="";
            }


            // Get the data for the DataTable
            var data = _context.FileMaster.Include(x => x.Country).Include(x => x.HBLMasters).AsQueryable();

            if (!string.IsNullOrEmpty(country) && country != "-- Select Country --")
            {
                data = data.Where(x => x.Country.CountryName.Contains(country));
            }
            if (!string.IsNullOrEmpty(fileNumber))
            {
                data = data.Where(x => x.FileNumber.Contains(fileNumber));
            }
            if (!string.IsNullOrEmpty(hBLNumber))
            {
                data = data.Where(x => x.HBLMasters.Any(hbl => hbl.HBLNumber.Contains(hBLNumber)));
            }
            IEnumerable<FileDashModel> files;
            if (searchValue=="Completed")
            {
                //var data2 = (from fm in _context.FileMaster
                //             join fa in _context.FileActivityLog
                //             on fm.Id equals fa.FileId
                //             join am in _context.ActivityMaster
                //             on fa.ActivityId equals am.Id
                //             join sm in _context.StatusMaster
                //             on fa.StatusId equals sm.Id
                //             where (sm.Status=="Completed")
                //             join um in _context.Users
                //             on fa.UserId equals um.Id
                //             select new FileDashModel
                //             {
                //                 Id = fm.Id,
                //                 CountryName = fm.Country.CountryName,
                //                 FileNumber = fm.FileNumber,
                //                 ETD = fm.Etd,
                //                 DraftCutOff = fm.DraftCutoff,
                //                 CountofHBL = fm.HBLMasters.Count()
                //             }).ToList();

                var data1 = _context.FileMaster
                                    .Include(fm => fm.Country)
                                    .Include(fm => fm.HBLMasters)
                                    .Include(fm => fm.FileActivityLogs)
                                        .ThenInclude(fa => fa.Activity)
                                    .Include(fm => fm.FileActivityLogs)
                                        .ThenInclude(fa => fa.Status)
                                    .Include(fm => fm.FileActivityLogs)
                                        .ThenInclude(fa => fa.ApplicationUser)
                                    .Where(fm => fm.FileActivityLogs.Any(fa => fa.Status.Status == "Completed"))
                                    .Select(fm => new FileDashModel
                                    {
                                        Id = fm.Id,
                                        CountryName = fm.Country.CountryName,
                                        FileNumber = fm.FileNumber,
                                        ETD = fm.Etd,
                                        DraftCutOff = fm.DraftCutoff,
                                        CountofHBL = fm.HBLMasters.Count()
                                    })
                                    .ToList();

                files=data1;                
            }
            else if (searchValue=="Pending")
            {

                var data1 = _context.FileMaster
                                       .Include(fm => fm.Country)
                                       .Include(fm => fm.HBLMasters)
                                       .Include(fm => fm.FileActivityLogs)
                                           .ThenInclude(fa => fa.Activity)
                                       .Include(fm => fm.FileActivityLogs)
                                           .ThenInclude(fa => fa.Status)
                                       .Include(fm => fm.FileActivityLogs)
                                           .ThenInclude(fa => fa.ApplicationUser)
                                       .Where(fm => fm.FileActivityLogs.Any(fa => fa.Status.Status == "Pending"))
                                       .Select(fm => new FileDashModel
                                       {
                                           Id = fm.Id,
                                           CountryName = fm.Country.CountryName,
                                           FileNumber = fm.FileNumber,
                                           ETD = fm.Etd,
                                           DraftCutOff = fm.DraftCutoff,
                                           CountofHBL = fm.HBLMasters.Count()
                                       })
                                       .ToList();

                files=data1;              
            }
            else if (searchValue=="Query")
            {
                var data1 = (from fm in _context.FileMaster
                             join fa in _context.FileActivityLog
                             on fm.Id equals fa.FileId
                             join am in _context.ActivityMaster
                             on fa.ActivityId equals am.Id
                             join sm in _context.StatusMaster
                             on fa.StatusId equals sm.Id
                             where (sm.Status=="Query")
                             join um in _context.Users
                             on fa.UserId equals um.Id
                             select new FileDashModel
                             {
                                 Id = fm.Id,
                                 CountryName = fm.Country.CountryName,
                                 FileNumber = fm.FileNumber,
                                 ETD = fm.Etd,
                                 DraftCutOff = fm.DraftCutoff,
                                 CountofHBL = fm.HBLMasters.Count()
                             }).ToList();
                //var data1 = _context.FileMaster
                //                    .Include(fm => fm.Country)
                //                    .Include(fm => fm.HBLMasters)
                //                    .Include(fm => fm.FileActivityLogs)
                //                        .ThenInclude(fa => fa.Activity)
                //                    .Include(fm => fm.FileActivityLogs)
                //                        .ThenInclude(fa => fa.Status)
                //                    .Include(fm => fm.FileActivityLogs)
                //                        .ThenInclude(fa => fa.ApplicationUser)
                //                    .Where(fm => fm.FileActivityLogs.Any(fa => fa.Status.Status == "Query"))
                //                    .Select(fm => new FileDashModel
                //                    {
                //                        Id = fm.Id,
                //                        CountryName = fm.Country.CountryName,
                //                        FileNumber = fm.FileNumber,
                //                        ETD = fm.Etd,
                //                        DraftCutOff = fm.DraftCutoff,
                //                        CountofHBL = fm.HBLMasters.Count()
                //                    })
                //                    .ToList();
                files=data1;
                
            }
            else if (searchValue=="UnAllocated")
            {

                var data1 = (from fm in _context.FileMaster
                             where !(from fa in _context.FileActivityLog
                                     where fm.Id == fa.FileId
                                     select fa)
                                    .Any()
                                      select new FileDashModel
                                     {
                                         Id = fm.Id,
                                         CountryName = fm.Country.CountryName,
                                         FileNumber = fm.FileNumber,
                                         ETD = fm.Etd,
                                         DraftCutOff = fm.DraftCutoff,
                                         CountofHBL = fm.HBLMasters.Count()
                                     }).ToList();
                
                files=data1;
            }
            else if (searchValue=="etd10")
            {

                var data1 = (from fm in _context.FileMaster
                             join fa in _context.FileActivityLog
                             on fm.Id equals fa.FileId
                             join am in _context.ActivityMaster
                             on fa.ActivityId equals am.Id
                             join sm in _context.StatusMaster
                             on fa.StatusId equals sm.Id
                             where (sm.Status!="Completed")
                             join um in _context.Users
                             on fa.UserId equals um.Id
                             select new FileDashModel
                             {
                                 Id = fm.Id,
                                 CountryName = fm.Country.CountryName,
                                 FileNumber = fm.FileNumber,
                                 ETD = fm.Etd,
                                 DraftCutOff = fm.DraftCutoff,
                                 CountofHBL = fm.HBLMasters.Count()
                             }).ToList();

                files=data1.Where(x => x.ETD != null && Convert.ToDateTime(x.ETD).AddDays(-10) <= DateTime.Now);
            }
            else if (searchValue=="etd12")
            {

                var data1 = (from fm in _context.FileMaster
                             join fa in _context.FileActivityLog
                             on fm.Id equals fa.FileId
                             join am in _context.ActivityMaster
                             on fa.ActivityId equals am.Id
                             join sm in _context.StatusMaster
                             on fa.StatusId equals sm.Id
                             where (sm.Status!="Completed")
                             join um in _context.Users
                             on fa.UserId equals um.Id
                             select new FileDashModel
                             {
                                 Id = fm.Id,
                                 CountryName = fm.Country.CountryName,
                                 FileNumber = fm.FileNumber,
                                 ETD = fm.Etd,
                                 DraftCutOff = fm.DraftCutoff,
                                 CountofHBL = fm.HBLMasters.Count()
                             }).ToList();


                files=data1.Where(x => x.ETD.Value.AddDays(-10) > DateTime.Now && x.ETD.Value.AddDays(-12) <= DateTime.Now);
            }
            else if (searchValue=="etd18")
            {

                var data1 = (from fm in _context.FileMaster
                             join fa in _context.FileActivityLog
                             on fm.Id equals fa.FileId
                             join am in _context.ActivityMaster
                             on fa.ActivityId equals am.Id
                             join sm in _context.StatusMaster
                             on fa.StatusId equals sm.Id
                             where (sm.Status!="Completed")
                             join um in _context.Users
                             on fa.UserId equals um.Id
                             select new FileDashModel
                             {
                                 Id = fm.Id,
                                 CountryName = fm.Country.CountryName,
                                 FileNumber = fm.FileNumber,
                                 ETD = fm.Etd,
                                 DraftCutOff = fm.DraftCutoff,
                                 CountofHBL = fm.HBLMasters.Count()
                             }).ToList();


                files=data1.Where(x => x.ETD.Value.AddDays(-12) > DateTime.Now);
            }
            else
            {              

                files = data.Select(
                   x => new FileDashModel
                   {
                       Id = x.Id,
                       CountryName = x.Country.CountryName,
                       FileNumber = x.FileNumber,
                       ETD = x.Etd,
                       DraftCutOff = x.DraftCutoff,
                       CountofHBL = x.HBLMasters.Count()
                   }).OrderBy(sortColumn + " " + sortColumnDirection)
                  .Skip(skip)
                  .Take(pageSize).AsQueryable().ToList();

            }

            

            ///switch case code in case of inavailability of System.linq.dynamic.core
            ///
            #region
            //switch (sortColumn)
            //{
            //    case "id":
            //        if (sortColumnDirection =="asc")
            //            files=files.OrderBy(x => x.Id);
            //        else
            //            files = files.OrderByDescending(x => x.Id);
            //        break;
            //    case "countryName":
            //        if (sortColumnDirection == "asc")
            //            files = files.OrderBy(x => x.CountryName);
            //        else
            //            files = files.OrderByDescending(x => x.CountryName);
            //        break;
            //    case "fileNumber":
            //        if (sortColumnDirection == "asc")
            //            files = files.OrderBy(x => x.FileNumber);
            //        else
            //            files = files.OrderByDescending(x => x.FileNumber);
            //        break;
            //    case "etd":
            //        if (sortColumnDirection == "asc")
            //            files = files.OrderBy(x => x.ETD);
            //        else
            //            files = files.OrderByDescending(x => x.ETD);
            //        break;
            //    case "draftCutOff":
            //        if (sortColumnDirection == "asc")
            //            files = files.OrderBy(x => x.DraftCutOff);
            //        else
            //            files = files.OrderByDescending(x => x.DraftCutOff);
            //        break;
            //    case "countofHBL":
            //        if (sortColumnDirection == "asc")
            //            files = files.OrderBy(x => x.CountofHBL);
            //        else
            //            files = files.OrderByDescending(x => x.CountofHBL);
            //        break;
            //}

            //files = files.Skip(skip * pageSize).Take(pageSize == -1 ? 100 : pageSize);
            #endregion


            // Return the data in the format required by DataTables
            return Json(new
            {
                draw = model.draw,
                recordsTotal = data.Count(),
                recordsFiltered = files.Count(),
                data = files
            });
        }


        [HttpGet]
        public IActionResult GetHblData(string fileNumber)
        {
            var hbl = _context.HBLMaster.Where(x => x.File.FileNumber == fileNumber).ToList();

            var sm=_context.StatusMaster.ToList();

            var fm = _context.FileActivityLog.Include(x => x.File).Include(x => x.Activity).Include(x => x.Status).Include(x => x.ApplicationUser).Where(x => x.File.FileNumber == fileNumber).ToList();
            IQueryable<FileActivityLog> fileActivityLog = fm.AsQueryable();
            foreach (var item in fm)
            {
                fileActivityLog.Select(x => new FileActivityLog
                {
                    ActivityId = _context.FileActivityLog.Where(x => x.Activity.Id == item.ActivityId).Select(x => x.Activity.NameOfActivity).FirstOrDefault(),
                    StatusId = _context.FileActivityLog.Where(x => x.Status.Id == item.StatusId).Select(x => x.Status.Status).FirstOrDefault(),
                    UserId = _context.FileActivityLog.Where(x => x.ApplicationUser.Id == item.UserId).Select(x => x.ApplicationUser.UserName).FirstOrDefault(),


                }).ToList();
            }

            return Json(new { fm, hbl,sm });
        }

        [HttpGet]
        public IActionResult GetHblActivityData(string hblnumber)
        {
            var hblact = _context.HBLActivityLog.Include(x => x.Hbl).Include(x => x.Activity).Include(x => x.Status).Where(x => x.Hbl.HBLNumber == hblnumber).ToList();
            IQueryable<HBLActivityLog> hblActivityLog = hblact.AsQueryable();
            foreach (var item in hblact)
            {
                hblActivityLog.Select(x => new HBLActivityLog
                {
                    ActivityId = _context.HBLActivityLog.Where(x => x.Activity.Id == item.ActivityId).Select(x => x.Activity.NameOfActivity).FirstOrDefault(),
                    StatusId = _context.HBLActivityLog.Where(x => x.Status.Id == item.StatusId).Select(x => x.Status.Status).FirstOrDefault(),
                    UserId = _context.HBLActivityLog.Where(x => x.ApplicationUser.Id == item.UserId).Select(x => x.ApplicationUser.UserName).FirstOrDefault(),

                }).ToList();
            }
            return Json(hblact);
        }


        
        public JsonResult GetDashboardCount()
        {
            var file = _context.FileMaster.Include(x => x.FileActivityLogs).ToList();
            var filelog = _context.FileActivityLog.Include(x=>x.Activity).Include(x=>x.Status).ToList();
            IQueryable<FileActivityLog> fileActivityLog = filelog.AsQueryable();

            foreach (var item in filelog)
            {               

                fileActivityLog.Select(x => new FileActivityLog
                {
                    ActivityId =  _context.FileActivityLog.Where(x => x.Activity.Id == item.ActivityId).Select(x => x.Activity.NameOfActivity).FirstOrDefault(),
                    StatusId = _context.FileActivityLog.Where(x => x.Status.Id == item.StatusId).Select(x => x.Status.Status).FirstOrDefault(),
                    UserId = _context.FileActivityLog.Where(x => x.ApplicationUser.Id == item.UserId).Select(x => x.ApplicationUser.UserName).FirstOrDefault(),
                }).ToList();

            }

            var eta = fileActivityLog.Where(x => x.File.Etd != null && Convert.ToDateTime(x.File.Etd).AddDays(-10) <= DateTime.Now && (x.Status.Status != "Completed")).Count();

            DashboardProdcount dp = new DashboardProdcount
            {
                Received =file.Count,                
                Pending =fileActivityLog.Where(x=>x.Status.Status=="Pending").Count(),   
                WIP = fileActivityLog.Where(x => x.Status.Status=="WIP").Count(),
                Query = fileActivityLog.Where(x => x.Status.Status=="Query").Count(),
                Completed = fileActivityLog.Where(x => x.Status.Status=="Completed").Count(),
                UnAllocated =_context.FileMaster.Except(_context.FileActivityLog.Select(fa => fa.File)).Count(),
                etd10 = fileActivityLog.Where(x => x.File.Etd != null && Convert.ToDateTime(x.File.Etd).AddDays(-10) <= DateTime.Now && (x.Status.Status != "Completed")).Count(),
                etd12 = fileActivityLog.Where(x => x.File.Etd.Value.AddDays(-10) > DateTime.Now && x.File.Etd.Value.AddDays(-12) <= DateTime.Now && (x.Status.Status == null || x.Status.Status == "WIP")).Count(),
                etd18 = fileActivityLog.Where(x => x.File.Etd.Value.AddDays(-12) > DateTime.Now && (x.Status.Status == null )).Count(),
            };

            return Json(dp);
        }

        public ActionResult Report()
        {

            return View();
        }

        [HttpPost]
        public ActionResult Report(ReportViewModel report)
        {

            var data = (from fa in _context.FileActivityLog                        
                        join fm in _context.FileMaster                        
                        on fa.FileId equals fm.Id
                        where (fm.EnterDate>= Convert.ToDateTime(report.start_date) && fm.EnterDate <= Convert.ToDateTime(report.end_date))
                        join am in _context.ActivityMaster
                        on fa.ActivityId equals am.Id
                        join um in _context.Users
                        on fa.UserId equals um.Id
                        select new FileDashModel
                        {                           
                            CountryName=fm.Country.CountryName,
                            DraftCutOff=fm.DraftCutoff,
                            ETD=fm.Etd,
                            FileNumber=fm.FileNumber,
                            ActivityId=am.NameOfActivity,
                            StatusId=fa.Status.Status,
                            Comment=fa.Comment,
                            UserId=um.UserName
                        }).ToList();

            var HBLdata = (from ha in _context.HBLActivityLog                         
                        join hm in _context.HBLMaster
                        on ha.HBLId equals hm.Id
                        join fa in _context.FileMaster
                        on hm.FileId equals fa.Id
                        where (hm.EnterDate>= Convert.ToDateTime(report.start_date) && hm.EnterDate <= Convert.ToDateTime(report.end_date))
                        join am in _context.ActivityMaster
                        on ha.ActivityId equals am.Id
                        join um in _context.Users
                        on ha.UserId equals um.Id
                        select new ReportTemplateModel
                        {
                            CountryName=fa.Country.CountryName,
                            FileNumber=fa.FileNumber,
                            Container=hm.Container,
                            BookingNo=hm.Booking,
                            ETD=fa.Etd,
                            HBL_No=hm.HBLNumber,                            
                            ActivityId=am.NameOfActivity,
                            StatusId=ha.Status.Status,                            
                            Comment=ha.Comment,
                            UserId=um.UserName,
                            EnterDate=hm.EnterDate,
                            StartDate=ha.StartDate,
                            EndDate=ha.EndDate                            
                        }).ToList();

            DataTable filedt = ToDataTable(data);
            DataTable hbldt = ToDataTable(HBLdata);

            //saveFile.Filter = "Excel files (*.xlsx)|*.xlsx";
            //saveFile.Filter = "Excel files (*.xlsx)";
            string filename = "";
                //filename = saveFile.FileName;
                string apath = filename + ".xlsx";
                using (XLWorkbook wb = new XLWorkbook())
                {
                filedt.TableName = "File Data";         
                var wsFileData = wb.Worksheets.Add(filedt);
                var wsHblData = wb.Worksheets.Add(hbldt);            

                try
                    {
                        using (MemoryStream stream = new MemoryStream())
                        {
                            wb.SaveAs(stream);
                            string excelname = $"UserReport-{DateTime.Now.ToString("ddmmyyyy hh:mm:ss")}.xlsx";
                            return File(stream.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", excelname);
                        }

                        // System.Windows.Forms.MessageBox.Show("File Save Successfully.!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    catch (Exception ex)
                    {
                        // System.Windows.Forms.MessageBox.Show("Something went wrong.!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }         

            return View();
        }
        //List to Database convert
        public DataTable ToDataTable<T>(List<T> items)
        {
            DataTable dataTable = new DataTable(typeof(T).Name);
            //Get all the properties by using reflection   
            PropertyInfo[] Props = typeof(T).GetProperties(BindingFlags.Public | BindingFlags.Instance);
            foreach (PropertyInfo prop in Props)
            {
                //Setting column names as Property names  
                dataTable.Columns.Add(prop.Name);
            }
            foreach (T item in items)
            {
                var values = new object[Props.Length];
                for (int i = 0; i < Props.Length; i++)
                {

                    values[i] = Props[i].GetValue(item, null);
                }
                dataTable.Rows.Add(values);
            }

            return dataTable;
        }

        //Get UserCount
        public ActionResult GetCountofUser()
        {

            return View();
        }
        //User wise data
        [HttpPost]
        public JsonResult GetUserDatacount()
        {
            var draw = Request.Form["draw"].FirstOrDefault();
            var sortColumn = Request.Form["columns[" + Request.Form["order[0][column]"].FirstOrDefault() + "][name]"].FirstOrDefault();
            var sortColumnDirection = Request.Form["order[0][dir]"].FirstOrDefault();
            List<ApplicationUser> udata = _context.Users.ToList();
           
            
            
            var result =_context.FileMaster 
                        .Include(fm => fm.FileActivityLogs)
                            .ThenInclude(fa => fa.Activity)                        
                        .Include(fm => fm.FileActivityLogs)
                            .ThenInclude(fa => fa.Status)
                        .Include(fm => fm.FileActivityLogs)
                            .ThenInclude(fa => fa.ApplicationUser)
                        .Where(fm => fm.FileActivityLogs.Any(fa => fa.Status.Status != "Completed"))
                        .Select(fm => new
                        {
                            Id = fm.Id,
                            FileId=fm.FileNumber,
                            Countryname=fm.Country.CountryName,
                            ActivityName = fm.FileActivityLogs.Select(x=>x.Activity.NameOfActivity),
                            StatusName = fm.FileActivityLogs.Select(x => x.Status.Status),
                            UserName = fm.FileActivityLogs.Select(x => x.ApplicationUser.UserName),
                           
                            // Add other relevant properties here
                        })
                        .ToList();


                    var data = (from fm in _context.FileMaster
                                join fa in _context.FileActivityLog
                                on fm.Id equals fa.FileId
                                join am in _context.ActivityMaster
                                on fa.ActivityId equals am.Id
                                join um in _context.Users
                                on fa.UserId equals um.Id
                                select new FileDashModel
                                {   Id=fm.Id,
                                    CountryName=fm.Country.CountryName,
                                    DraftCutOff=fm.DraftCutoff,
                                    ETD=fm.Etd,
                                    FileNumber=fm.FileNumber,
                                    ActivityId=am.NameOfActivity,
                                    StatusId=fa.Status.Status  ,
                                    Comment=fa.Comment,
                                    UserId=um.UserName
                            
                                });




            //var result = from c in fdata
            //             group c.Username by c.Username into g
            //             select new
            //             {
            //                 Username = fdata.Where(x=>x.Username==g.Key),  
            //                 Total = fdata.Where(x => x.Username==g.Key).Count(),
            //                 activityname=fdata.Select(x=>x.Activity),
            //                 Query = fdata.Where(x => x.Username==g.Key && x.Status.ToString() =="Query").Count(),
            //                 Pending = fdata.Where(x => x.Username==g.Key && x.Status.ToString() =="Pending").Count(),
            //                 Completed = fdata.Where(x => x.Username==g.Key && x.Status.ToString() =="Completed").Count()
                             
            //             };

            //try
            //{

            //    if (!string.IsNullOrEmpty(sortColumn) && !string.IsNullOrEmpty(sortColumnDirection))
            //        result = result.AsQueryable().OrderBy(sortColumn + " " + sortColumnDirection).AsQueryable();
            //}
            //catch { }

            int totalRecord = 0;
            int filterRecord = 0;

            var returnObj = new
            {
                data = result//.Where(x => x.Username!=null)
            };

            return Json(returnObj);
        }

        //public async void DashData(int? page, string sort, string order, string search)
        //{item.Activity.NameOfActivity,//
        //	// Set default values for sort, order, and search
        //	if (sort == null) sort = "CountryName";
        //	if (order == null) order = "asc";
        //	if (search == null) search = "";

        //	// Get a list of files
        //	var files = await _context.Files
        //		//.Include(f => f.Country)
        //		.Include(f => f.FileActivityLogs)
        //		.ThenInclude(x => x.ActivityMaster)
        //		.Include(f => f.FileActivityLogs)
        //		.ThenInclude(x => x.StatusMaster)
        //		.Include(f => f.HBLs)
        //		.ToListAsync();

        //	// Filter the list of files by search query
        //	if (!string.IsNullOrEmpty(search))
        //	{
        //		files = files.Where(f => f.Country.CountryName.Contains(search)
        //							|| f.FileNumber.Contains(search)
        //							|| f.HBLs.Any(x => x.HBLNumber.Contains(search))).ToList();
        //	}

        //	// Sort the list of files
        //	switch (sort)
        //	{
        //		case "CountryName":
        //			files = order == "asc" ? files.OrderBy(f => f.Country.CountryName).ToList()
        //								   : files.OrderByDescending(f => f.Country.CountryName).ToList();
        //			break;
        //		case "FileNumber":
        //			files = order == "asc" ? files.OrderBy(f => f.FileNumber).ToList()
        //								   : files.OrderByDescending(f => f.FileNumber).ToList();
        //			break;
        //		case "ETD":
        //			files = order == "asc" ? files.OrderBy(f => f.ETD).ToList()
        //								   : files.OrderByDescending(f => f.ETD).ToList();
        //			break;
        //		case "DraftCutoff":
        //			files = order == "asc" ? files.OrderBy(f => f.DraftCutoff).ToList()
        //								   : files.OrderByDescending(f => f.DraftCutoff).ToList();
        //			break;
        //		case "HBLs":
        //			files = order == "asc" ? files.OrderBy(f => f.HBLs.Count()).ToList()
        //								   : files.OrderByDescending(f => f.HBLs.Count()).ToList();
        //			break;
        //		default:
        //			files = order == "asc" ? files.OrderBy(f => f.Country.CountryName).ToList()
        //								   : files.OrderByDescending(f => f.Country.CountryName).ToList();
        //			break;
        //	}

        //	// Set up pagination
        //	int pageSize = 10;
        //	int pageNumber = (page ?? 1);
        //}



    }

   

}

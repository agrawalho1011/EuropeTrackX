﻿using ClosedXML.Excel;
using DocumentFormat.OpenXml.Spreadsheet;
using EuropeTrackX.DataModel;
using EuropeTrackX.ViewModels;
using Microsoft.AspNetCore.Mvc;
using System.Drawing;
using System.Net;

namespace EuropeTrackX.Controllers
{
	public class UploadController : Controller
	{
		ApplicationDBContext _context;
		public UploadController(ApplicationDBContext context)
		{
			_context = context;

		}

		public IActionResult Index()
		{

			ViewBag.Countries = _context.CountryMaster.ToList();
			Console.WriteLine(ViewBag.Countries.Count);
			return View(new UploadViewModel());
		}

		[HttpPost]
		public async Task<IActionResult> Index(UploadViewModel model)
		{


			if (ModelState.IsValid)
			{
				// Save the uploaded file to the server
				var filePath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "uploads", model.File.FileName);
				using (var stream = new FileStream(filePath, FileMode.Create))
				{
					await model.File.CopyToAsync(stream);
				}
				UploadFile(filePath);
			}
			// Return a response to the client
			return RedirectToAction("Index", "Dashboard");
		}


		public async void UploadFile(string filePath)
		{
			List<CountryMaster> country = _context.CountryMaster.ToList();
			using (var stream = new FileStream(filePath, FileMode.Open))
			{
				using (var workbook = new XLWorkbook(stream))
				{
					var worksheet = workbook.Worksheet(1);
					var rows = worksheet.RowsUsed();
					int skip = 1;
					foreach (var row in rows)
					{
						string prv_file = "";
						if (skip != 1 && row.Cell(2).GetString().Trim() != "")
						{
							FileMaster File_exists = _context.FileMaster.Where(x => x.FileNumber == row.Cell(2).GetString()).FirstOrDefault();
							if (File_exists == null)
							{
								File_exists = new FileMaster();
								File_exists.Country = country.Where(x => x.CountryName == row.Cell(1).GetString()).FirstOrDefault();
								File_exists.FileNumber = row.Cell(2).GetString();
								File_exists.EnterDate = DateTime.UtcNow;
								if (row.Cell(7).Value.ToString().Trim() != "")
								{
									try {
										double d = double.Parse(row.Cell(7).Value.ToString());
										DateTime conv = DateTime.FromOADate(d);
										File_exists.Etd = conv;
									} catch (InvalidCastException ex) { }
									//File_exists.Etd = row.Cell(7).GetDateTime();
								}
								if (row.Cell(8).Value.ToString().Trim() != "")
								{
									try
									{
										double d = double.Parse(row.Cell(8).Value.ToString());
										DateTime conv = DateTime.FromOADate(d);
										File_exists.DraftCutoff = conv;
									}
									catch (InvalidCastException ex) { }
									//File_exists.DraftCutoff = row.Cell(8).GetDateTime();
								}
								prv_file = row.Cell(2).GetString();
								_context.FileMaster.Add(File_exists);
								_context.SaveChanges();

							}
							HBLMaster hbl_number = _context.HBLMaster.Where(x => x.HBLNumber == row.Cell(5).GetString()).FirstOrDefault();
							if (hbl_number == null)
							{
								var hblNumber = row.Cell(5).GetString();
								var customerName = row.Cell(4).GetString();
								var container = row.Cell(6).GetString();
								var booking = row.Cell(3).GetString();

								// Create a new HBL object and set its properties
								var hbl = new HBLMaster
								{
									HBLNumber = hblNumber,
									FileId = File_exists.Id,
									CustomerName = customerName,
									Container = container,
									Booking = booking,
									EnterDate = DateTime.UtcNow
								};
								// Insert the HBL object into the database
								_context.HBLMaster.Add(hbl);
								_context.SaveChanges();
							}
							
						}
						skip = skip + 1;

					}

					//_context.SaveChanges();
				}
			}

		}

	}
}

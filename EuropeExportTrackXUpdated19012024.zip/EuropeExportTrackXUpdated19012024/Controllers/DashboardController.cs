﻿using ClosedXML.Excel;
using EuropeTrackX.DataModel;
using EuropeTrackX.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Data;
using System.Linq.Dynamic.Core;
using System.Reflection;

namespace EuropeTrackX.Controllers
{
    [Authorize]
    public class DashboardController : Controller
    {
        ApplicationDBContext _context;
        public DashboardController(ApplicationDBContext context)
        {
            _context = context;
        }

        [Authorize(Roles = "Supervisor,Manager")]
        public async Task<IActionResult> Index()
        {

            ViewData["Status"] = _context.StatusMaster.Where(x => x.IsActive == true && x.IsDelete == false).ToList();
            ViewData["Activity"] = _context.ActivityMaster.Where(x => x.ActivityType == "File" && x.Source == "Upload" && x.IsActive == true && x.IsDelete == false).ToList();
            ViewData["Country"] = _context.CountryMaster.Where(x => x.IsActive == true && x.IsDelete == false).ToList();
            ViewData["User"] = _context.Users.Where(x => x.IsActive == true && x.IsDelete == false).ToList();
            return View();
        }
        // Get Files Data
        [HttpPost]
        
        public IActionResult GetFiles(DataTableAjaxPostModel model, string country, string fileNumber, string hBLNumber)
        {
            var draw = model.draw;
            var sortColumn = string.IsNullOrEmpty(model.columns[model.order[0].column].data) ? "id" : model.columns[model.order[0].column].data;
            var sortColumnDirection = model.order[0].dir;
            var searchValue = model.search.value;
            int pageSize = model.length.HasValue ? model.length.Value : 100;
            int skip = model.start.HasValue ? model.start.Value : 0;

            if (fileNumber != null)
            {
                searchValue = "";
            }
            else if (country != null)
            {
                searchValue = "";
            }

            // Get the data for the DataTable
            var data = _context.FileMaster.Include(x => x.Country).Include(x => x.HBLMasters).AsQueryable();

            if (!string.IsNullOrEmpty(country) && country != "-- Select Country --")
            {
                data = data.Where(x => x.Country.CountryName.Contains(country.Trim()));
            }
            if (!string.IsNullOrEmpty(fileNumber))
            {
                data = data.Where(x => x.FileNumber.Contains(fileNumber.Trim()));
            }
            if (!string.IsNullOrEmpty(hBLNumber))
            {
                data = data.Where(x => x.HBLMasters.Any(hbl => hbl.HBLNumber.Contains(hBLNumber.Trim())));
            }
            IEnumerable<FileDashModel> files;

            files = _context.FileMaster.Include(x => x.Country).Include(x => x.HBLMasters)
                        .Include(x => x.FileActivityLogs).ThenInclude(x => x.Activity)
                        .Include(x => x.FileActivityLogs).ThenInclude(x => x.Status).Select(x => new FileDashModel
                        {
                            Id = x.Id,
                            CountryName = x.Country.CountryName,
                            FileNumber = x.FileNumber,
                            ETD = x.Etd,
                            DraftCutOff = x.DraftCutoff,
                            CountofHBL = x.HBLMasters.Count(),
                            ProcessedHBL = x.HBLMasters.Where(y => y.FileId == x.Id).SelectMany(y => y.HBLActivityLogs.Select(log => log.HBLId)).Distinct().Count(),
                            PendingHBL = (x.HBLMasters.Count() - x.HBLMasters.Where(y => y.FileId == x.Id).SelectMany(y => y.HBLActivityLogs.Select(log => log.HBLId)).Distinct().Count()),
                            UserId = x.FileActivityLogs.Where(y => y.Activity.NameOfActivity == "FileAllocation").Select(x => x.ApplicationUser.UserName).FirstOrDefault(),
                            StatusId = x.FileActivityLogs.Where(y => y.Activity.NameOfActivity == "FileAllocation").Select(x => x.Status.Status).FirstOrDefault(),

                        }).Distinct().AsQueryable();
            IQueryable<FileDashModel> SortedData = files.AsQueryable();
            if (searchValue == "Completed")
            {
                //var data1 = _context.FileMaster
                //            .Include(fm => fm.Country)
                //            .Include(fm => fm.HBLMasters)
                //            .Include(fm => fm.FileActivityLogs)
                //                .ThenInclude(fa => fa.Activity)
                //            .Include(fm => fm.FileActivityLogs)
                //                .ThenInclude(fa => fa.Status)
                //            .Include(fm => fm.FileActivityLogs)
                //                .ThenInclude(fa => fa.ApplicationUser)
                //            .Where(fm => fm.FileActivityLogs.Any(fa => fa.Status.Status == "Completed"))
                //            .Select(fm => new FileDashModel
                //            {
                //                Id = fm.Id,
                //                CountryName = fm.Country.CountryName,
                //                FileNumber = fm.FileNumber,
                //                ETD = fm.Etd,
                //                DraftCutOff = fm.DraftCutoff,
                //                CountofHBL = fm.HBLMasters.Count(),
                //                ProcessedHBL = fm.HBLMasters
                //                .Where(y => y.FileId == fm.Id)
                //                .SelectMany(y => y.HBLActivityLogs.Select(log => log.HBLId))
                //                .Distinct()
                //                .Count(),
                //                PendingHBL = (fm.HBLMasters.Count() - fm.HBLMasters
                //                .Where(y => y.FileId == fm.Id)
                //                .SelectMany(y => y.HBLActivityLogs.Select(log => log.HBLId))
                //                .Distinct()
                //                .Count()),
                //                UserId = fm.FileActivityLogs.Where(y => y.Activity.NameOfActivity == "FileAllocation").Select(x => x.ApplicationUser.UserName).FirstOrDefault(),
                //                StatusId = fm.FileActivityLogs.Where(y => y.Activity.NameOfActivity == "FileAllocation").Select(x => x.Status.Status).FirstOrDefault(),

                //            })
                //            .ToList();

                SortedData = SortedData.Where(x => x.StatusId == "Completed");


                //data1 = _context.FileMaster.Include(x => x.Country).Include(x => x.HBLMasters)
                //        .Include(x => x.FileActivityLogs).ThenInclude(x => x.Activity)
                //        .Include(x => x.FileActivityLogs).ThenInclude(x => x.Status).Select(x => new FileDashModel
                //        {
                //            Id = x.Id,
                //            CountryName = x.Country.CountryName,
                //            FileNumber = x.FileNumber,
                //            ETD = x.Etd,
                //            DraftCutOff = x.DraftCutoff,
                //            CountofHBL = x.HBLMasters.Count(),
                //            ProcessedHBL = x.HBLMasters.Where(y => y.FileId == x.Id).SelectMany(y => y.HBLActivityLogs.Select(log => log.HBLId)).Distinct().Count(),
                //            PendingHBL = (x.HBLMasters.Count() - x.HBLMasters.Where(y => y.FileId == x.Id).SelectMany(y => y.HBLActivityLogs.Select(log => log.HBLId)).Distinct().Count()),
                //            UserId = x.FileActivityLogs.Where(y => y.Activity.NameOfActivity == "FileAllocation").Select(x => x.ApplicationUser.UserName).FirstOrDefault(),
                //            StatusId = x.FileActivityLogs.Where(y => y.Activity.NameOfActivity == "FileAllocation").Select(x => x.Status.Status).FirstOrDefault(),

                //        }).Distinct().ToList();
            }
            else if (searchValue == "Pending")
            {
                //var data1 = _context.FileMaster
                //    .Include(fm => fm.Country)
                //    .Include(fm => fm.HBLMasters)
                //    .Include(fm => fm.FileActivityLogs)
                //        .ThenInclude(fa => fa.Activity)
                //    .Include(fm => fm.FileActivityLogs)
                //        .ThenInclude(fa => fa.Status)
                //    .Include(fm => fm.FileActivityLogs)
                //        .ThenInclude(fa => fa.ApplicationUser)
                //    .Where(fm => fm.FileActivityLogs.Any(fa => fa.Status.Status != "Completed" || fa.Status.Status != "Query"))
                //    .Select(fm => new FileDashModel
                //    {
                //        Id = fm.Id,
                //        CountryName = fm.Country.CountryName,
                //        FileNumber = fm.FileNumber,
                //        ETD = fm.Etd,
                //        DraftCutOff = fm.DraftCutoff,
                //        CountofHBL = fm.HBLMasters.Count(),
                //        ProcessedHBL = fm.HBLMasters
                //        .Where(y => y.FileId == fm.Id)
                //        .SelectMany(y => y.HBLActivityLogs.Select(log => log.HBLId))
                //        .Distinct()
                //        .Count(),
                //        PendingHBL = (fm.HBLMasters.Count() - fm.HBLMasters
                //        .Where(y => y.FileId == fm.Id)
                //        .SelectMany(y => y.HBLActivityLogs.Select(log => log.HBLId))
                //        .Distinct()
                //        .Count()),
                //        UserId = fm.FileActivityLogs.Where(y => y.Activity.NameOfActivity == "FileAllocation").Select(x => x.ApplicationUser.UserName).FirstOrDefault(),
                //        StatusId = fm.FileActivityLogs.Where(y => y.Activity.NameOfActivity == "FileAllocation").Select(x => x.Status.Status).FirstOrDefault(),

                //    })
                //    .Distinct()
                //    .ToList();

                SortedData = SortedData.Where(x => x.StatusId == "Pending");
            }
            else if (searchValue == "Query")
            {
                //var data1 = (from fm in _context.FileMaster
                //             join fa in _context.FileActivityLog
                //             on fm.Id equals fa.FileId
                //             join am in _context.ActivityMaster
                //             on fa.ActivityId equals am.Id
                //             join sm in _context.StatusMaster
                //             on fa.StatusId equals sm.Id
                //             where (sm.Status == "Query")
                //             join um in _context.Users
                //             on fa.UserId equals um.Id
                //             select new FileDashModel
                //             {
                //                 Id = fm.Id,
                //                 CountryName = fm.Country.CountryName,
                //                 FileNumber = fm.FileNumber,
                //                 ETD = fm.Etd,
                //                 DraftCutOff = fm.DraftCutoff,
                //                 CountofHBL = fm.HBLMasters.Count(),
                //                 ProcessedHBL = fm.HBLMasters
                //                       .Where(y => y.FileId == fm.Id)
                //                       .SelectMany(y => y.HBLActivityLogs.Select(log => log.HBLId))
                //                       .Distinct()
                //                       .Count(),
                //                 PendingHBL = (fm.HBLMasters.Count() - fm.HBLMasters
                //                       .Where(y => y.FileId == fm.Id)
                //                       .SelectMany(y => y.HBLActivityLogs.Select(log => log.HBLId))
                //                       .Distinct()
                //                       .Count()),
                //                 UserId = fm.FileActivityLogs.Where(y => y.Activity.NameOfActivity == "FileAllocation").Select(x => x.ApplicationUser.UserName).FirstOrDefault(),
                //                 StatusId = fm.FileActivityLogs.Where(y => y.Activity.NameOfActivity == "FileAllocation").Select(x => x.Status.Status).FirstOrDefault()
                //             }).ToList();
                SortedData = SortedData.Where(x => x.StatusId == "Query");
            }
            else if (searchValue == "UnAllocated")
            {
                //var data1 = (from fm in _context.FileMaster
                //             where !(from fa in _context.FileActivityLog
                //                     where fm.Id == fa.FileId
                //                     select fa)
                //                    .Any()
                //             select new FileDashModel
                //             {
                //                 Id = fm.Id,
                //                 CountryName = fm.Country.CountryName,
                //                 FileNumber = fm.FileNumber,
                //                 ETD = fm.Etd,
                //                 DraftCutOff = fm.DraftCutoff,
                //                 CountofHBL = fm.HBLMasters.Count(),
                //                 ProcessedHBL = fm.HBLMasters
                //                       .Where(y => y.FileId == fm.Id)
                //                       .SelectMany(y => y.HBLActivityLogs.Select(log => log.HBLId))
                //                       .Distinct()
                //                       .Count(),
                //                 PendingHBL = (fm.HBLMasters.Count() - fm.HBLMasters
                //                       .Where(y => y.FileId == fm.Id)
                //                       .SelectMany(y => y.HBLActivityLogs.Select(log => log.HBLId))
                //                       .Distinct()
                //                       .Count()),
                //                 UserId = fm.FileActivityLogs.Where(y => y.Activity.NameOfActivity == "FileAllocation").Select(x => x.ApplicationUser.UserName).FirstOrDefault(),
                //                 StatusId = fm.FileActivityLogs.Where(y => y.Activity.NameOfActivity == "FileAllocation").Select(x => x.Status.Status).FirstOrDefault(),
                //                 //Completion=(10-7)/10*100,
                //             }).ToList();

                SortedData = SortedData.Where(x => x.StatusId == null || x.StatusId == "");
            }
            else if (searchValue == "etd10")
            {
                //var data1 = (from fm in _context.FileMaster
                //             join fa in _context.FileActivityLog
                //             on fm.Id equals fa.FileId
                //             join am in _context.ActivityMaster
                //             on fa.ActivityId equals am.Id
                //             join sm in _context.StatusMaster
                //             on fa.StatusId equals sm.Id
                //             where (sm.Status != "Completed")
                //             join um in _context.Users
                //             on fa.UserId equals um.Id
                //             select new FileDashModel
                //             {
                //                 Id = fm.Id,
                //                 CountryName = fm.Country.CountryName,
                //                 FileNumber = fm.FileNumber,
                //                 ETD = fm.Etd,
                //                 DraftCutOff = fm.DraftCutoff,
                //                 CountofHBL = fm.HBLMasters.Count(),
                //                 ProcessedHBL = fm.HBLMasters
                //                       .Where(y => y.FileId == fm.Id)
                //                       .SelectMany(y => y.HBLActivityLogs.Select(log => log.HBLId))
                //                       .Distinct()
                //                       .Count(),
                //                 PendingHBL = (fm.HBLMasters.Count() - fm.HBLMasters
                //                       .Where(y => y.FileId == fm.Id)
                //                       .SelectMany(y => y.HBLActivityLogs.Select(log => log.HBLId))
                //                       .Distinct()
                //                       .Count()),
                //                 UserId = fm.FileActivityLogs.Where(y => y.Activity.NameOfActivity == "FileAllocation").Select(x => x.ApplicationUser.UserName).FirstOrDefault(),
                //                 StatusId = fm.FileActivityLogs.Where(y => y.Activity.NameOfActivity == "FileAllocation").Select(x => x.Status.Status).FirstOrDefault(),
                //                 //Completion=(10-7)/10*100,
                //             }).ToList();

                //files = data1.Where(x => x.ETD != null && x.ETD.Value.Date >= DateTime.Now.Date && x.ETD.Value.Date < DateTime.Now.Date.AddDays(11));
                SortedData = SortedData.Where(x => x.ETD != null && x.ETD.Value.Date >= DateTime.Now.Date && x.ETD.Value.Date < DateTime.Now.Date.AddDays(11) && x.StatusId != "Completed");
            }
            else if (searchValue == "etd12")
            {

                //var data1 = (from fm in _context.FileMaster
                //             join fa in _context.FileActivityLog
                //             on fm.Id equals fa.FileId
                //             join am in _context.ActivityMaster
                //             on fa.ActivityId equals am.Id
                //             join sm in _context.StatusMaster
                //             on fa.StatusId equals sm.Id
                //             where (sm.Status != "Completed")
                //             join um in _context.Users
                //             on fa.UserId equals um.Id
                //             select new FileDashModel
                //             {
                //                 Id = fm.Id,
                //                 CountryName = fm.Country.CountryName,
                //                 FileNumber = fm.FileNumber,
                //                 ETD = fm.Etd,
                //                 DraftCutOff = fm.DraftCutoff,
                //                 CountofHBL = fm.HBLMasters.Count(),
                //                 ProcessedHBL = fm.HBLMasters
                //                       .Where(y => y.FileId == fm.Id)
                //                       .SelectMany(y => y.HBLActivityLogs.Select(log => log.HBLId))
                //                       .Distinct()
                //                       .Count(),
                //                 PendingHBL = (fm.HBLMasters.Count() - fm.HBLMasters
                //                       .Where(y => y.FileId == fm.Id)
                //                       .SelectMany(y => y.HBLActivityLogs.Select(log => log.HBLId))
                //                       .Distinct()
                //                       .Count()),
                //                 UserId = fm.FileActivityLogs.Where(y => y.Activity.NameOfActivity == "FileAllocation").Select(x => x.ApplicationUser.UserName).FirstOrDefault(),
                //                 StatusId = fm.FileActivityLogs.Where(y => y.Activity.NameOfActivity == "FileAllocation").Select(x => x.Status.Status).FirstOrDefault(),
                //                 //Completion=(10-7)/10*100,
                //             }).ToList();


                //files = data1.Where(x => x.ETD.Value.Date >= DateTime.Now.Date.AddDays(11) && x.ETD.Value.Date < DateTime.Now.Date.AddDays(13));
                SortedData = SortedData.Where(x => x.ETD.Value.Date >= DateTime.Now.Date.AddDays(11) && x.ETD.Value.Date < DateTime.Now.Date.AddDays(13) && x.StatusId != "Completed");
            }
            else if (searchValue == "etd18")
            {

                //var data1 = (from fm in _context.FileMaster
                //             join fa in _context.FileActivityLog
                //             on fm.Id equals fa.FileId
                //             join am in _context.ActivityMaster
                //             on fa.ActivityId equals am.Id
                //             join sm in _context.StatusMaster
                //             on fa.StatusId equals sm.Id
                //             where (sm.Status != "Completed")
                //             join um in _context.Users
                //             on fa.UserId equals um.Id
                //             select new FileDashModel
                //             {
                //                 Id = fm.Id,
                //                 CountryName = fm.Country.CountryName,
                //                 FileNumber = fm.FileNumber,
                //                 ETD = fm.Etd,
                //                 DraftCutOff = fm.DraftCutoff,
                //                 CountofHBL = fm.HBLMasters.Count(),
                //                 ProcessedHBL = fm.HBLMasters
                //                       .Where(y => y.FileId == fm.Id)
                //                       .SelectMany(y => y.HBLActivityLogs.Select(log => log.HBLId))
                //                       .Distinct()
                //                       .Count(),
                //                 PendingHBL = (fm.HBLMasters.Count() - fm.HBLMasters
                //                       .Where(y => y.FileId == fm.Id)
                //                       .SelectMany(y => y.HBLActivityLogs.Select(log => log.HBLId))
                //                       .Distinct()
                //                       .Count()),
                //                 UserId = fm.FileActivityLogs.Where(y => y.Activity.NameOfActivity == "FileAllocation").Select(x => x.ApplicationUser.UserName).FirstOrDefault(),
                //                 StatusId = fm.FileActivityLogs.Where(y => y.Activity.NameOfActivity == "FileAllocation").Select(x => x.Status.Status).FirstOrDefault(),
                //                 //Completion=(10-7)/10*100,
                //             }).ToList();

                //files = data1.Where(x => x.ETD.Value.Date >= DateTime.Now.Date.AddDays(13) && x.ETD.Value.Date < DateTime.Now.Date.AddDays(19));
                SortedData = SortedData.Where(x => x.ETD.Value.Date >= DateTime.Now.Date.AddDays(13) && x.ETD.Value.Date < DateTime.Now.Date.AddDays(19) && x.StatusId != "Completed");
            }
            else
            {

                var hblIds = data.Where(x => x.FileNumber == fileNumber)
                 .SelectMany(x => x.HBLMasters.Select(y => y.Id))
                 .ToList();

                //files = data.Select(
                //   x => new FileDashModel
                //   {
                //       Id = x.Id,
                //       CountryName = x.Country.CountryName,
                //       FileNumber = x.FileNumber,
                //       ETD = x.Etd,
                //       DraftCutOff = x.DraftCutoff,
                //       CountofHBL = x.HBLMasters.Count(),
                //       ProcessedHBL = x.HBLMasters
                //                       .Where(y => y.FileId == x.Id)
                //                       .SelectMany(y => y.HBLActivityLogs.Select(log => log.HBLId))
                //                       .Distinct()
                //                       .Count(),
                //       PendingHBL = (x.HBLMasters.Count() - x.HBLMasters
                //                       .Where(y => y.FileId == x.Id)
                //                       .SelectMany(y => y.HBLActivityLogs.Select(log => log.HBLId))
                //                       .Distinct()
                //                       .Count()),
                //       UserId = x.FileActivityLogs.Where(y => y.Activity.NameOfActivity == "FileAllocation").Select(x => x.ApplicationUser.UserName).FirstOrDefault(),
                //       StatusId = x.FileActivityLogs.Where(y => y.Activity.NameOfActivity == "FileAllocation").Select(x => x.Status.Status).FirstOrDefault(),

                //   }).OrderBy(sortColumn + " " + sortColumnDirection).AsQueryable().ToList();

                SortedData = SortedData.OrderBy(sortColumn + " " + sortColumnDirection).AsQueryable();

            }


            // Return the data in the format required by DataTables
            return Json(new
            {
                draw = model.draw,
                recordsTotal = data.Count(),
                recordsFiltered = SortedData.Count(),
                data = SortedData,

            });
        }

        //Get HBL data by filenumber
        [HttpGet]
        public IActionResult GetHblData(string fileNumber)
        {
            var hbl = _context.HBLMaster.Where(x => x.File.FileNumber == fileNumber.Trim()).ToList();
            var sm = _context.StatusMaster.Where(x => x.IsActive == true && x.IsDelete == false).ToList();
            var fm = _context.FileActivityLog.Include(x => x.File).Include(x => x.Activity).Include(x => x.Status).Include(x => x.ApplicationUser).Where(x => x.File.FileNumber == fileNumber.Trim()).ToList();
            IQueryable<FileActivityLog> fileActivityLog = fm.AsQueryable();
            foreach (var item in fm)
            {
                fileActivityLog.Select(x => new FileActivityLog
                {
                    ActivityId = _context.FileActivityLog.Where(x => x.Activity.Id == item.ActivityId).Select(x => x.Activity.NameOfActivity).FirstOrDefault(),
                    StatusId = _context.FileActivityLog.Where(x => x.Status.Id == item.StatusId).Select(x => x.Status.Status).FirstOrDefault(),
                    UserId = _context.FileActivityLog.Where(x => x.ApplicationUser.Id == item.UserId).Select(x => x.ApplicationUser.UserName).FirstOrDefault(),

                }).ToList();
            }
            return Json(new { fm, hbl, sm });
        }
        //Get Hbl activity data
        [HttpGet]
        public IActionResult GetHblActivityData(string hblnumber)
        {
            var hblact = _context.HBLActivityLog.Include(x => x.Hbl).Include(x => x.Activity).Include(x => x.Status).Where(x => x.Hbl.HBLNumber == hblnumber.Trim()).ToList();
            IQueryable<HBLActivityLog> hblActivityLog = hblact.AsQueryable();
            foreach (var item in hblact)
            {
                hblActivityLog.Select(x => new HBLActivityLog
                {
                    ActivityId = _context.HBLActivityLog.Where(x => x.Activity.Id == item.ActivityId).Select(x => x.Activity.NameOfActivity).FirstOrDefault(),
                    StatusId = _context.HBLActivityLog.Where(x => x.Status.Id == item.StatusId).Select(x => x.Status.Status).FirstOrDefault(),
                    UserId = _context.HBLActivityLog.Where(x => x.ApplicationUser.Id == item.UserId).Select(x => x.ApplicationUser.UserName).FirstOrDefault(),

                }).ToList();
            }
            return Json(hblact);
        }
        //Get hbl dashboard count
        public JsonResult GetDashboardCount()
        {
            DashboardProdcount dp = new DashboardProdcount();
            try
            {
                var file = _context.FileMaster.Include(x => x.FileActivityLogs).ToList();
                var filelog = _context.FileActivityLog.Include(x => x.Activity).Include(x => x.Status).ToList();
                IQueryable<FileActivityLog> fileActivityLog = filelog.AsQueryable();
                IEnumerable<FileDashModel> files;

                files = _context.FileMaster.Include(x => x.Country).Include(x => x.HBLMasters)
                            .Include(x => x.FileActivityLogs).ThenInclude(x => x.Activity)
                            .Include(x => x.FileActivityLogs).ThenInclude(x => x.Status).Select(x => new FileDashModel
                            {
                                Id = x.Id,
                                CountryName = x.Country.CountryName,
                                FileNumber = x.FileNumber,
                                ETD = x.Etd,
                                DraftCutOff = x.DraftCutoff,
                                CountofHBL = x.HBLMasters.Count(),
                                ProcessedHBL = x.HBLMasters.Where(y => y.FileId == x.Id).SelectMany(y => y.HBLActivityLogs.Select(log => log.HBLId)).Distinct().Count(),
                                PendingHBL = (x.HBLMasters.Count() - x.HBLMasters.Where(y => y.FileId == x.Id).SelectMany(y => y.HBLActivityLogs.Select(log => log.HBLId)).Distinct().Count()),
                                UserId = x.FileActivityLogs.Where(y => y.Activity.NameOfActivity == "FileAllocation").Select(x => x.ApplicationUser.UserName).FirstOrDefault(),
                                StatusId = x.FileActivityLogs.Where(y => y.Activity.NameOfActivity == "FileAllocation").Select(x => x.Status.Status).FirstOrDefault(),

                            }).Distinct().AsQueryable();
                IQueryable<FileDashModel> SortedData = files.AsQueryable();
                dp = new DashboardProdcount
                {
                    Received = file.Count,
                    Pending = SortedData.Where(x => x.StatusId != "Completed" || x.StatusId != "Query").Count(),
                    WIP = SortedData.Where(x => x.StatusId == "WIP").Count(),
                    Query = SortedData.Where(x => x.StatusId == "Query").Count(),
                    Completed = SortedData.Where(x => x.StatusId == "Completed").Count(),
                    UnAllocated = _context.FileMaster.Except(_context.FileActivityLog.Select(fa => fa.File)).Count(),
                    etd10 = SortedData.Where(x => x.ETD != null && x.ETD.Value.Date >= DateTime.Now.Date && x.ETD.Value.Date < DateTime.Now.Date.AddDays(11) && x.StatusId != "Completed").Count(),
                    etd12 = SortedData.Where(x => x.ETD != null && x.ETD.Value.Date >= DateTime.Now.Date.AddDays(11) && x.ETD.Value.Date < DateTime.Now.Date.AddDays(13) && x.StatusId != "Completed").Count(),
                    etd18 = SortedData.Where(x => x.ETD != null && x.ETD.Value.Date >= DateTime.Now.Date.AddDays(13) && x.ETD.Value.Date < DateTime.Now.Date.AddDays(19) && x.StatusId != "Completed").Count(),
                };

            }
            catch (Exception ex)
            {


            }


            return Json(dp);
        }
        //Report
        [Authorize(Roles = "Supervisor,Manager")]
        public ActionResult Report()
        {
            return View();
        }

        //Report download
        [HttpPost]
        [Authorize(Roles = "Supervisor,Manager")]
        public ActionResult Report(ReportViewModel report)
        {
            //Main Report file and HBL also activity wise filelevel and hbllevel report
            //DataTable filedt = new DataTable();
            DataTable fileactivity = new DataTable();
            DataTable hbldt = new DataTable();
            //Adhoc Report 
            DataTable adhoc = new DataTable();
            DataTable adhocHBL = new DataTable();
            DataTable adhocfileActivity = new DataTable();
            DataTable adhochblActivity = new DataTable();
            var startDate = Convert.ToDateTime(report.start_date.ToString("MM/dd/yyyy"));
            var endDate = Convert.ToDateTime(report.end_date.ToString("MM/dd/yyyy"));
            const string ISTTimeZoneId = "India Standard Time";

            if(startDate == endDate)
            {
                startDate = startDate;
                endDate = endDate.AddDays(1);
            }

            if (report.ReportType == "MainReport")
            {
                //var filedata = _context.FileMaster.Where(x => x.EnterDate >= Convert.ToDateTime(report.start_date) && x.EnterDate <= Convert.ToDateTime(report.end_date))
                //           .Include(fm => fm.Country)
                //           .Include(fm => fm.HBLMasters)
                //           .Include(fm => fm.FileActivityLogs)
                //               .ThenInclude(fa => fa.Activity)
                //           .Include(fm => fm.FileActivityLogs)
                //               .ThenInclude(fa => fa.Status)
                //           .Include(fm => fm.FileActivityLogs)
                //               .ThenInclude(fa => fa.ApplicationUser)
                //           //.Where(fm => fm.FileActivityLogs.Any(fa => fa.Status.Status == "Completed"))
                //           .Select(fm => new FileDashModel
                //           {
                //               Id = fm.Id,
                //               CountryName = fm.Country.CountryName,
                //               FileNumber = fm.FileNumber,
                //               ETD = fm.Etd,
                //               DraftCutOff = fm.DraftCutoff,
                //               CountofHBL = fm.HBLMasters.Count(),
                //               ProcessedHBL=fm.HBLMasters
                //               .Where(y => y.FileId == fm.Id)
                //               .SelectMany(y => y.HBLActivityLogs.Select(log => log.HBLId))
                //               .Distinct()
                //               .Count(),
                //               PendingHBL=(fm.HBLMasters.Count()- fm.HBLMasters
                //               .Where(y => y.FileId == fm.Id)
                //               .SelectMany(y => y.HBLActivityLogs.Select(log => log.HBLId))
                //               .Distinct()
                //               .Count()),
                //               UserId=fm.FileActivityLogs.Where(y => y.Activity.NameOfActivity=="FileAllocation").Select(x => x.ApplicationUser.UserName).FirstOrDefault(),
                //               StatusId=fm.FileActivityLogs.Where(y => y.Activity.NameOfActivity=="FileAllocation").Select(x => x.Status.Status).FirstOrDefault(),

                //           })
                //           .ToList();

                if (report.DateType == "ReceivedDate")
                {
                    var fileactivtydata = (from fa in _context.FileActivityLog
                                           join fm in _context.FileMaster
                                           on fa.FileId equals fm.Id
                                           where (fm.EnterDate >= startDate && fm.EnterDate <= endDate)
                                           join am in _context.ActivityMaster
                                           on fa.ActivityId equals am.Id
                                           join um in _context.Users
                                           on fa.UserId equals um.Id
                                           select new FileDashModel
                                           {
                                               CountryName = fm.Country.CountryName,
                                               DraftCutOff = fm.DraftCutoff,
                                               ETD = fm.Etd,
                                               FileNumber = fm.FileNumber,
                                               ActivityId = am.NameOfActivity,
                                               StatusId = fa.Status.Status,
                                               Comment = fa.Comment,
                                               UserId = um.UserName,
                                               StartDate = fa.StartDate,
                                               EndDate = fa.EndDate
                                           }).ToList();

                    fileactivtydata = fileactivtydata.Select(x => new FileDashModel
                    {
                        CountryName = x.CountryName,
                        DraftCutOff = x.DraftCutOff.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.DraftCutOff.Value, TimeZoneInfo.FindSystemTimeZoneById(ISTTimeZoneId)) : (DateTime?)null,
                        ETD = x.ETD.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.ETD.Value, TimeZoneInfo.FindSystemTimeZoneById(ISTTimeZoneId)) : (DateTime?)null,
                        FileNumber = x.FileNumber,
                        ActivityId = x.ActivityId,
                        StatusId = x.StatusId,
                        Comment = x.Comment,
                        UserId = x.UserId,
                        StartDate = x.StartDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.StartDate.Value, TimeZoneInfo.FindSystemTimeZoneById(ISTTimeZoneId)) : (DateTime?)null,
                        EndDate = x.EndDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.EndDate.Value, TimeZoneInfo.FindSystemTimeZoneById(ISTTimeZoneId)) : (DateTime?)null,
                    }).ToList();

                    var HBLdata = (from ha in _context.HBLActivityLog
                                   join hm in _context.HBLMaster
                                   on ha.HBLId equals hm.Id
                                   join fa in _context.FileMaster
                                   on hm.FileId equals fa.Id
                                   where (hm.EnterDate >= startDate && hm.EnterDate <= endDate)
                                   join am in _context.ActivityMaster
                                   on ha.ActivityId equals am.Id
                                   join um in _context.Users
                                   on ha.UserId equals um.Id
                                   select new ReportTemplateModel
                                   {
                                       CountryName = fa.Country.CountryName,
                                       FileNumber = fa.FileNumber,
                                       Container = hm.Container,
                                       BookingNo = hm.Booking,
                                       ETD = fa.Etd,
                                       HBL_No = hm.HBLNumber,
                                       ActivityId = am.NameOfActivity,
                                       StatusId = ha.Status.Status,
                                       Comment = ha.Comment,
                                       UserId = um.UserName,
                                       EnterDate = hm.EnterDate,
                                       StartDate = ha.StartDate,
                                       EndDate = ha.EndDate,

                                   }).ToList();

                    HBLdata = HBLdata.Select(x => new ReportTemplateModel
                    {
                        CountryName = x.CountryName,
                        FileNumber = x.FileNumber,
                        Container = x.Container,
                        BookingNo = x.BookingNo,
                        ETD = x.ETD.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.ETD.Value, TimeZoneInfo.FindSystemTimeZoneById(ISTTimeZoneId)) : (DateTime?)null,
                        HBL_No = x.HBL_No,
                        ActivityId = x.ActivityId,
                        StatusId = x.StatusId,
                        Comment = x.Comment,
                        UserId = x.UserId,
                        EnterDate = x.EnterDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.EnterDate.Value, TimeZoneInfo.FindSystemTimeZoneById(ISTTimeZoneId)) : (DateTime?)null,
                        StartDate = x.StartDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.StartDate.Value, TimeZoneInfo.FindSystemTimeZoneById(ISTTimeZoneId)) : (DateTime?)null,
                        EndDate = x.EndDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.EndDate.Value, TimeZoneInfo.FindSystemTimeZoneById(ISTTimeZoneId)) : (DateTime?)null,

                    }).ToList();


                    //filedt = ToDataTable(filedata);
                    fileactivity = ToDataTable(fileactivtydata);
                    hbldt = ToDataTable(HBLdata);
                }
                else if ((report.DateType == "EndDate"))
                {
                    var fileactivtydata = (from fa in _context.FileActivityLog
                                           join fm in _context.FileMaster
                                           on fa.FileId equals fm.Id
                                           where (fa.EndDate >= startDate && fa.EndDate <= endDate)
                                           join am in _context.ActivityMaster
                                           on fa.ActivityId equals am.Id
                                           join um in _context.Users
                                           on fa.UserId equals um.Id
                                           select new FileDashModel
                                           {
                                               CountryName = fm.Country.CountryName,
                                               DraftCutOff = fm.DraftCutoff,
                                               ETD = fm.Etd,
                                               FileNumber = fm.FileNumber,
                                               ActivityId = am.NameOfActivity,
                                               StatusId = fa.Status.Status,
                                               Comment = fa.Comment,
                                               UserId = um.UserName,
                                               StartDate = fa.StartDate,
                                               EndDate = fa.EndDate
                                           }).ToList();

                    fileactivtydata = fileactivtydata.Select(x => new FileDashModel
                    {
                        CountryName = x.CountryName,
                        DraftCutOff = x.DraftCutOff.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.DraftCutOff.Value, TimeZoneInfo.FindSystemTimeZoneById(ISTTimeZoneId)) : (DateTime?)null,
                        ETD = x.ETD.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.ETD.Value, TimeZoneInfo.FindSystemTimeZoneById(ISTTimeZoneId)) : (DateTime?)null,
                        FileNumber = x.FileNumber,
                        ActivityId = x.ActivityId,
                        StatusId = x.StatusId,
                        Comment = x.Comment,
                        UserId = x.UserId,
                        StartDate = x.StartDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.StartDate.Value, TimeZoneInfo.FindSystemTimeZoneById(ISTTimeZoneId)) : (DateTime?)null,
                        EndDate = x.EndDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.EndDate.Value, TimeZoneInfo.FindSystemTimeZoneById(ISTTimeZoneId)) : (DateTime?)null,
                    }).ToList();

                    var HBLdata = (from ha in _context.HBLActivityLog
                                   join hm in _context.HBLMaster
                                   on ha.HBLId equals hm.Id
                                   join fa in _context.FileMaster
                                   on hm.FileId equals fa.Id
                                   where (ha.EndDate >= startDate && ha.EndDate <= endDate)
                                   join am in _context.ActivityMaster
                                   on ha.ActivityId equals am.Id
                                   join um in _context.Users
                                   on ha.UserId equals um.Id
                                   select new ReportTemplateModel
                                   {
                                       CountryName = fa.Country.CountryName,
                                       FileNumber = fa.FileNumber,
                                       Container = hm.Container,
                                       BookingNo = hm.Booking,
                                       ETD = fa.Etd,
                                       HBL_No = hm.HBLNumber,
                                       ActivityId = am.NameOfActivity,
                                       StatusId = ha.Status.Status,
                                       Comment = ha.Comment,
                                       UserId = um.UserName,
                                       EnterDate = hm.EnterDate,
                                       StartDate = ha.StartDate,
                                       EndDate = ha.EndDate,

                                   }).ToList();

                    HBLdata = HBLdata.Select(x => new ReportTemplateModel
                    {
                        CountryName = x.CountryName,
                        FileNumber = x.FileNumber,
                        Container = x.Container,
                        BookingNo = x.BookingNo,
                        ETD = x.ETD.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.ETD.Value, TimeZoneInfo.FindSystemTimeZoneById(ISTTimeZoneId)) : (DateTime?)null,
                        HBL_No = x.HBL_No,
                        ActivityId = x.ActivityId,
                        StatusId = x.StatusId,
                        Comment = x.Comment,
                        UserId = x.UserId,
                        EnterDate = x.EnterDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.EnterDate.Value, TimeZoneInfo.FindSystemTimeZoneById(ISTTimeZoneId)) : (DateTime?)null,
                        StartDate = x.StartDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.StartDate.Value, TimeZoneInfo.FindSystemTimeZoneById(ISTTimeZoneId)) : (DateTime?)null,
                        EndDate = x.EndDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.EndDate.Value, TimeZoneInfo.FindSystemTimeZoneById(ISTTimeZoneId)) : (DateTime?)null,

                    }).ToList();


                    //filedt = ToDataTable(filedata);
                    fileactivity = ToDataTable(fileactivtydata);
                    hbldt = ToDataTable(HBLdata);
                }
                else
                {
                    var fileactivtydata = (from fa in _context.FileActivityLog
                                           join fm in _context.FileMaster
                                           on fa.FileId equals fm.Id
                                           where (fa.StartDate >= startDate && fa.StartDate <= endDate)
                                           join am in _context.ActivityMaster
                                           on fa.ActivityId equals am.Id
                                           join um in _context.Users
                                           on fa.UserId equals um.Id
                                           select new FileDashModel
                                           {
                                               CountryName = fm.Country.CountryName,
                                               DraftCutOff = fm.DraftCutoff,
                                               ETD = fm.Etd,
                                               FileNumber = fm.FileNumber,
                                               ActivityId = am.NameOfActivity,
                                               StatusId = fa.Status.Status,
                                               Comment = fa.Comment,
                                               UserId = um.UserName,
                                               StartDate = fa.StartDate,
                                               EndDate = fa.EndDate
                                           }).ToList();

                    fileactivtydata = fileactivtydata.Select(x => new FileDashModel
                    {
                        CountryName = x.CountryName,
                        DraftCutOff = x.DraftCutOff.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.DraftCutOff.Value, TimeZoneInfo.FindSystemTimeZoneById(ISTTimeZoneId)) : (DateTime?)null,
                        ETD = x.ETD.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.ETD.Value, TimeZoneInfo.FindSystemTimeZoneById(ISTTimeZoneId)) : (DateTime?)null,
                        FileNumber = x.FileNumber,
                        ActivityId = x.ActivityId,
                        StatusId = x.StatusId,
                        Comment = x.Comment,
                        UserId = x.UserId,
                        StartDate = x.StartDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.StartDate.Value, TimeZoneInfo.FindSystemTimeZoneById(ISTTimeZoneId)) : (DateTime?)null,
                        EndDate = x.EndDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.EndDate.Value, TimeZoneInfo.FindSystemTimeZoneById(ISTTimeZoneId)) : (DateTime?)null,
                    }).ToList();


                    var HBLdata = (from ha in _context.HBLActivityLog
                                   join hm in _context.HBLMaster
                                   on ha.HBLId equals hm.Id
                                   join fa in _context.FileMaster
                                   on hm.FileId equals fa.Id
                                   where (ha.StartDate >= startDate && ha.StartDate <= endDate)
                                   join am in _context.ActivityMaster
                                   on ha.ActivityId equals am.Id
                                   join um in _context.Users
                                   on ha.UserId equals um.Id
                                   select new ReportTemplateModel
                                   {
                                       CountryName = fa.Country.CountryName,
                                       FileNumber = fa.FileNumber,
                                       Container = hm.Container,
                                       BookingNo = hm.Booking,
                                       ETD = fa.Etd,
                                       HBL_No = hm.HBLNumber,
                                       ActivityId = am.NameOfActivity,
                                       StatusId = ha.Status.Status,
                                       Comment = ha.Comment,
                                       UserId = um.UserName,
                                       EnterDate = hm.EnterDate,
                                       StartDate = ha.StartDate,
                                       EndDate = ha.EndDate,

                                   }).ToList();

                    HBLdata = HBLdata.Select(x => new ReportTemplateModel
                    {
                        CountryName = x.CountryName,
                        FileNumber = x.FileNumber,
                        Container = x.Container,
                        BookingNo = x.BookingNo,
                        ETD = x.ETD.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.ETD.Value, TimeZoneInfo.FindSystemTimeZoneById(ISTTimeZoneId)) : (DateTime?)null,
                        HBL_No = x.HBL_No,
                        ActivityId = x.ActivityId,
                        StatusId = x.StatusId,
                        Comment = x.Comment,
                        UserId = x.UserId,
                        EnterDate = x.EnterDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.EnterDate.Value, TimeZoneInfo.FindSystemTimeZoneById(ISTTimeZoneId)) : (DateTime?)null,
                        StartDate = x.StartDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.StartDate.Value, TimeZoneInfo.FindSystemTimeZoneById(ISTTimeZoneId)) : (DateTime?)null,
                        EndDate = x.EndDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.EndDate.Value, TimeZoneInfo.FindSystemTimeZoneById(ISTTimeZoneId)) : (DateTime?)null,

                    }).ToList();

                    //filedt = ToDataTable(filedata);
                    fileactivity = ToDataTable(fileactivtydata);
                    hbldt = ToDataTable(HBLdata);
                }


            }
            else
            {
                if (report.DateType == "ReceivedDate")
                {
                    var AdhocHBLactivitydata = (from ha in _context.AdhocHBLActivityLog
                                                join hm in _context.AdhocHBL
                                                on ha.AdhocHBLId equals hm.Id
                                                where (hm.EnterDate >= startDate && hm.EnterDate <= endDate)
                                                join am in _context.ActivityMaster
                                                on ha.ActivityId equals am.Id
                                                join um in _context.Users
                                                on ha.UserId equals um.Id
                                                join sm in _context.StatusMaster
                                                on ha.StatusId equals sm.Id
                                                join ca in _context.CountryMaster
                                                on hm.AdhocCountryId equals ca.Id
                                                select new AdhocReportModel
                                                {
                                                    AdhocFileNumber = hm.AdhocFileNumber,
                                                    AdhocContainer = hm.AdhocContainer,
                                                    AdhocBooking = hm.AdhocBooking,
                                                    AdhocHBLNumber = hm.AdhocHBLNumber,
                                                    Activity = am.NameOfActivity,
                                                    Status = sm.Status,
                                                    Comment = ha.Comment,
                                                    User = um.UserName,
                                                    EnterDate = hm.EnterDate,
                                                    StartDate = ha.StartDate,
                                                    EndDate = ha.EndDate,
                                                    ArrivedCBM = ha.ArrivedCBM,
                                                    BookingCBM = ha.BookingCBM,
                                                    ShippingType = ha.Shippingtype
                                                }).ToList();

                    adhochblActivity = ToDataTable(AdhocHBLactivitydata);

                    var fileactivitylog = _context.AdhocFileActivityLog.Include(x => x.Activity)
                                           .Include(x => x.Status)
                                           .Include(x => x.ApplicationUser)
                                           .Where(x => x.StartDate >= startDate && x.StartDate <= endDate)
                                           .Select(x => new AdhocFileActivityLog
                                           {
                                               AdhocFileId = x.AdhocFile.AdhocFileNumber,
                                               ActivityId = x.Activity.NameOfActivity,
                                               StatusId = x.Status.Status,
                                               UserId = x.ApplicationUser.UserName,
                                               Comment = x.Comment,
                                               StartDate = x.StartDate,
                                               EndDate = x.EndDate
                                           })
                                           .ToList();


                    adhocfileActivity = ToDataTable(fileactivitylog);
                }
                else if (report.DateType == "EndDate")
                {
                    var AdhocHBLactivitydata = (from ha in _context.AdhocHBLActivityLog
                                                join hm in _context.AdhocHBL
                                                on ha.AdhocHBLId equals hm.Id
                                                where (ha.EndDate >= startDate && ha.EndDate <= endDate)
                                                join am in _context.ActivityMaster
                                                on ha.ActivityId equals am.Id
                                                join um in _context.Users
                                                on ha.UserId equals um.Id
                                                join sm in _context.StatusMaster
                                                on ha.StatusId equals sm.Id
                                                join ca in _context.CountryMaster
                                                on hm.AdhocCountryId equals ca.Id
                                                select new AdhocReportModel
                                                {
                                                    AdhocFileNumber = hm.AdhocFileNumber,
                                                    AdhocContainer = hm.AdhocContainer,
                                                    AdhocBooking = hm.AdhocBooking,
                                                    AdhocHBLNumber = hm.AdhocHBLNumber,
                                                    Activity = am.NameOfActivity,
                                                    Status = sm.Status,
                                                    Comment = ha.Comment,
                                                    User = um.UserName,
                                                    EnterDate = hm.EnterDate,
                                                    StartDate = ha.StartDate,
                                                    EndDate = ha.EndDate,
                                                    ArrivedCBM = ha.ArrivedCBM,
                                                    BookingCBM = ha.BookingCBM,
                                                    ShippingType = ha.Shippingtype
                                                }).ToList();

                    adhochblActivity = ToDataTable(AdhocHBLactivitydata);

                    var fileactivitylog = _context.AdhocFileActivityLog.Include(x => x.Activity)
                                           .Include(x => x.Status)
                                           .Include(x => x.ApplicationUser)
                                           .Where(x => x.StartDate >= startDate && x.StartDate <= endDate)
                                           .Select(x => new AdhocFileActivityLog
                                           {
                                               AdhocFileId = x.AdhocFile.AdhocFileNumber,
                                               ActivityId = x.Activity.NameOfActivity,
                                               StatusId = x.Status.Status,
                                               UserId = x.ApplicationUser.UserName,
                                               Comment = x.Comment,
                                               StartDate = x.StartDate,
                                               EndDate = x.EndDate
                                           })
                                           .ToList();


                    adhocfileActivity = ToDataTable(fileactivitylog);
                }
                else
                {
                    var AdhocHBLactivitydata = (from ha in _context.AdhocHBLActivityLog
                                                join hm in _context.AdhocHBL
                                                on ha.AdhocHBLId equals hm.Id
                                                where (ha.StartDate >= startDate && ha.StartDate <= endDate)
                                                join am in _context.ActivityMaster
                                                on ha.ActivityId equals am.Id
                                                join um in _context.Users
                                                on ha.UserId equals um.Id
                                                join sm in _context.StatusMaster
                                                on ha.StatusId equals sm.Id
                                                join ca in _context.CountryMaster
                                                on hm.AdhocCountryId equals ca.Id
                                                select new AdhocReportModel
                                                {
                                                    AdhocFileNumber = hm.AdhocFileNumber,
                                                    AdhocContainer = hm.AdhocContainer,
                                                    AdhocBooking = hm.AdhocBooking,
                                                    AdhocHBLNumber = hm.AdhocHBLNumber,
                                                    Activity = am.NameOfActivity,
                                                    Status = sm.Status,
                                                    Comment = ha.Comment,
                                                    User = um.UserName,
                                                    EnterDate = hm.EnterDate,
                                                    StartDate = ha.StartDate,
                                                    EndDate = ha.EndDate,
                                                    ArrivedCBM = ha.ArrivedCBM,
                                                    BookingCBM = ha.BookingCBM,
                                                    ShippingType = ha.Shippingtype
                                                }).ToList();

                    adhochblActivity = ToDataTable(AdhocHBLactivitydata);

                    var fileactivitylog = _context.AdhocFileActivityLog.Include(x => x.Activity)
                                           .Include(x => x.Status)
                                           .Include(x => x.ApplicationUser)
                                           .Where(x => x.StartDate >= startDate && x.StartDate <= endDate)
                                           .Select(x => new AdhocFileActivityLog
                                           {
                                               AdhocFileId = x.AdhocFile.AdhocFileNumber,
                                               ActivityId = x.Activity.NameOfActivity,
                                               StatusId = x.Status.Status,
                                               UserId = x.ApplicationUser.UserName,
                                               Comment = x.Comment,
                                               StartDate = x.StartDate,
                                               EndDate = x.EndDate
                                           })
                                           .ToList();


                    adhocfileActivity = ToDataTable(fileactivitylog);
                }


            }

            //saveFile.Filter = "Excel files (*.xlsx)|*.xlsx";
            //saveFile.Filter = "Excel files (*.xlsx)";
            string filename = "";
            //filename = saveFile.FileName;
            string apath = filename + ".xlsx";
            using (XLWorkbook wb = new XLWorkbook())
            {
                if (report.ReportType == "MainReport")
                {
                    //filedt.TableName = "File Data";
                    fileactivity.TableName = "File Activity Data";
                    hbldt.TableName = "Hbl Activity Data";
                    //var wsFileData = wb.Worksheets.Add(filedt);
                    var wsfileactivitydata = wb.Worksheets.Add(fileactivity);

                    var wsHblData = wb.Worksheets.Add(hbldt);
                    // Auto-fit columns
                    wsfileactivitydata.Columns().AdjustToContents();
                    wsHblData.Columns().AdjustToContents();
                }
                else
                {
                    adhochblActivity.TableName = "adhochblActivity";
                    adhocfileActivity.TableName = "adhocfileActivity";

                    var wsFileData = wb.Worksheets.Add(adhochblActivity);
                    var wsfileactivity = wb.Worksheets.Add(adhocfileActivity);

                    // Auto-fit columns
                    wsFileData.Columns().AdjustToContents();
                    wsfileactivity.Columns().AdjustToContents();
                }

                try
                {
                    using (MemoryStream stream = new MemoryStream())
                    {
                        wb.SaveAs(stream);
                        string excelname = $"UserReport-{DateTime.Now.ToString("ddMMyyyy hh:mm:ss")}.xlsx";
                        return File(stream.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", excelname);
                    }
                }
                catch (Exception ex)
                {

                }
            }
            return View();
        }
        //List to data convert into datatable
        public DataTable ToDataTable<T>(List<T> items)
        {
            DataTable dataTable = new DataTable(typeof(T).Name);
            //Get all the properties by using reflection   
            PropertyInfo[] Props = typeof(T).GetProperties(BindingFlags.Public | BindingFlags.Instance);
            foreach (PropertyInfo prop in Props)
            {
                //Setting column names as Property names  
                dataTable.Columns.Add(prop.Name);
            }
            foreach (T item in items)
            {
                var values = new object[Props.Length];
                for (int i = 0; i < Props.Length; i++)
                {

                    values[i] = Props[i].GetValue(item, null);
                }
                dataTable.Rows.Add(values);
            }

            return dataTable;
        }

        //Get UserCount
        [Authorize(Roles = "Supervisor,Manager")]
        public ActionResult GetCountofUser()
        {

            return View();
        }
        //User wise data
        [HttpPost]
        public JsonResult GetUserDatacount()
        {
            var draw = Request.Form["draw"].FirstOrDefault();
            var sortColumn = Request.Form["columns[" + Request.Form["order[0][column]"].FirstOrDefault() + "][name]"].FirstOrDefault();
            var sortColumnDirection = Request.Form["order[0][dir]"].FirstOrDefault();
            List<ApplicationUser> udata = _context.Users.Where(x => x.IsActive == true && x.IsDelete == false).ToList();

            var result = _context.FileMaster
                        .Include(fm => fm.FileActivityLogs)
                            .ThenInclude(fa => fa.Activity)
                        .Include(fm => fm.FileActivityLogs)
                            .ThenInclude(fa => fa.Status)
                        .Include(fm => fm.FileActivityLogs)
                            .ThenInclude(fa => fa.ApplicationUser)
                        .Where(fm => fm.FileActivityLogs.Any(fa => fa.Status.Status != "Completed"))
                        .Select(fm => new
                        {
                            Id = fm.Id,
                            FileId = fm.FileNumber,
                            Countryname = fm.Country.CountryName,
                            ActivityName = fm.FileActivityLogs.Select(x => x.Activity.NameOfActivity),
                            StatusName = fm.FileActivityLogs.Select(x => x.Status.Status),
                            UserName = fm.FileActivityLogs.Select(x => x.ApplicationUser.UserName),

                        })
                        .ToList();


            var data = (from fm in _context.FileMaster
                        join fa in _context.FileActivityLog
                        on fm.Id equals fa.FileId
                        join am in _context.ActivityMaster
                        on fa.ActivityId equals am.Id
                        join um in _context.Users
                        on fa.UserId equals um.Id
                        select new FileDashModel
                        {
                            Id = fm.Id,
                            CountryName = fm.Country.CountryName,
                            DraftCutOff = fm.DraftCutoff,
                            ETD = fm.Etd,
                            FileNumber = fm.FileNumber,
                            ActivityId = am.NameOfActivity,
                            StatusId = fa.Status.Status,
                            Comment = fa.Comment,
                            UserId = um.UserName

                        });

            int totalRecord = 0;
            int filterRecord = 0;

            var returnObj = new
            {
                data = result//.Where(x => x.Username!=null)
            };

            return Json(returnObj);
        }

        //User wise production count
        [HttpPost]
        public JsonResult GetUserDataProdcount()
        {
            var draw = Request.Form["draw"].FirstOrDefault();
            var sortColumn = Request.Form["columns[" + Request.Form["order[0][column]"].FirstOrDefault() + "][name]"].FirstOrDefault();
            var sortColumnDirection = Request.Form["order[0][dir]"].FirstOrDefault();
            List<ApplicationUser> udata = _context.Users.ToList();
            List<FileActivityLog> fdata = _context.FileActivityLog.Include(x => x.Status).ToList();
            var result = (from c in fdata
                          group (c.UserId) by c.UserId into g
                          select new
                          {
                              Username = udata.Where(x => x.Id == g.Key).Select(x => x.FirstName + " " + x.LastName).FirstOrDefault(),
                              Total = fdata.Where(x => x.UserId == g.Key).Count(),
                              WIP = fdata.Where(x => x.UserId == g.Key && x.Status.Status.ToString() == "WIP").Count(),
                              Pending = fdata.Where(x => x.UserId == g.Key && (x.Status.Status.ToString() != "Completed" || x.Status.Status.ToString() != "WIP")).Count(),
                              Completed = fdata.Where(x => x.UserId == g.Key && x.Status.Status.ToString() == "Completed").Count()
                          });



            int totalRecord = 0;
            int filterRecord = 0;

            var returnObj = new
            {
                data = result.Distinct().Where(x => x.Username != null)
            };

            return Json(returnObj);
        }

        //FileAllocation Funcation
        [Authorize(Roles = "Supervisor,Manager")]
        public JsonResult FileAllocation(string[] fileNumbers, string activity, string user, string status)
        {
            try
            {
                if (fileNumbers.Length == 0)
                {
                    return Json("Please select file checkbox");
                }
                else if (activity == null)
                {
                    return Json("Please select activities");
                }
                else if (user == null)
                {
                    return Json("Please select user");
                }
                else
                {
                    foreach (string fileid in fileNumbers)
                    {
                        var compstatusId = _context.StatusMaster.Where(x => x.Status == "Completed" && x.IsActive == true && x.IsDelete == false).Select(x => x.Id).FirstOrDefault();
                        var fileactivity = _context.FileActivityLog.Where(x => x.FileId == fileid && x.ActivityId == activity.Trim()).FirstOrDefault();
                        var statusId = _context.StatusMaster.Where(x => x.Status == "WIP" && x.IsActive == true && x.IsDelete == false).Select(x => x.Id).FirstOrDefault();
                        if (fileactivity != null)
                        {
                            if (fileactivity.StatusId == compstatusId)
                            {
                                return Json("File activity status is completed so does not allocate");
                            }
                            else
                            {
                                FileAcitivityLogHistory fileActivitylogHistory = new FileAcitivityLogHistory
                                {
                                    FileLogId = fileactivity.Id,
                                    ActivityId = fileactivity.ActivityId,
                                    StatusId = fileactivity.StatusId,
                                    UserId = fileactivity.UserId,
                                    Comment = fileactivity.Comment,
                                    StartDate = fileactivity.StartDate,
                                    EndDate = fileactivity.EndDate,

                                };
                                _context.FileAcitivityLogHistory.Add(fileActivitylogHistory);
                                if (fileactivity.UserId == user)
                                {
                                    return Json("Same User");
                                }
                                else
                                {
                                    fileactivity.UserId = user;
                                    _context.FileActivityLog.Update(fileactivity);
                                    _context.SaveChanges();
                                }
                            }
                        }
                        else
                        {
                            FileActivityLog fileActivityLogs = new FileActivityLog
                            {
                                UserId = user.Trim(),
                                StatusId = statusId,
                                ActivityId = activity.Trim(),
                                FileId = fileid,
                            };
                            _context.FileActivityLog.Add(fileActivityLogs);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                return Json("error");
            }
            _context.SaveChanges();
            return Json("Success");

        }

        //Assign role to user
        [HttpPost]
        [Authorize(Roles = "Supervisor,Manager")]
        public JsonResult AssignRole([FromBody] UserRoleViewModel userrole)
        {
            string Msg = null;
            var user = _context.Users.Where(x => x.IsActive == true && x.IsDelete == false).FirstOrDefault(x => x.EmpId == Convert.ToInt32(userrole.UserId));
            if (user == null)
            {
                Msg = "User not found";
                return Json(new { Msg });
            }

            var userRole = _context.UserRoles.FirstOrDefault(x => x.UserId == user.Id);
            if (userRole != null)
            {
                _context.UserRoles.Remove(userRole);
                _context.SaveChanges();
                _context.UserRoles.Add(new IdentityUserRole<string>
                {
                    RoleId = userrole.RoleId,
                    UserId = user.Id
                });
            }
            else
            {
                _context.UserRoles.Add(new IdentityUserRole<string>
                {
                    RoleId = userrole.RoleId,
                    UserId = user.Id
                });
            }
            _context.SaveChanges();
            Msg = "User role updated successfully";

            return Json(Msg);
        }


        [Authorize(Roles = "Supervisor,Manager")]
        public JsonResult ActivateActivity(string Id)
        {
            string message = "";
            if (Id != null)
            {
                ActivityMaster master = _context.ActivityMaster.Where(x => x.Id == Id).FirstOrDefault();
                if (master != null)
                {
                    master.IsActive = master.IsActive != null ? !master.IsActive : true;
                    //master.IsDelete = master.IsDelete != null ? !master.IsDelete : true;
                    _context.ActivityMaster.Update(master);
                    _context.SaveChanges();
                    message = master.IsActive == true ? master.NameOfActivity + " Activity Activated!" : master.NameOfActivity + " Activity Deactivated!";

                }
                else
                {
                    message = "Error in Activation.!";
                }
            }
            return Json(message);
        }

        [Authorize(Roles = "Supervisor,Manager")]
        public JsonResult DeleteActivity(string Id)
        {
            string message = "";
            if (Id != null)
            {
                ActivityMaster master = _context.ActivityMaster.Where(x => x.Id == Id).FirstOrDefault();
                if (master != null)
                {
                    //master.IsActive = master.IsActive != null ? !master.IsActive : true;
                    master.IsDelete = master.IsDelete != null ? !master.IsDelete : true;
                    _context.ActivityMaster.Update(master);
                    _context.SaveChanges();
                    message = master.IsActive == true ? master.NameOfActivity + " Activity Deleted!" : master.NameOfActivity + " Activity Restore!";

                }
                else
                {
                    message = "Error in Activation.!";
                }
            }
            return Json(message);
        }

        [Authorize(Roles = "Supervisor,Manager")]
        public JsonResult ActivateStatus(string Id)
        {
            string message = "";
            if (Id != null)
            {
                StatusMaster master = _context.StatusMaster.Where(x => x.Id == Id).FirstOrDefault();
                if (master != null)
                {
                    master.IsActive = master.IsActive != null ? !master.IsActive : true;
                    //master.IsDelete = master.IsDelete != null ? !master.IsDelete : true;
                    _context.StatusMaster.Update(master);
                    _context.SaveChanges();
                    message = master.IsActive == true ? master.Status + " Status Activated!" : master.Status + " Status Deactivated!";

                }
                else
                {
                    message = "Error in Activation.!";
                }
            }
            return Json(message);
        }

        [Authorize(Roles = "Supervisor,Manager")]
        public JsonResult DeleteStatus(string Id)
        {
            string message = "";
            if (Id != null)
            {
                StatusMaster master = _context.StatusMaster.Where(x => x.Id == Id).FirstOrDefault();
                if (master != null)
                {
                    //master.IsActive = master.IsActive != null ? !master.IsActive : true;
                    master.IsDelete = master.IsDelete != null ? !master.IsDelete : true;
                    _context.StatusMaster.Update(master);
                    _context.SaveChanges();
                    message = master.IsActive == true ? master.Status + " Status Deleted!" : master.Status + " Status Restore!";


                }
                else
                {
                    message = "Error in Activation.!";
                }
            }
            return Json(message);
        }

        [Authorize(Roles = "Supervisor,Manager")]
        public JsonResult ActivateCountry(string Id)
        {
            string message = "";
            if (Id != null)
            {
                CountryMaster master = _context.CountryMaster.Where(x => x.Id == Id).FirstOrDefault();
                if (master != null)
                {
                    master.IsActive = master.IsActive != null ? !master.IsActive : true;
                    //master.IsDelete = master.IsDelete != null ? !master.IsDelete : true;
                    _context.CountryMaster.Update(master);
                    _context.SaveChanges();
                    message = master.IsActive == true ? master.CountryName + " Country Activated!" : master.CountryName + " Country Deactivated!";


                }
                else
                {
                    message = "Error in Activation.!";
                }
            }
            return Json(message);
        }

        [Authorize(Roles = "Supervisor,Manager")]
        public JsonResult DeleteCountry(string Id)
        {
            string message = "";
            if (Id != null)
            {
                CountryMaster master = _context.CountryMaster.Where(x => x.Id == Id).FirstOrDefault();
                if (master != null)
                {
                    //master.IsActive = master.IsActive != null ? !master.IsActive : true;
                    master.IsDelete = master.IsDelete != null ? !master.IsDelete : true;
                    _context.CountryMaster.Update(master);
                    _context.SaveChanges();
                    message = master.IsActive == true ? master.CountryName + " Country Deleted!" : master.CountryName + " Country Restore!";


                }
                else
                {
                    message = "Error in Activation.!";
                }
            }
            return Json(message);
        }

        [Authorize(Roles = "Supervisor,Manager")]
        public JsonResult ActivateUser(string Id)
        {
            string message = "";
            if (Id != null)
            {
                ApplicationUser master = _context.Users.Where(x => x.CitrixId == Id).FirstOrDefault();
                if (master != null)
                {
                    master.IsActive = master.IsActive != null ? !master.IsActive : true;
                    //master.IsDelete = master.IsDelete != null ? !master.IsDelete : true;
                    _context.Users.Update(master);
                    _context.SaveChanges();
                    message = master.IsActive == true ? master.CitrixId + " User Activated!" : master.CitrixId + " User Deactivated!";



                }
                else
                {
                    message = "Error in Activation.!";
                }
            }
            return Json(message);
        }

        [Authorize(Roles = "Supervisor,Manager")]
        public JsonResult DeleteUser(string Id)
        {
            string message = "";
            if (Id != null)
            {
                ApplicationUser master = _context.Users.Where(x => x.CitrixId == Id).FirstOrDefault();
                if (master != null)
                {
                    //master.IsActive = master.IsActive != null ? !master.IsActive : true;
                    master.IsDelete = master.IsDelete != null ? !master.IsDelete : true;
                    _context.Users.Update(master);
                    _context.SaveChanges();
                    message = master.IsActive == true ? master.CitrixId + " User Deleted!" : master.CitrixId + " User Restore!";


                }
                else
                {
                    message = "Error in Activation.!";
                }
            }
            return Json(message);
        }

    }
}

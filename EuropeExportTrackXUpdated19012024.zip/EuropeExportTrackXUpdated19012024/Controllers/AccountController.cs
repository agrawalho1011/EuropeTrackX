﻿using EuropeTrackX.DataModel;
using EuropeTrackX.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;

namespace EuropeTrackX.Controllers
{
    public class AccountController : Controller
    {
        private readonly UserManager<ApplicationUser> userManger;
        private readonly SignInManager<ApplicationUser> signInManager;
        private readonly RoleManager<IdentityRole> roleManager;
        public ApplicationDBContext _ctx;

        //// Login and Registration using credentials 
        public AccountController(UserManager<ApplicationUser> userManger, SignInManager<ApplicationUser> signInManager, RoleManager<IdentityRole> roleManager, ApplicationDBContext ctx)
        {
            this.userManger = userManger;
            this.signInManager = signInManager;
            this.roleManager = roleManager;
            _ctx = ctx;
        }
        //Login
        [HttpGet]
        public IActionResult Login()
        {
            return View(new LoginViewModel());
        }

        [Authorize(Roles = "Supervisor,Manager")]
        [HttpGet]
        public IActionResult Index()
        {
            //ViewBag.Roles = roleManager.Roles.ToList();
            //var roles = roleManager.Roles.ToList();
            // Debug or print 'roles' to inspect its contents
            ViewData["Roles"] = _ctx.Roles.ToList();
            ViewData["User"] = _ctx.Users.OrderBy(x => x.UserName).ToList();
            var result = _ctx.Users.Select(x => new RegisterViewModel
            {
                FirstName = x.FirstName,
                LastName = x.LastName,
                UserName = x.UserName,
                CitrixId = x.CitrixId,
                EmpId = x.EmpId,
                IsActive = x.IsActive,
                IsDelete = x.IsDelete,
                Role = _ctx.UserRoles.Where(y => y.UserId == x.Id).FirstOrDefault().RoleId
            }).Where(x => x.IsDelete == false).ToList();
            return View(result);
        }

        //Login to application user and supervisor roles
        [HttpPost]
        public async Task<IActionResult> Login(LoginViewModel model)
        {

            if (ModelState.IsValid)
            {
                var result = await signInManager.PasswordSignInAsync(model.CitrixId, model.Password, false, false);
                if (result.Succeeded)
                {
                    var user = await userManger.FindByNameAsync(model.CitrixId);
                    var roles = await userManger.GetRolesAsync(user);
                    if (roles.Count != 0)
                    {
                        if (roles[0].ToString() == "Supervisor" || roles[0].ToString() == "Manager")
                        {
                            return RedirectToAction("Index", "Dashboard");
                        }
                        else if (roles[0].ToString() == "User")
                        {
                            return RedirectToAction("Index", "User");
                        }
                        else
                        {
                            return NotFound();
                        }
                    }
                }
                //ModelState.AddModelError("Invalid Login Attempt", "Invalid Login Attempt");
                //return View(model);
                ModelState.AddModelError("", "Invalid Login Attempt");
                return View(model);
            }
            else
            {
                ModelState.AddModelError(string.Empty, "Invalid login attempt.");
                return View(model);
            }
        }
        //Register 
        [HttpGet]
        [Authorize(Roles = "Supervisor,Manager")]
        public IActionResult Register()
        {
            ViewData["Roles"] = roleManager.Roles.ToList();
            return View(new RegisterViewModel());
        }
        //Registration of user
        //[HttpPost]
        //public async Task<IActionResult> Register(RegisterViewModel model)
        //{			
        //	Console.Write("--------------------------------------------------------------");
        //	Console.Write(model.Role);
        //	if (ModelState.IsValid)
        //	{
        //		var userList = _ctx.Users.Where(x => x.CitrixId.ToLower() == model.CitrixId.ToLower() || x.UserName.ToLower() == model.UserName.ToLower() || x.EmpId == model.EmpId).ToList();
        //		if(userList == null)
        //		{
        //                  var user = new ApplicationUser
        //                  {
        //                      CitrixId = model.UserName,
        //                      EmpId = model.EmpId,
        //                      UserName = model.UserName,
        //                      FirstName = model.FirstName,
        //                      LastName = model.LastName,
        //                      IsActive = true,
        //                      IsDelete = false,
        //                      NormalizedUserName = model.UserName.ToUpper()
        //                  };

        //                  var roleId = _ctx.Roles.Where(x => x.Name == model.Role).Select(x => x.Id).FirstOrDefault();

        //                  _ctx.UserRoles.Add(new IdentityUserRole<string>
        //                  {
        //                      RoleId = roleId,
        //                      UserId = user.Id,
        //                  });

        //                  var result = await userManger.CreateAsync(user);
        //                  _ctx.SaveChanges();
        //                  if (result.Succeeded)
        //                  {
        //                      //await userManger.AddToRoleAsync(user, model.Role);

        //                      return RedirectToAction("Index", "Account");
        //                  }
        //                  foreach (var error in result.Errors)
        //                  {
        //                      ModelState.AddModelError("", error.Description);
        //                  }
        //		}
        //		else
        //		{
        //                  return Json("UserName,CitrixId or EmpId Already Exist.");
        //              }

        //	}

        //	return View(model);
        //}

        [HttpPost]
        public async Task<IActionResult> Register(RegisterViewModel model)
        {
            if (ModelState.IsValid)
            {
                //var userList = _ctx.Users
                //    .Where(x => x.CitrixId.ToLower() == model.CitrixId.ToLower() ||
                //                x.UserName.ToLower() == model.UserName.ToLower() ||
                //                x.EmpId == model.EmpId)
                //    .ToList();

                var userList = _ctx.Users.Where(x => x.CitrixId.ToLower() == model.UserName.ToLower() ||
                                x.UserName.ToLower() == model.UserName.ToLower() ||
                                x.EmpId == model.EmpId).ToList();

                if (userList == null || userList.Count == 0)
                {
                    var user = new ApplicationUser
                    {
                        CitrixId = model.UserName,
                        EmpId = model.EmpId,
                        UserName = model.UserName,
                        FirstName = model.FirstName,
                        LastName = model.LastName,
                        IsActive = true,
                        IsDelete = false,
                        NormalizedUserName = model.UserName.ToUpper()
                    };

                    var roleId = _ctx.Roles
                        .Where(x => x.Name == model.Role)
                        .Select(x => x.Id)
                        .FirstOrDefault();

                    _ctx.UserRoles.Add(new IdentityUserRole<string>
                    {
                        RoleId = roleId,
                        UserId = user.Id,
                    });

                    var result = await userManger.CreateAsync(user);

                    _ctx.SaveChanges();

                    if (result.Succeeded)
                    {
                        return Json(new { success = true, message = "User registered successfully." });
                    }

                    foreach (var error in result.Errors)
                    {
                        ModelState.AddModelError("", error.Description);
                    }
                }
                else
                {
                    return Json(new { success = false, message = "UserName, CitrixId or EmpId already exists." });
                }
            }

            return View(model);
        }


        //Update the roles
        [HttpPost]
        [Authorize(Roles = "Supervisor,Manager")]
        public async Task<JsonResult> UpdateRole(UpdateRoleModel data)
        {
            var user = _ctx.Users.Where(x => x.CitrixId == data.CitrixId && x.IsActive == true && x.IsDelete == false).FirstOrDefault();
            var userrole = _ctx.UserRoles.Where(x => x.UserId == user.Id).FirstOrDefault();

            if (user != null)
            {
                try
                {
                    _ctx.Remove(userrole);
                    _ctx.UserRoles.Add(new IdentityUserRole<string>
                    {
                        RoleId = data.RoleId,
                        UserId = user.Id,
                    });

                    _ctx.SaveChanges();
                }
                catch (Exception ex) { }
                return Json("success");
            }
            else
            {
                return Json("failed");
            }

        }

        [HttpGet]
        [Authorize(Roles = "Supervisor,Manager")]
        public IActionResult EditUser(string Uname)
        {
            ViewData["EditUser"] = _ctx.Users.Where(x => x.CitrixId.ToLower() == Uname.Trim().ToLower()).FirstOrDefault();

            return PartialView();
        }

        [HttpPost]
        public async Task<JsonResult> EditUser(ApplicationUser model)
        {
            var uname = _ctx.Users.Where(x => x.Id == model.Id).FirstOrDefault();
            if (uname != null)
            {
                uname.FirstName = model.FirstName.Trim();
                uname.LastName = model.LastName.Trim();
                uname.UserName = model.UserName.Trim();
                uname.CitrixId = model.CitrixId.Trim();
                uname.EmpId = model.EmpId;
                uname.NormalizedUserName = model.CitrixId.ToUpper().Trim();
                _ctx.Users.Update(uname);
                _ctx.SaveChanges();
                return Json("Updated Successfully..!");
            }
            else
            {
                return Json("Error while processing the request");
            }
        }


        //Register 
        [HttpGet]
        public IActionResult RegisterMe()
        {
            ViewBag.Roles = roleManager.Roles.Where(x => x.Name == "User").ToList();
            return View(new RegisterViewModel());
        }

        [HttpPost]
        public async Task<IActionResult> RegisterMe(RegisterViewModel model)
        {
            if (ModelState.IsValid) { 

                var userList = _ctx.Users.Where(x => x.CitrixId.ToLower() == model.UserName.ToLower() ||
                                x.UserName.ToLower() == model.UserName.ToLower() ||
                                x.EmpId == model.EmpId).ToList();

                if (userList == null || userList.Count == 0)
                {
                    var user = new ApplicationUser
                    {
                        CitrixId = model.UserName,
                        EmpId = model.EmpId,
                        UserName = model.UserName,
                        FirstName = model.FirstName,
                        LastName = model.LastName,
                        IsActive = true,
                        IsDelete = false,
                        NormalizedUserName = model.UserName.ToUpper()
                    };

                    var roleId = _ctx.Roles
                        .Where(x => x.Name == model.Role)
                        .Select(x => x.Id)
                        .FirstOrDefault();

                    _ctx.UserRoles.Add(new IdentityUserRole<string>
                    {
                        RoleId = roleId,
                        UserId = user.Id,
                    });

                    var result = await userManger.CreateAsync(user);

                    _ctx.SaveChanges();

                    if (result.Succeeded)
                    {
                        return Json(new { success = true, message = "User registered successfully." });
                    }

                    foreach (var error in result.Errors)
                    {
                        ModelState.AddModelError("", error.Description);
                    }
                }
                else
                {
                    return Json(new { success = false, message = "UserName, CitrixId or EmpId already exists." });
                }
            }

            return View(model);
        }

        //Logout application
        public async Task<IActionResult> Logout()
        {
            await signInManager.SignOutAsync();
            return RedirectToAction("Login", "Account");
        }
    }
}

﻿using EuropeTrackX.DataModel;
using EuropeTrackX.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;
using System.Linq.Dynamic.Core;
using Microsoft.AspNetCore.Authorization;
using System.Data;
using System.Reflection;
using ClosedXML.Excel;

namespace EuropeTrackX.Controllers
{
    //User
    [Authorize]
    public class UserController : Controller
    {
        ApplicationDBContext _context;
        private readonly IHttpContextAccessor _httpContextAccessor;
        //User roles to access services
        public UserController(ApplicationDBContext context, IHttpContextAccessor httpContextAccessor)
        {
            _context = context;
            _httpContextAccessor = httpContextAccessor;
        }
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Files()
        {
            ViewData["Activity"] = _context.ActivityMaster.Where(x => x.IsActive == true && x.IsDelete == false).ToList();
            ViewData["Country"] = _context.CountryMaster.Where(x => x.IsActive == true && x.IsDelete == false).ToList();
            ViewData["User"] = _context.Users.Where(x => x.IsActive == true && x.IsDelete == false).ToList();
            return View();
        }

        //Add Activity 
        [HttpPost]
        public IActionResult AddActivity(FileActivityLogModel fileActivity)
        {
            string Msg = "";
            if (ModelState.IsValid)
            {
                //Find the activity by activity Id and File Id
                var fileactivityIsexits = _context.FileActivityLog.Where(x => x.ActivityId == fileActivity.ActivityId && x.FileId == fileActivity.FileId).FirstOrDefault();

                if (fileactivityIsexits == null)
                {
                    _context.FileActivityLog.Add(new FileActivityLog
                    {
                        Id = fileActivity.Id,
                        FileId = fileActivity.FileId,
                        ActivityId = fileActivity.ActivityId,
                        StatusId = fileActivity.StatusId,
                        Comment = fileActivity.Comment,
                        UserId = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier),
                        StartDate = DateTime.UtcNow,
                        EndDate = DateTime.UtcNow,
                    });
                    Msg = "";
                    _context.SaveChanges();

                    return Json(fileActivity.FileId);
                }
                else
                {
                    //Adding in  File AcitivityLog History table 
                    _context.FileAcitivityLogHistory.Add(new FileAcitivityLogHistory
                    {
                        FileLogId = fileactivityIsexits.Id,
                        ActivityId = fileactivityIsexits.ActivityId,
                        StatusId = fileactivityIsexits.StatusId,
                        Comment = fileactivityIsexits.Comment,
                        UserId = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier),
                        StartDate = DateTime.UtcNow,
                        EndDate = DateTime.UtcNow,
                    });

                    fileactivityIsexits.StatusId = fileActivity.StatusId;
                    fileactivityIsexits.Comment = fileActivity.Comment;
                    fileactivityIsexits.StartDate = DateTime.UtcNow;
                    fileactivityIsexits.EndDate = DateTime.UtcNow;
                    fileactivityIsexits.UserId = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);

                    Msg = "Status Update Successfully.";
                    _context.SaveChanges();

                    return Json(Msg);
                }
            }
            else
            {
                return Json("Something went wrong");
            }
        }
        //Get data from FileActivityLog table
        [HttpGet]
        public IActionResult FileActivity(string Id)
        {
            ViewData["fileId"] = Id;
            ViewData["fileDtls"] = _context.FileMaster.Where(x => x.Id == Id).Include(x => x.Country).FirstOrDefault();

            ViewData["FileActivityList"] = _context.FileActivityLog.Where(x => x.FileId == Id)
                                                        .Include(x => x.Activity).Include(x => x.Status).Include(x => x.ApplicationUser)
                                                        .Select(x => new FileActivityLogModel
                                                        {
                                                            Id = x.Id,
                                                            FileId = x.File.Id,
                                                            ActivityId = x.ActivityId,
                                                            ActivityName = x.Activity.NameOfActivity,
                                                            StatusId = x.StatusId,
                                                            StatusName = x.Status.Status,
                                                            UserId = x.UserId,
                                                            UserName = x.ApplicationUser.UserName,
                                                            Comment = x.Comment,
                                                            StartDate = x.StartDate,
                                                            EndDate = x.EndDate,
                                                        }).ToList();
            ViewBag.Activity = _context.ActivityMaster.Where(x => x.ActivityType == "File" && x.Source == "Upload" && x.IsActive == true && x.IsDelete == false).ToList();
            ViewBag.Status = _context.StatusMaster.Where(x => x.IsActive == true && x.IsDelete == false).ToList();

            return PartialView();
        }
        //Get HBL Data 
        [HttpGet]
        public IActionResult HBL(string fileNumber)
        {
            IEnumerable<HBLUserViewModel> data = null;

            if (fileNumber != null)
            {
                data = _context.HBLMaster.Include(x => x.File).Where(x => x.File.FileNumber == fileNumber).Select(x =>
                new HBLUserViewModel
                {
                    Id = x.Id,
                    FileNo = x.File.FileNumber,
                    BookingNo = x.Booking,
                    HBL_No = x.HBLNumber,
                    CountryName = x.File.Country.CountryName,
                    CustomerName = x.CustomerName,

                });
            }
            else
            {
                data = _context.HBLMaster.Include(x => x.File).Select(x =>
                new HBLUserViewModel
                {
                    Id = x.Id,
                    FileNo = x.File.FileNumber,
                    BookingNo = x.Booking,
                    HBL_No = x.HBLNumber,
                    CountryName = x.File.Country.CountryName,
                    CustomerName = x.CustomerName,
                });
            }
            var count = data.Count();
            ViewData["Activity"] = _context.ActivityMaster.Where(x => x.ActivityType == "HBL" && x.Source == "Upload" && x.IsActive == true && x.IsDelete == false).ToList();
            ViewData["Status"] = _context.StatusMaster.Where(x => x.IsActive == true && x.IsDelete == false).ToList();
            ViewData["Country"] = _context.CountryMaster.Where(x => x.IsActive == true && x.IsDelete == false).ToList();
            ViewData["User"] = _context.Users.Where(x => x.IsActive == true && x.IsDelete == false).ToList();
            ViewData["fileNumber"] = fileNumber;
            return View(data);
        }
        //Get files data search and filter data
        [HttpPost]
        public IActionResult GetFiles(DataTableAjaxPostModel model, string country, string fileNumber, string status, string activity, string hBLNumber)
        {
            var draw = model.draw;
            var sortColumn = string.IsNullOrEmpty(model.columns[model.order[0].column].data) ? "id" : model.columns[model.order[0].column].data;
            var sortColumnDirection = model.order[0].dir;
            var searchValue = model.search.value;
            int pageSize = model.length.HasValue ? model.length.Value : 100;
            int skip = model.start.HasValue ? model.start.Value : 0;
            var role = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.Role);

            ViewBag.Status = _context.StatusMaster.ToList();

            if (role != "User")
            {  // Get the data for the DataTable
               //var data = _context.FileMaster.Include(x => x.Country).Include(x => x.FileActivityLogs).AsQueryable();
                var data = (from fa in _context.FileActivityLog
                            join fm in _context.FileMaster
                            on fa.FileId equals fm.Id
                            join am in _context.ActivityMaster
                            on fa.ActivityId equals am.Id
                            join um in _context.Users
                            on fa.UserId equals um.Id
                            select new FileDashModel
                            {
                                Id = fm.Id,
                                CountryName = fm.Country.CountryName,
                                DraftCutOff = fm.DraftCutoff,
                                ETD = fm.Etd,
                                FileNumber = fm.FileNumber,
                                ActivityId = am.NameOfActivity,
                                StatusId = fa.Status.Status,
                                Comment = fa.Comment,
                                UserId = um.UserName

                            });

                if (!string.IsNullOrEmpty(country) && country != "-- Select Country --")
                {
                    data = data.Where(x => x.CountryName.Contains(country.Trim()));
                }
                if (!string.IsNullOrEmpty(fileNumber))
                {
                    data = data.Where(x => x.FileNumber.Contains(fileNumber.Trim()));
                }
                if (!string.IsNullOrEmpty(status))
                {
                    data = data.Where(x => x.StatusId.Contains(status.Trim()));
                }
                if (!string.IsNullOrEmpty(activity))
                {
                    data = data.Where(x => x.ActivityId.Contains(activity.Trim()));
                }

                IEnumerable<FileDashModel> files = data.Select(
                    x => new FileDashModel
                    {
                        Id = x.Id,
                        CountryName = x.CountryName,
                        FileNumber = x.FileNumber,
                        ETD = x.ETD,
                        DraftCutOff = x.DraftCutOff,
                        ActivityId = x.ActivityId,
                        UserId = x.UserId,
                        StatusId = x.StatusId,
                        Comment = x.Comment,
                    }).OrderBy(sortColumn + " " + sortColumnDirection).AsQueryable().ToList();
                return Json(new
                {
                    draw = model.draw,
                    recordsTotal = files.Count(),
                    recordsFiltered = files.Count(),
                    data = files
                });
            }
            else
            {
                // Get the data for the DataTable
                var data = _context.FileActivityLog
                          .Include(x => x.File)
                          .Include(x => x.Activity)
                          .Include(x => x.Status)
                          .Include(x => x.ApplicationUser)
                          .Where(x => x.ApplicationUser.UserName == User.Identity.Name)
                          .Select(x => new FileDashModel
                          {
                              Id = x.Activity.Id,
                              CountryName = x.File.Country.CountryName,
                              DraftCutOff = x.File.DraftCutoff,
                              ETD = x.File.Etd,
                              FileNumber = x.File.FileNumber,
                              ActivityId = x.Activity.NameOfActivity,
                              StatusId = x.Status.Status,
                              Comment = x.Comment,
                              UserId = x.ApplicationUser.UserName
                          });
                //Search by the value of paramenter
                if (!string.IsNullOrEmpty(country) && country != "-- Select Country --")
                {
                    data = data.Where(x => x.CountryName.Contains(country.Trim()));
                }
                if (!string.IsNullOrEmpty(fileNumber))
                {
                    data = data.Where(x => x.FileNumber.Contains(fileNumber.Trim()));
                }
                if (!string.IsNullOrEmpty(status))
                {
                    data = data.Where(x => x.StatusId.Contains(status.Trim()));
                }
                if (!string.IsNullOrEmpty(activity))
                {
                    data = data.Where(x => x.ActivityId.Contains(activity.Trim()));
                }

                IEnumerable<FileDashModel> files = data.Select(
                    x => new FileDashModel
                    {
                        Id = x.Id,
                        CountryName = x.CountryName,
                        FileNumber = x.FileNumber,
                        ETD = x.ETD,
                        DraftCutOff = x.DraftCutOff,
                        ActivityId = x.ActivityId,
                        UserId = x.UserId,
                        StatusId = x.StatusId,
                        Comment = x.Comment,
                    }).OrderBy(sortColumn + " " + sortColumnDirection).AsQueryable().ToList();

                return Json(new
                {
                    draw = model.draw,
                    recordsTotal = files.Count(),
                    recordsFiltered = files.Count(),
                    data = files
                });
            }
            // Return the data in the format required by DataTables

        }

        public IActionResult Adhoc()
        {
            //ViewBag.ActivityMaster = _context.ActivityMaster.ToList();
            ViewData["Countries"] = _context.CountryMaster.Where(x => x.IsActive == true && x.IsDelete == false).ToList();
            return View();
        }

        [HttpGet]
        public IActionResult AdhocFileActivity()
        {
            //ViewData["fileId"] = Id;
            //ViewData["fileDtls"] = _context.FileMaster.Where(x => x.Id == Id).Include(x => x.Country).FirstOrDefault();

            //ViewData["FileActivityList"] = _context.FileActivityLog.Where(x => x.FileId == Id)
            //                                            .Include(x => x.Activity).Include(x => x.Status).Include(x => x.ApplicationUser)
            //                                            .Select(x => new FileActivityLogModel
            //                                            {
            //                                                Id = x.Id,
            //                                                FileId = x.File.Id,
            //                                                ActivityId = x.ActivityId,
            //                                                ActivityName = x.Activity.NameOfActivity,
            //                                                StatusId = x.StatusId,
            //                                                StatusName = x.Status.Status,
            //                                                UserId = x.UserId,
            //                                                UserName = x.ApplicationUser.UserName,
            //                                                Comment = x.Comment,
            //                                                StartDate = x.StartDate,
            //                                                EndDate = x.EndDate,
            //                                            }).ToList();

            ViewData["Country"] = _context.CountryMaster.Where(x => x.IsActive == true && x.IsDelete == false).ToList();
            ViewData["Activity"] = _context.ActivityMaster.Where(x => x.ActivityType == "File" && x.Source == "Adhoc" && x.IsActive == true && x.IsDelete == false).ToList();
            ViewData["Status"] = _context.StatusMaster.Where(x => x.IsActive == true && x.IsDelete == false).ToList();

            return PartialView();
        }

        //Add AdhocFileActivity data
        [HttpPost]
        public IActionResult AdhocFileActivity(AdhocFileActivityModel adhocfileActivity)
        {
            if (ModelState.IsValid)
            {
                AdhocFile adhocfile = _context.AdhocFile.Where(x => x.AdhocFileNumber == adhocfileActivity.AdhocFileNumber.ToUpper().Trim()).FirstOrDefault();

                if (adhocfile == null)
                {
                    adhocfile = new AdhocFile
                    {
                        Id = adhocfileActivity.Id,
                        CountryId = adhocfileActivity.CountryId,
                        AdhocFileNumber = adhocfileActivity.AdhocFileNumber.ToUpper().Trim(),
                        AdhocContainer = adhocfileActivity.AdhocContainer.ToUpper().Trim(),
                        EnterDate = DateTime.UtcNow,
                        IsActive = true,
                        IsDelete = false
                    };
                    _context.AdhocFile.Add(adhocfile);
                }


                foreach (AdhocFileActivityLogItem log in adhocfileActivity.AdhocFileActivities)
                {
                    var found = _context.AdhocFileActivityLog.Where(x => x.ActivityId == log.ActivityId && x.AdhocFileId == adhocfile.Id).FirstOrDefault();
                    if (found == null)
                    {
                        _context.AdhocFileActivityLog.Add(new AdhocFileActivityLog
                        {
                            Id = log.Id,
                            AdhocFileId = adhocfile.Id,
                            ActivityId = log.ActivityId,
                            StatusId = log.StatusId,
                            Comment = log.Comment,
                            UserId = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier),
                            StartDate = DateTime.UtcNow,
                            EndDate = DateTime.UtcNow,
                        });
                    }
                    else
                    {
                        found.ActivityId = log.ActivityId;
                        found.StatusId = log.StatusId;
                        found.Comment = log.Comment;
                        found.EndDate = DateTime.UtcNow;
                        found.UserId = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
                    }
                }
                _context.SaveChanges();

                //return Json(adhocfileActivity.Id);
                return Json("File Activity Inserted Successfully..!!");
            }
            else
            {
                return Json("Something went wrong");
            }
        }

        [HttpGet]
        public IActionResult AdhocHBLActivity()
        {
           ViewData["Country"]  = _context.CountryMaster.Where(x => x.IsActive == true && x.IsDelete == false).ToList();
           ViewData["Activity"] = _context.ActivityMaster.Where(x => x.ActivityType == "HBL" && x.Source == "Adhoc" && x.IsActive == true && x.IsDelete == false).ToList();
            ViewData["Status"] = _context.StatusMaster.Where(x => x.IsActive == true && x.IsDelete == false).ToList();

            return PartialView();
        }

        //Add AdhocHBLActivity data
        [HttpPost]
        public IActionResult AdhocHBLActivity(AdhocHBLActivityModel adhocHBLActivity)
        {
            string Msg = "";

            if (ModelState.IsValid)
            {
                try
                {
                    AdhocHBL adhocbooking = _context.AdhocHBL.Where(x => x.AdhocBooking == adhocHBLActivity.AdhocBooking.ToUpper().Trim()).FirstOrDefault();

                    if (adhocbooking == null)
                    {
                        AdhocHBL adhochbl = null;

                        if (adhocHBLActivity.AdhocHBLNumber != null)
                        {
                            adhochbl = _context.AdhocHBL.Where(x => x.AdhocHBLNumber.ToUpper().Trim() == adhocHBLActivity.AdhocHBLNumber.ToUpper().Trim()).FirstOrDefault();
                        }

                        if (adhochbl == null)
                        {
                            adhochbl = new AdhocHBL
                            {
                                AdhocCountryId = adhocHBLActivity.AdhocCountryId,
                                AdhocBooking = adhocHBLActivity.AdhocBooking.ToUpper().Trim(),
                                AdhocHBLNumber = adhocHBLActivity.AdhocHBLNumber,
                                //AdhocFileNumber = adhocHBLActivity.AdhocFileNumber,
                                //AdhocContainer = adhocHBLActivity.AdhocContainer,
                                EnterDate = DateTime.UtcNow,
                                IsActive = true,
                                IsDelete = false
                            };
                            _context.AdhocHBL.Add(adhochbl);

                            foreach (AdhocHBLActivityLogItem log in adhocHBLActivity.AdhocHBLActivities)
                            {
                                _context.AdhocHBLActivityLog.Add(new AdhocHBLActivityLog
                                {
                                    Id = log.Id,
                                    AdhocHBLId = adhochbl.Id,
                                    ActivityId = log.ActivityId,
                                    StatusId = log.StatusId,
                                    Comment = log.Comment,
                                    UserId = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier),
                                    StartDate = DateTime.UtcNow,
                                    EndDate = DateTime.UtcNow,
                                    BookingCBM = log.BookingCBM,
                                    ArrivedCBM = log.ArrivedCBM,
                                    Shippingtype = log.Shippingtype
                                });

                            }
                            _context.SaveChanges();
                            Msg = "adhoc Hbl is added successfully!";
                        }
                        else
                        {
                            foreach (AdhocHBLActivityLogItem log in adhocHBLActivity.AdhocHBLActivities)
                            {

                                AdhocHBLActivityLog adhocactlog = new AdhocHBLActivityLog();
                                adhocactlog.AdhocHBLId = adhochbl.Id;
                                adhocactlog.ActivityId = log.ActivityId;
                                adhocactlog.StatusId = log.StatusId;
                                adhocactlog.Comment = log.Comment;
                                adhocactlog.UserId = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
                                adhocactlog.StartDate = DateTime.UtcNow;
                                adhocactlog.EndDate = DateTime.UtcNow;
                                adhocactlog.BookingCBM = log.BookingCBM;
                                adhocactlog.ArrivedCBM = log.ArrivedCBM;
                                adhocactlog.Shippingtype = log.Shippingtype;

                                _context.AdhocHBLActivityLog.Update(adhocactlog);
                                _context.SaveChanges();
                                Msg = "adhoc Hbl is update successfully!";
                            }
                        }

                    }
                    else
                    {
                        var activityid = _context.AdhocHBLActivityLog.Where(x => x.ActivityId == adhocHBLActivity.AdhocHBLActivities[0].ActivityId && x.AdhocHBLId == adhocbooking.Id).FirstOrDefault();
                        if (activityid != null)
                        {
                            //AdhocHBLActivityLog adhocactlog = new AdhocHBLActivityLog();
                            //adhocactlog.Id=activityid.Id,
                            //adhocactlog.StatusId = activityid.StatusId;
                            //adhocactlog.Comment = activityid.Comment;
                            //adhocactlog.UserId = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
                            //adhocactlog.StartDate = DateTime.UtcNow;
                            //adhocactlog.EndDate = DateTime.UtcNow;
                            //adhocactlog.BookingCBM=activityid.BookingCBM;
                            //adhocactlog.ArrivedCBM=activityid.ArrivedCBM;
                            //adhocactlog.Shippingtype=activityid.Shippingtype;
                            foreach (AdhocHBLActivityLogItem log in adhocHBLActivity.AdhocHBLActivities)
                            {
                                activityid.StatusId = log.StatusId;
                                activityid.Comment = log.Comment;
                            }
                            _context.AdhocHBLActivityLog.Update(activityid);
                            Msg = "adhoc Hbl is update successfully!";

                        }
                        else
                        {
                            foreach (AdhocHBLActivityLogItem log in adhocHBLActivity.AdhocHBLActivities)
                            {
                                _context.AdhocHBLActivityLog.Add(new AdhocHBLActivityLog
                                {
                                    Id = log.Id,
                                    AdhocHBLId = adhocbooking.Id,
                                    ActivityId = log.ActivityId,
                                    StatusId = log.StatusId,
                                    Comment = log.Comment,
                                    UserId = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier),
                                    StartDate = DateTime.UtcNow,
                                    EndDate = DateTime.UtcNow,
                                    BookingCBM = log.BookingCBM,
                                    ArrivedCBM = log.ArrivedCBM,
                                    Shippingtype = log.Shippingtype
                                });

                            }

                        }
                        _context.SaveChanges();

                        Msg = "adhoc Hbl is update successfully!";
                    }

                }
                catch (Exception ex)
                {

                }

                return Json(Msg + " " + adhocHBLActivity.Id);
            }
            else
            {
                return Json(Msg);
            }
        }

        [HttpPost]
        //public IActionResult GetAdhocFiles(DataTableAjaxPostModel model, string country, string fileNumber, string container)
        public IActionResult GetAdhocFiles(DataTableAjaxPostModel model, string country, string fileNumber, string container)
        {
            var draw = model.draw;
            var sortColumn = string.IsNullOrEmpty(model.columns[model.order[0].column].data) ? "id" : model.columns[model.order[0].column].data;
            var sortColumnDirection = model.order[0].dir;
            var searchValue = model.search.value;
            int pageSize = model.length.HasValue ? model.length.Value : 10;
            int skip = model.start.HasValue ? model.start.Value : 0;

            // Get the data for the DataTable
            var data = _context.AdhocFileActivityLog
            .Join(_context.AdhocFile, fileActivity => fileActivity.AdhocFileId, fileMaster => fileMaster.Id, (fileActivity, fileMaster) => new { fileActivity, fileMaster })
            .Join(_context.ActivityMaster, activityJoin => activityJoin.fileActivity.ActivityId, activityMaster => activityMaster.Id, (activityJoin, activityMaster) => new { activityJoin, activityMaster })
            .Join(_context.StatusMaster, statusjoin => statusjoin.activityJoin.fileActivity.StatusId, statusMaster => statusMaster.Id, (statusjoin, statusMaster) => new { statusjoin, statusMaster })
            .Join(_context.CountryMaster, countryjoin => countryjoin.statusjoin.activityJoin.fileMaster.CountryId, countryMaster => countryMaster.Id, (countryjoin, countryMaster) => new { countryjoin, countryMaster })
            .Join(_context.Users, userjoin => userjoin.countryjoin.statusjoin.activityJoin.fileActivity.ApplicationUser.Id, User => User.Id, (userjoin, User) => new
            AdhocFileDashModel
            {

                Id = userjoin.countryjoin.statusjoin.activityJoin.fileMaster.Id,
                CountryName = userjoin.countryMaster.CountryName,
                FileNumber = userjoin.countryjoin.statusjoin.activityJoin.fileMaster.AdhocFileNumber,
                Container = userjoin.countryjoin.statusjoin.activityJoin.fileMaster.AdhocContainer,
                LastActivityPerformed = userjoin.countryjoin.statusjoin.activityMaster.NameOfActivity,
                LastActivityStatus = userjoin.countryjoin.statusMaster.Status,
                LastProcessedDate = userjoin.countryjoin.statusjoin.activityJoin.fileActivity.EndDate,
                LastFileHandler = User.UserName
                //Comment = countryjoin.statusjoin.activityJoin.fileActivity.Comment,
            })
            .GroupBy(x => x.FileNumber)
            .Select(group => group.OrderByDescending(x => x.LastProcessedDate).First()).ToList().AsQueryable();

            if (!string.IsNullOrEmpty(country) && country != "-- Select Country --")
            {
                data = data.Where(x => x.CountryName.Contains(country.Trim()));
            }
            if (!string.IsNullOrEmpty(fileNumber))
            {
                data = data.Where(x => x.FileNumber.Contains(fileNumber.Trim()));
            }
            if (!string.IsNullOrEmpty(container))
            {
                data = data.Where(x => x.Container.Contains(container.Trim()));
            }
            int filteredrecords = data.Count();
            const string ISTTimeZoneId = "India Standard Time";

            List<AdhocFileDashModel> files = data.Select(
                x => new AdhocFileDashModel
                {
                    Id = x.Id,
                    CountryName = x.CountryName,
                    FileNumber = x.FileNumber,
                    Container = x.Container,
                    LastActivityPerformed = x.LastActivityPerformed,
                    LastActivityStatus = x.LastActivityStatus,
                    LastProcessedDate = x.LastProcessedDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.LastProcessedDate.Value, TimeZoneInfo.FindSystemTimeZoneById(ISTTimeZoneId)) : (DateTime?)null,
                    LastFileHandler = x.LastFileHandler
                }).OrderBy(sortColumn + " " + sortColumnDirection)
               .Skip(skip)
               .Take(pageSize == -1 ? 10 : pageSize).AsQueryable().ToList();


            // Return the data in the format required by DataTables
            return Json(new
            {
                draw = model.draw,
                recordsTotal = data.Count(),
                recordsFiltered = filteredrecords,
                data = files
            });
        }

        [HttpPost]
        //public IActionResult GetAdhocHBLs(DataTableAjaxPostModel model, string country, string fileNumber, string container)
        public IActionResult GetAdhocHBLs(DataTableAjaxPostModel model, string country, string booking, string hblNumber)
        {

            var draw = model.draw;
            var sortColumn = string.IsNullOrEmpty(model.columns[model.order[0].column].data) ? "id" : model.columns[model.order[0].column].data;
            var sortColumnDirection = model.order[0].dir;
            var searchValue = model.search.value;
            int pageSize = model.length.HasValue ? model.length.Value : 10;
            int skip = model.start.HasValue ? model.start.Value : 0;

            // Get the data for the DataTable
            //var data = _context.AdhocHBLActivityLog
            //.Join(_context.AdhocHBL, hblActivity => hblActivity.AdhocHBLId, hblMaster => hblMaster.Id, (hblActivity, hblMaster) => new { hblActivity, hblMaster })
            //.Join(_context.ActivityMaster, activityJoin => activityJoin.hblActivity.ActivityId, activityMaster => activityMaster.Id, (activityJoin, activityMaster) => new { activityJoin, activityMaster })
            //.Join(_context.StatusMaster, statusjoin => statusjoin.activityJoin.hblActivity.StatusId, statusMaster => statusMaster.Id, (statusjoin, statusMaster) => new { statusjoin, statusMaster })
            //.Join(_context.CountryMaster, countryjoin => countryjoin.statusjoin.activityJoin.hblMaster.AdhocCountryId, countryMaster => countryMaster.Id, (countryjoin, countryMaster) => new { countryjoin, countryMaster })
            //.Join(_context.Users, userjoin => userjoin.countryjoin.statusjoin.activityJoin.hblActivity.ApplicationUser.Id, User => User.Id, (userjoin, User) => new
            //AdhocHBLDashModel
            //{

            //    Id = userjoin.countryjoin.statusjoin.activityJoin.hblMaster.Id,
            //    CountryName = userjoin.countryMaster.CountryName,
            //    HBLNo = userjoin.countryjoin.statusjoin.activityJoin.hblMaster.AdhocHBLNumber,
            //    BookingNo = userjoin.countryjoin.statusjoin.activityJoin.hblMaster.AdhocBooking,
            //    LastActivityPerformed = userjoin.countryjoin.statusjoin.activityMaster.NameOfActivity,
            //    LastActivityStatus = userjoin.countryjoin.statusMaster.Status,
            //    LastProcessedDate = userjoin.countryjoin.statusjoin.activityJoin.hblActivity.EndDate,
            //    LastHBLHandler = User.UserName
            //    //Comment = countryjoin.statusjoin.activityJoin.hblActivity.Comment,
            //})
            //.GroupBy(x => x.HBLNo)
            //.Select(group => group.OrderByDescending(x => x.LastProcessedDate).First()).ToList().AsQueryable();


            var data = _context.AdhocHBLActivityLog
                        .Include(x => x.Activity)
                        .Include(x => x.Status)
                        .Include(x => x.AdhocHBL)
                        .Select(x => new AdhocHBLDashModel
                        {
                            Id = x.Id,
                            CountryName = x.AdhocHBL.Country.CountryName,
                            HBLNo = x.AdhocHBL.AdhocHBLNumber,
                            BookingNo = x.AdhocHBL.AdhocBooking,
                            LastActivityPerformed = x.Activity.NameOfActivity,
                            LastActivityStatus = x.Status.Status,
                            LastProcessedDate = x.EndDate,
                            LastHBLHandler = x.ApplicationUser.UserName
                        })
                       .ToList().AsQueryable();



            if (!string.IsNullOrEmpty(country) && country != "--Select--")
            {
                data = data.Where(x => x.CountryName.Contains(country.Trim()));
            }
            if (!string.IsNullOrEmpty(booking))
            {
                data = data.Where(x => x.BookingNo.Contains(booking.Trim()));
            }
            //if (!string.IsNullOrEmpty(hblNumber))
            //{
            //    hblNumber=hblNumber.Trim();
            //    data = data.Where(x => x.HBLNo.Contains(hblNumber));
            //}

            int filteredrecords = data.Count();
            const string ISTTimeZoneId = "India Standard Time";

            List<AdhocHBLDashModel> files = data.AsQueryable().Select(
                x => new AdhocHBLDashModel
                {
                    CountryName = x.CountryName,
                    BookingNo = x.BookingNo,
                    HBLNo = x.HBLNo,

                    LastActivityPerformed = x.LastActivityPerformed,
                    LastActivityStatus = x.LastActivityStatus,
                    LastProcessedDate = x.LastProcessedDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.LastProcessedDate.Value, TimeZoneInfo.FindSystemTimeZoneById(ISTTimeZoneId)) : (DateTime?)null,
                    LastHBLHandler = x.LastHBLHandler
                }).OrderBy(sortColumn + " " + sortColumnDirection)
               .Skip(skip)
               .Take(pageSize == -1 ? 10 : pageSize).AsQueryable().ToList();

            // Return the data in the format required by DataTables
            return Json(new
            {
                draw = model.draw,
                recordsTotal = data.Count(),
                recordsFiltered = filteredrecords,
                data = files
            });
        }

        //Get File activity data
        [HttpGet]
        public IActionResult GetFileActivityData(string Id)
        {
            var adhocFile = _context.AdhocFileActivityLog.Where(fileActivity => fileActivity.AdhocFile.Id == Id)
            .Join(_context.ActivityMaster, activityJoin => activityJoin.ActivityId, activityMaster => activityMaster.Id, (activityJoin, activityMaster) => new { activityJoin, activityMaster })
            .Join(_context.StatusMaster, statusjoin => statusjoin.activityJoin.StatusId, statusMaster => statusMaster.Id, (statusjoin, statusMaster) => new { statusjoin, statusMaster })
            .Join(_context.Users, userjoin => userjoin.statusjoin.activityJoin.ApplicationUser.Id, User => User.Id, (userjoin, User) => new
            {

                Id = userjoin.statusjoin.activityMaster.Id,
                ActivityName = userjoin.statusjoin.activityMaster.NameOfActivity,
                Status = userjoin.statusMaster.Status,
                ProcessedDate = userjoin.statusjoin.activityJoin.EndDate,
                User = User.UserName,
                Comment = userjoin.statusjoin.activityJoin.Comment == null ? "" : userjoin.statusjoin.activityJoin.Comment,
            }).OrderByDescending(x => x.ProcessedDate).ToList().AsQueryable();

            const string ISTTimeZoneId = "India Standard Time";

            adhocFile = adhocFile.Select(x => new
            {
                Id = x.Id,
                ActivityName = x.ActivityName,
                Status = x.Status,
                ProcessedDate = x.ProcessedDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.ProcessedDate.Value, TimeZoneInfo.FindSystemTimeZoneById(ISTTimeZoneId)) : (DateTime?)null,
                User = x.User,
                Comment = x.Comment,
            }).ToList().AsQueryable();

            return Json(new { adhocFile });
        }

        [HttpGet]
        public IActionResult GetFileActivityData1(string Id)
        {
            var adhocHBL = _context.AdhocHBLActivityLog.Where(fileActivity => fileActivity.AdhocHBLId == Id)
             .Join(_context.ActivityMaster, activityJoin => activityJoin.ActivityId, activityMaster => activityMaster.Id, (activityJoin, activityMaster) => new { activityJoin, activityMaster })
             .Join(_context.StatusMaster, statusjoin => statusjoin.activityJoin.StatusId, statusMaster => statusMaster.Id, (statusjoin, statusMaster) => new { statusjoin, statusMaster })
             .Join(_context.Users, userjoin => userjoin.statusjoin.activityJoin.ApplicationUser.Id, User => User.Id, (userjoin, User) => new
             {

                 Id = userjoin.statusjoin.activityMaster.Id,
                 ActivityName = userjoin.statusjoin.activityMaster.NameOfActivity,
                 Status = userjoin.statusMaster.Status,
                 ProcessedDate = userjoin.statusjoin.activityJoin.EndDate,
                 User = User.UserName,
                 Comment = userjoin.statusjoin.activityJoin.Comment == null ? "" : userjoin.statusjoin.activityJoin.Comment,
             }).OrderByDescending(x => x.ProcessedDate).ToList().AsQueryable();

            const string ISTTimeZoneId = "India Standard Time";

            adhocHBL = adhocHBL.Select(x => new
            {
                Id = x.Id,
                ActivityName = x.ActivityName,
                Status = x.Status,
                ProcessedDate = x.ProcessedDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.ProcessedDate.Value, TimeZoneInfo.FindSystemTimeZoneById(ISTTimeZoneId)) : (DateTime?)null,
                User = x.User,
                Comment = x.Comment,
            }).ToList().AsQueryable();

            return Json(new { adhocHBL });
        }

        //Get HBL Activity Data
        [HttpGet]
        public IActionResult GetHBLActivityData(string Id)
        {
            const string ISTTimeZoneId = "India Standard Time";


            var adhocHBL = _context.AdhocHBLActivityLog.Where(fileActivity => fileActivity.AdhocHBLId == Id)
            .Join(_context.ActivityMaster, activityJoin => activityJoin.ActivityId, activityMaster => activityMaster.Id, (activityJoin, activityMaster) => new { activityJoin, activityMaster })
            .Join(_context.StatusMaster, statusjoin => statusjoin.activityJoin.StatusId, statusMaster => statusMaster.Id, (statusjoin, statusMaster) => new { statusjoin, statusMaster })
            .Join(_context.Users, userjoin => userjoin.statusjoin.activityJoin.ApplicationUser.Id, User => User.Id, (userjoin, User) => new
            {

                Id = userjoin.statusjoin.activityMaster.Id,
                ActivityName = userjoin.statusjoin.activityMaster.NameOfActivity,
                Status = userjoin.statusMaster.Status,
                ProcessedDate = userjoin.statusjoin.activityJoin.EndDate,
                User = User.UserName,
                Comment = userjoin.statusjoin.activityJoin.Comment == null ? "" : userjoin.statusjoin.activityJoin.Comment,
            }).OrderByDescending(x => x.ProcessedDate).ToList().AsQueryable();

            adhocHBL = adhocHBL.Select(x => new
            {
                Id = x.Id,
                ActivityName = x.ActivityName,
                Status = x.Status,
                ProcessedDate = x.ProcessedDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.ProcessedDate.Value, TimeZoneInfo.FindSystemTimeZoneById(ISTTimeZoneId)) : (DateTime?)null,
                User = x.User,
                Comment = x.Comment,
            }).ToList().AsQueryable();

            return Json(new { adhocHBL });
        }

        //Get HBL Activity data
        [HttpGet]
        public IActionResult GetHBLActivity(string Id)
        {
            const string ISTTimeZoneId = "India Standard Time";

            var HBL = _context.HBLActivityLog.Where(x => x.HBLId == Id)
            .Include(activity => activity.Activity)
            .Include(status => status.Status)
            .Include(user => user.ApplicationUser)
            .Select(x => new
            {
                Id = x.Activity.Id,
                ActivityName = x.Activity.NameOfActivity,
                Status = x.Status.Status,
                ProcessedDate = x.EndDate,
                User = x.ApplicationUser.UserName,
                Comment = x.Comment == null ? "" : x.Comment,
            })
           .OrderByDescending(x => x.ProcessedDate).ToList().AsQueryable()
           .ToList();

            HBL = HBL.Select(x => new
            {
                Id = x.Id,
                ActivityName = x.ActivityName,
                Status = x.Status,
                ProcessedDate = x.ProcessedDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.ProcessedDate.Value, TimeZoneInfo.FindSystemTimeZoneById(ISTTimeZoneId)) : (DateTime?)null,
                User = x.User,
                Comment = x.Comment,
            }).ToList();

            return Json(new { HBL });
        }

        //
        [HttpPost]
        public JsonResult AddHblActivities(HBLActivityLogViewModel model)
        {
            if (model.ActivityId == null)
            {
                return Json("Please select activity");
            }
            else if (model.StatusId == null)
            {
                return Json("Please select status");
            }
            else
            {
                var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);

                var hbllog = _context.HBLActivityLog.Where(x => x.HBLId == model.HblId && x.ActivityId == model.ActivityId).FirstOrDefault();

                if (ModelState.IsValid)
                {
                    if (hbllog == null)
                    {
                        _context.HBLActivityLog.Add(new HBLActivityLog
                        {
                            HBLId = model.HblId,
                            ActivityId = model.ActivityId,
                            StatusId = model.StatusId,
                            UserId = userid,
                            StartDate = DateTime.UtcNow,
                            EndDate = DateTime.UtcNow,
                            Comment = model.Comment
                        });
                    }
                    else
                    {
                        //var hbllog = _context.HBLActivityLog.FirstOrDefault(x => x.HBLId == model.HblId);

                        _context.HBLActivitylogHistory.Add(new HBLActivitylogHistory
                        {
                            StartDate = DateTime.UtcNow,
                            HBLogId = hbllog.Id,
                            ActivityId = hbllog.ActivityId,
                            StatusId = hbllog.StatusId,
                            UserId = userid,
                            EndDate = DateTime.UtcNow,
                            Comment = hbllog.Comment
                        });

                        if (hbllog != null)
                        {
                            hbllog.ActivityId = model.ActivityId;
                            hbllog.StatusId = model.StatusId;
                            hbllog.UserId = userid;
                            hbllog.StartDate = DateTime.Parse(model.StartDate.ToString());
                            hbllog.EndDate = DateTime.UtcNow;
                            hbllog.Comment = model.Comment;
                        }
                    }
                    _context.SaveChanges();
                    return Json("Success");
                }
                else
                {
                    return Json("Error while processing the request");
                }
            }
        }

        [HttpGet]
        public IActionResult CreateFile()
        {
            ViewBag.Countries = _context.CountryMaster.Where(x => x.IsActive == true && x.IsDelete == false).ToList();
            ViewBag.Activity = _context.ActivityMaster.Where(x => x.ActivityType == "File" && x.Source == "Upload" && x.IsActive == true && x.IsDelete == false).ToList();
            ViewBag.Status = _context.StatusMaster.Where(x => x.IsActive == true && x.IsDelete == false).ToList();

            return PartialView();
        }

        [HttpPost]
        public IActionResult AddFileNewActivity(FileAddActivityLogModel file)
        {
            if (ModelState.IsValid)
            {
                FileMaster fileMaster = _context.FileMaster.Where(x => x.FileNumber == file.FileNumber.ToUpper().Trim()).FirstOrDefault();

                if (fileMaster == null)
                {
                    fileMaster = new FileMaster
                    {
                        Id = file.Id,
                        CountryId = file.CountryId,
                        FileNumber = file.FileNumber.ToUpper().Trim(),
                        Etd = file.ETD,
                        DraftCutoff = file.DraftCutOff,
                        EnterDate = DateTime.UtcNow,
                        IsActive = true,
                        IsDelete = false
                    };
                    _context.FileMaster.Add(fileMaster);
                }

                foreach (FileActivityLogItem log in file.FileActivities)
                {
                    _context.FileActivityLog.Add(new FileActivityLog
                    {
                        Id = log.Id,
                        FileId = fileMaster.Id,
                        ActivityId = log.ActivityId,
                        StatusId = log.StatusId,
                        Comment = log.Comment,
                        UserId = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier),
                        StartDate = DateTime.UtcNow,
                        EndDate = DateTime.UtcNow,
                    });
                }

                _context.SaveChanges();

                return Json(file.Id);
            }
            else
            {
                return Json("Something went wrong");

            }
        }

        [HttpGet]
        public IActionResult CreateHBL()
        {
            ViewData["Country"] = _context.CountryMaster.Where(x => x.IsActive == true && x.IsDelete == false).ToList();
            ViewData["Activity"] = _context.ActivityMaster.Where(x => x.ActivityType == "HBL" && x.Source == "Upload" && x.IsActive == true && x.IsDelete == false).ToList();
            ViewData["Status"] = _context.StatusMaster.Where(x => x.IsActive == true && x.IsDelete == false).ToList();
            return PartialView();
        }

        [HttpPost]
        public IActionResult AddNewHBLActivity(HBLUserViewModel hbl)
        {
            string Msg = "";
            if (ModelState.IsValid)
            {
                var file = _context.FileMaster.Where(x => x.FileNumber == hbl.FileNo.ToUpper().Trim()).FirstOrDefault();

                if (file == null)
                {
                    Msg = "File does not exist first insert file";
                }
                else
                {
                    HBLMaster hblMaster = _context.HBLMaster.Where(x => x.HBLNumber == hbl.HBL_No.ToUpper().Trim()).FirstOrDefault();

                    if (hblMaster == null)
                    {
                        hblMaster = new HBLMaster
                        {
                            Id = hbl.Id,
                            HBLNumber = hbl.HBL_No,
                            FileId = _context.FileMaster.Where(x => x.FileNumber == hbl.FileNo.ToUpper().Trim()).Select(x => x.Id).FirstOrDefault(),
                            Container = hbl.Container,
                            Booking = hbl.BookingNo,
                            CustomerName = hbl.CustomerName,
                            EnterDate = DateTime.UtcNow,
                            IsActive = true,
                            IsDelete = false
                        };
                        _context.HBLMaster.Add(hblMaster);
                        _context.SaveChanges();
                        Msg = "HBL Inserted Successfully..!!";
                    }
                    else
                    {
                        Msg = "HBL no is already added";
                    }

                    //foreach (HBLActivityLogs log in hbl.HBLActivities)
                    //{
                    //    _context.HBLActivityLog.Add(new HBLActivityLog
                    //    {
                    //        Id = log.Id,
                    //        HBLId = hbl.Id,
                    //        ActivityId = log.ActivityId,
                    //        StatusId = log.StatusId,
                    //        Comment = log.Comment,
                    //        UserId = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier),
                    //        StartDate = DateTime.UtcNow,
                    //        EndDate = DateTime.UtcNow,
                    //    });
                    //}

                }
                return Json(Msg);

            }
            else
            {
                return Json("Error while processing the request");

            }
        }

        [HttpGet]
        public IActionResult InsertFile()
        {
            ViewData["Country"] = _context.CountryMaster.Where(x => x.IsActive == true && x.IsDelete == false).ToList();            
           
            return PartialView();
        }

        //Insert new file data
        public IActionResult InsertNewFile(FileInsertModel file)
        {
            if (ModelState.IsValid)
            {
                FileMaster fileMaster = _context.FileMaster.Where(x => x.FileNumber == file.FileNumber.ToUpper().Trim()).FirstOrDefault();

                if (fileMaster == null)
                {
                    fileMaster = new FileMaster
                    {
                        Id = file.Id,
                        CountryId = file.CountryId,
                        FileNumber = file.FileNumber.ToUpper().Trim(),
                        Etd = file.ETD,
                        DraftCutoff = file.DraftCutOff,
                        EnterDate = DateTime.UtcNow,
                        IsActive = true,
                        IsDelete = false
                    };
                    _context.FileMaster.Add(fileMaster);
                }
                _context.SaveChanges();

                return Json(file.Id);
            }
            else
            {
                return Json("Something went wrong");

            }
        }


        public IActionResult FileQuery()
        {
            ViewBag.StatusMaster = _context.StatusMaster.Where(x => x.IsActive == true && x.IsDelete == false).OrderBy(x => x.Status).ToList();
            ViewBag.ActivityMaster = _context.ActivityMaster.OrderBy(x => x.NameOfActivity).Where(x => x.ActivityType == "File" && x.Source == "Upload" && x.IsActive == true && x.IsDelete == false).ToList();
            ViewBag.Countries = _context.CountryMaster.Where(x => x.IsActive == true && x.IsDelete == false).OrderBy(x => x.CountryName).ToList();
            return View();
        }

        //Get file data

        [HttpGet]
        public IActionResult GetfileData(string fileNumber)
        {
            var hbl = _context.HBLMaster.Where(x => x.File.FileNumber == fileNumber.Trim()).ToList();
            var file = _context.FileMaster.Where(x => x.FileNumber == fileNumber.Trim()).Select(x => new { x.Id }).FirstOrDefault();
            var sm = _context.StatusMaster.Where(x => x.IsActive == true && x.IsDelete == false).ToList();

            var fm = _context.FileActivityLog.Include(x => x.File).Include(x => x.Activity).Include(x => x.Status).Include(x => x.ApplicationUser).Where(x => x.FileId == file.Id).ToList();
            IQueryable<FileActivityLog> fileActivityLog = fm.AsQueryable();

            return Json(new { fm, hbl, sm });
        }

        [HttpGet]
        public IActionResult GetHblActivityData(string hblnumber)
        {
            var hblact = _context.HBLActivityLog.Include(x => x.Hbl).Include(x => x.Activity).Include(x => x.Status).Where(x => x.Hbl.HBLNumber == hblnumber.Trim()).ToList();
            IQueryable<HBLActivityLog> hblActivityLog = hblact.AsQueryable();
            foreach (var item in hblact)
            {
                hblActivityLog.Select(x => new HBLActivityLog
                {
                    ActivityId = _context.HBLActivityLog.Where(x => x.Activity.Id == item.ActivityId).Select(x => x.Activity.NameOfActivity).FirstOrDefault(),
                    StatusId = _context.HBLActivityLog.Where(x => x.Status.Id == item.StatusId).Select(x => x.Status.Status).FirstOrDefault(),
                    UserId = _context.HBLActivityLog.Where(x => x.ApplicationUser.Id == item.UserId).Select(x => x.ApplicationUser.UserName).FirstOrDefault(),

                }).ToList();
            }
            return Json(hblact);
        }

        //HBL Query data 
        public IActionResult HBLQuery(string fileNumber)
        {
            ViewBag.ActivityMaster = _context.ActivityMaster.OrderBy(x => x.NameOfActivity).Where(x => x.ActivityType == "HBL" && x.Source == "Upload" && x.IsActive == true && x.IsDelete == false).ToList();
            ViewBag.Countries = _context.CountryMaster.Where(x => x.IsActive == true && x.IsDelete == false).ToList();
            IEnumerable<HBLQueryActivity> data = null;
            var username = _httpContextAccessor.HttpContext.User.Identity.Name;
            var role = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.Role);
            if (fileNumber != null)
            {
                if (role != "User")
                {
                    data = (from fa in _context.HBLActivityLog
                            join am in _context.ActivityMaster
                            on fa.ActivityId equals am.Id
                            join sm in _context.StatusMaster
                            on fa.StatusId equals sm.Id
                            join um in _context.Users
                            on fa.UserId equals um.Id
                            join hm in _context.HBLMaster
                            on fa.HBLId equals hm.Id

                            select (new HBLQueryActivity
                            {
                                Id = hm.Id,
                                FileNo = hm.File.ToString(),
                                BookingNo = hm.Booking,
                                HBL_No = hm.HBLNumber,
                                CountryName = hm.File.Country.CountryName,
                                CustomerName = hm.CustomerName,
                                UserId = um.UserName,
                                ActivityId = fa.Activity.NameOfActivity,
                                StatusId = fa.Status.Status,
                                Comment = fa.Comment,
                                ProcessDate = fa.StartDate
                            }));

                }
                else
                {
                    data = (from fa in _context.HBLActivityLog
                            join am in _context.ActivityMaster
                            on fa.ActivityId equals am.Id
                            join sm in _context.StatusMaster
                            on fa.StatusId equals sm.Id
                            join um in _context.Users
                            on fa.UserId equals um.Id
                            where (um.UserName == User.Identity.Name)
                            join hm in _context.HBLMaster
                            on fa.HBLId equals hm.Id
                            select (new HBLQueryActivity
                            {
                                Id = hm.Id,
                                FileNo = hm.File.ToString(),
                                BookingNo = hm.Booking,
                                HBL_No = hm.HBLNumber,
                                CountryName = hm.File.Country.CountryName,
                                CustomerName = hm.CustomerName,
                                UserId = um.UserName,
                                ActivityId = fa.Activity.NameOfActivity,
                                StatusId = fa.Status.Status,
                                Comment = fa.Comment,
                                ProcessDate = fa.StartDate
                            }));
                }
            }
            else
            {
                ViewBag.Status = _context.StatusMaster.Where(x => x.IsActive == true && x.IsDelete == false).ToList();

                if (role != "User")
                {
                    data = (from fa in _context.HBLActivityLog
                            join am in _context.ActivityMaster
                            on fa.ActivityId equals am.Id
                            join sm in _context.StatusMaster
                            on fa.StatusId equals sm.Id
                            join um in _context.Users
                            on fa.UserId equals um.Id
                            join hm in _context.HBLMaster
                            on fa.HBLId equals hm.Id

                            select (new HBLQueryActivity
                            {
                                Id = hm.Id,
                                FileNo = hm.File.ToString(),
                                BookingNo = hm.Booking,
                                HBL_No = hm.HBLNumber,
                                CountryName = hm.File.Country.CountryName,
                                CustomerName = hm.CustomerName,
                                UserId = um.UserName,
                                ActivityId = fa.Activity.NameOfActivity,
                                StatusId = fa.Status.Status,
                                Comment = fa.Comment,
                                ProcessDate = fa.StartDate
                            }));

                }
                else
                {
                    data = (from fa in _context.HBLActivityLog
                            join am in _context.ActivityMaster
                            on fa.ActivityId equals am.Id
                            join sm in _context.StatusMaster
                            on fa.StatusId equals sm.Id
                            join um in _context.Users
                            on fa.UserId equals um.Id
                            where (um.UserName == User.Identity.Name)
                            join hm in _context.HBLMaster
                            on fa.HBLId equals hm.Id

                            select (new HBLQueryActivity
                            {
                                Id = hm.Id,
                                FileNo = hm.File.ToString(),
                                BookingNo = hm.Booking,
                                HBL_No = hm.HBLNumber,
                                CountryName = hm.File.Country.CountryName,
                                CustomerName = hm.CustomerName,
                                UserId = um.UserName,
                                ActivityId = fa.Activity.NameOfActivity,
                                StatusId = fa.Status.Status,
                                Comment = fa.Comment,
                                ProcessDate = fa.StartDate
                            }));
                }
            }
            ViewBag.StatusMaster = _context.StatusMaster.Where(x => x.IsActive == true && x.IsDelete == false).ToList();
            return View(data);

        }
        //HBL Activity Query
        [HttpGet]
        public IActionResult GetHBLActivityQuery(string Id)
        {
            var sm = _context.StatusMaster.Where(x => x.IsActive == true && x.IsDelete == false).ToList();
            var HBL = _context.HBLActivityLog.Where(fileActivity => fileActivity.HBLId == Id)
            .Join(_context.ActivityMaster, activityJoin => activityJoin.ActivityId, activityMaster => activityMaster.Id, (activityJoin, activityMaster) => new { activityJoin, activityMaster })
            .Join(_context.StatusMaster, statusjoin => statusjoin.activityJoin.StatusId, statusMaster => statusMaster.Id, (statusjoin, statusMaster) => new { statusjoin, statusMaster })
            .Join(_context.Users, userjoin => userjoin.statusjoin.activityJoin.ApplicationUser.Id, User => User.Id, (userjoin, User) => new
            {
                Id = userjoin.statusjoin.activityMaster.Id,
                ActivityName = userjoin.statusjoin.activityMaster.NameOfActivity,
                Status = userjoin.statusMaster.Status,
                ProcessedDate = userjoin.statusjoin.activityJoin.EndDate,
                User = User.UserName,
                Comment = userjoin.statusjoin.activityJoin.Comment == null ? "" : userjoin.statusjoin.activityJoin.Comment,
            }).OrderByDescending(x => x.ProcessedDate).ToList().Where(x => x.Status == "Query").AsQueryable();
            return Json(new { HBL, sm, Id });
        }

        //HBL Activity changes status
        public IActionResult HBLActivityChangeStatus(HBLQueryActivity hbl)
        {
            string Msg = "";
            var activityId = _context.ActivityMaster.Where(x => x.NameOfActivity == hbl.ActivityId && x.IsActive == true && x.IsDelete == false).Select(x => x.Id).FirstOrDefault();
            var statusId = _context.StatusMaster.Where(x => x.Status == hbl.StatusId && x.IsActive == true && x.IsDelete == false).Select(x => x.Id).FirstOrDefault();
            var userId = _context.Users.Where(x => x.UserName == hbl.UserId && x.IsActive == true && x.IsDelete == false).Select(x => x.Id).FirstOrDefault();
            var hbldata = _context.HBLActivityLog.Where(x => x.Id == hbl.Id && x.ActivityId == activityId).FirstOrDefault();
            var hblActivityLog = _context.HBLActivityLog.FirstOrDefault(x => x.HBLId == hbl.Id);

            _context.HBLActivitylogHistory.Add(new HBLActivitylogHistory
            {
                HBLogId = hbl.Id,
                ActivityId = hblActivityLog.ActivityId,
                StatusId = hblActivityLog.StatusId,
                Comment = hblActivityLog.Comment,
                UserId = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier),
                StartDate = DateTime.UtcNow,
                EndDate = DateTime.UtcNow,
            });

            if (hblActivityLog != null)
            {
                hblActivityLog.ActivityId = hblActivityLog.ActivityId;
                hblActivityLog.StatusId = statusId;
                hblActivityLog.EndDate = DateTime.UtcNow;
                hblActivityLog.Comment = hbl.Comment;
                hblActivityLog.UserId = userId;
                _context.SaveChanges();
                Msg = "Status Update Successfully.";
            }
            else
            {
                Msg = "Error while processing the request.";
            }
            return Json(Msg);
        }

        // Change file activity status add and update
        public IActionResult FileActivityChangeStatus(FileQueryActivity filequery)
        {
            string Msg = "";
            var files = _context.FileMaster.Where(x => x.FileNumber == filequery.Filenumber).Include(x => x.FileActivityLogs).ThenInclude(x => x.Status).ToList();
            var fileid = _context.FileMaster.Where(x => x.FileNumber == filequery.Filenumber).Select(x => x.Id).FirstOrDefault();
            var activityId = _context.ActivityMaster.Where(x => x.NameOfActivity == filequery.ActivityId && x.ActivityType == "File" && x.IsActive == true && x.IsDelete == false).Select(x => x.Id).FirstOrDefault();
            // var statusId = _context.StatusMaster.Where(x => x.Status == filequery.StatusId).Select(x => x.Id).FirstOrDefault();
            var userId = _context.Users.Where(x => x.UserName == filequery.UserId && x.IsActive == true && x.IsDelete == false).Select(x => x.Id).FirstOrDefault();
            var fileActivityLog = _context.FileActivityLog.Where(x => x.FileId == fileid && x.ActivityId == activityId).FirstOrDefault();

            if (fileActivityLog == null)
            {
                Msg = "Error while processing the request.";
            }
            else
            {
                //Add data in fileactivityhistory tables
                _context.FileAcitivityLogHistory.Add(new FileAcitivityLogHistory
                {
                    FileLogId = fileActivityLog.Id,
                    ActivityId = fileActivityLog.ActivityId,
                    StatusId = fileActivityLog.StatusId,
                    Comment = fileActivityLog.Comment,
                    UserId = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier),
                    StartDate = DateTime.UtcNow,
                    EndDate = DateTime.UtcNow,
                });

                if (fileActivityLog != null)
                {
                    fileActivityLog.StatusId = filequery.StatusId;
                    fileActivityLog.Comment = filequery.Comment;
                    fileActivityLog.UserId = userId;
                    fileActivityLog.EndDate = DateTime.UtcNow;
                    _context.SaveChanges();
                    Msg = "Status Update Successfully.";
                }
                else
                {
                    Msg = "Error while processing the request.";
                }
            }
            //return status of file.
            return Json(Msg);
        }

        public IActionResult Datatableexample()
        {
            return View();
        }

        //Get file data
        [HttpPost]
        public IActionResult GetDatatable(DataTableAjaxPostModel model, string country, string fileNumber, string hBLNumber)
        {
            // Get the data for the DataTable
            var data = _context.FileMaster.Include(x => x.Country).Include(x => x.HBLMasters).AsQueryable();

            IEnumerable<FileDashModel> files;

            var hblIds = data.Where(x => x.FileNumber == fileNumber.Trim())
             .SelectMany(x => x.HBLMasters.Select(y => y.Id))
             .ToList();

            files = data.Select(
               x => new FileDashModel
               {
                   Id = x.Id,
                   CountryName = x.Country.CountryName,
                   FileNumber = x.FileNumber,
                   ETD = x.Etd,
                   DraftCutOff = x.DraftCutoff,
                   CountofHBL = x.HBLMasters.Count(),
                   ProcessedHBL = x.HBLMasters
                                   .Where(y => y.FileId == x.Id)
                                   .SelectMany(y => y.HBLActivityLogs.Select(log => log.HBLId))
                                   .Distinct()
                                   .Count(),
                   PendingHBL = (x.HBLMasters.Count() - x.HBLMasters
                                   .Where(y => y.FileId == x.Id)
                                   .SelectMany(y => y.HBLActivityLogs.Select(log => log.HBLId))
                                   .Distinct()
                                   .Count()),
                   UserId = x.FileActivityLogs.Where(y => y.Activity.NameOfActivity == "FileAllocation").Select(x => x.ApplicationUser.UserName).FirstOrDefault(),
                   StatusId = x.FileActivityLogs.Where(y => y.Activity.NameOfActivity == "FileAllocation").Select(x => x.Status.Status).FirstOrDefault(),

               }).ToList();

            // Return the data in the format required by DataTables
            return Json(new
            {
                draw = model.draw,
                recordsTotal = data.Count(),
                recordsFiltered = files.Count(),
                data = files
            });
        }


        //Report
        public ActionResult Report()
        {
            return View();
        }

        //Report download
        [HttpPost]
        public ActionResult Report(ReportViewModel report)
        {
            //Main Report file and HBL also activity wise filelevel and hbllevel report
            DataTable filedt = new DataTable();
            DataTable fileactivity = new DataTable();
            DataTable hbldt = new DataTable();
            //Adhoc Report 
            DataTable adhoc = new DataTable();
            DataTable adhocHBL = new DataTable();
            DataTable adhocfileActivity = new DataTable();
            DataTable adhochblActivity = new DataTable();
            DateTime startDate = Convert.ToDateTime(report.start_date).Date;
            DateTime endDate = Convert.ToDateTime(report.end_date).Date;
            const string ISTTimeZoneId = "India Standard Time";
            if(startDate == endDate)
            {
                endDate = endDate.AddDays(1);
            }
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
            string userId = _context.Users.Where(x => x.Id == userid && x.IsActive == true && x.IsDelete == false).FirstOrDefault().UserName;
            if (report.ReportType == "MainReport")
            {
                var filedata = _context.FileMaster.Where(x => x.EnterDate.Value.Date >= Convert.ToDateTime(startDate) && x.EnterDate.Value.Date <= Convert.ToDateTime(endDate))
                           .Include(fm => fm.Country)
                           .Include(fm => fm.HBLMasters)
                           .Include(fm => fm.FileActivityLogs)
                               .ThenInclude(fa => fa.Activity)
                           .Include(fm => fm.FileActivityLogs)
                               .ThenInclude(fa => fa.Status)
                           .Include(fm => fm.FileActivityLogs)
                               .ThenInclude(fa => fa.ApplicationUser)
                           .Select(fm => new FileDashModel
                           {
                               Id = fm.Id,
                               CountryName = fm.Country.CountryName,
                               FileNumber = fm.FileNumber,
                               ETD = fm.Etd,
                               DraftCutOff = fm.DraftCutoff,
                               CountofHBL = fm.HBLMasters.Count(),
                               ProcessedHBL = fm.HBLMasters
                               .Where(y => y.FileId == fm.Id)
                               .SelectMany(y => y.HBLActivityLogs.Select(log => log.HBLId))
                               .Distinct()
                               .Count(),
                               PendingHBL = (fm.HBLMasters.Count() - fm.HBLMasters
                               .Where(y => y.FileId == fm.Id)
                               .SelectMany(y => y.HBLActivityLogs.Select(log => log.HBLId))
                               .Distinct()
                               .Count()),
                               UserId = fm.FileActivityLogs.Where(y => y.Activity.NameOfActivity == "FileAllocation").Select(x => x.ApplicationUser.UserName).FirstOrDefault(),
                               StatusId = fm.FileActivityLogs.Where(y => y.Activity.NameOfActivity == "FileAllocation").Select(x => x.Status.Status).FirstOrDefault(),

                           }).ToList();


                filedata = filedata.Select(fm => new FileDashModel
                {
                    Id = fm.Id,
                    CountryName = fm.CountryName,
                    FileNumber = fm.FileNumber,
                    ETD = fm.ETD.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(fm.ETD.Value, TimeZoneInfo.FindSystemTimeZoneById(ISTTimeZoneId)) : (DateTime?)null,
                    DraftCutOff = fm.DraftCutOff.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(fm.DraftCutOff.Value, TimeZoneInfo.FindSystemTimeZoneById(ISTTimeZoneId)) : (DateTime?)null,
                    CountofHBL = fm.CountofHBL,
                    ProcessedHBL = fm.ProcessedHBL,
                    PendingHBL = fm.PendingHBL,
                    UserId = fm.UserId,
                    StatusId = fm.StatusId,

                }).ToList();

                var fileactivtydata = (from fa in _context.FileActivityLog
                                       join fm in _context.FileMaster
                                       on fa.FileId equals fm.Id
                                       where (fm.EnterDate.Value.Date >= Convert.ToDateTime(report.start_date).Date && fm.EnterDate.Value.Date <= Convert.ToDateTime(report.end_date).Date)
                                       join am in _context.ActivityMaster
                                       on fa.ActivityId equals am.Id
                                       join um in _context.Users
                                       on fa.UserId equals um.Id
                                       select new FileDashModel
                                       {
                                           CountryName = fm.Country.CountryName,
                                           DraftCutOff = fm.DraftCutoff,
                                           ETD = fm.Etd,
                                           FileNumber = fm.FileNumber,
                                           ActivityId = am.NameOfActivity,
                                           StatusId = fa.Status.Status,
                                           Comment = fa.Comment,
                                           UserId = um.UserName
                                       }).ToList();


                fileactivtydata = fileactivtydata.Select(x => new FileDashModel
                {
                    CountryName = x.CountryName,
                    DraftCutOff = x.DraftCutOff.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.DraftCutOff.Value, TimeZoneInfo.FindSystemTimeZoneById(ISTTimeZoneId)) : (DateTime?)null,
                    ETD = x.ETD.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.ETD.Value, TimeZoneInfo.FindSystemTimeZoneById(ISTTimeZoneId)) : (DateTime?)null,
                    FileNumber = x.FileNumber,
                    ActivityId = x.ActivityId,
                    StatusId = x.StatusId,
                    Comment = x.Comment,
                    UserId = x.UserId
                }).ToList();

                var HBLdata = (from ha in _context.HBLActivityLog
                               join hm in _context.HBLMaster
                               on ha.HBLId equals hm.Id
                               join fa in _context.FileMaster
                               on hm.FileId equals fa.Id
                               where (hm.EnterDate.Date >= Convert.ToDateTime(report.start_date).Date && hm.EnterDate.Date <= Convert.ToDateTime(report.end_date).Date)
                               join am in _context.ActivityMaster
                               on ha.ActivityId equals am.Id
                               join um in _context.Users
                               on ha.UserId equals um.Id
                               select new ReportTemplateModel
                               {
                                   CountryName = fa.Country.CountryName,
                                   FileNumber = fa.FileNumber,
                                   Container = hm.Container,
                                   BookingNo = hm.Booking,
                                   ETD = fa.Etd,
                                   HBL_No = hm.HBLNumber,
                                   ActivityId = am.NameOfActivity,
                                   StatusId = ha.Status.Status,
                                   Comment = ha.Comment,
                                   UserId = um.UserName,
                                   EnterDate = hm.EnterDate,
                                   StartDate = ha.StartDate,
                                   EndDate = ha.EndDate
                               }).ToList();

                HBLdata = HBLdata.Select(x => new ReportTemplateModel
                {
                    CountryName = x.CountryName,
                    FileNumber = x.FileNumber,
                    Container = x.Container,
                    BookingNo = x.BookingNo,
                    ETD = x.ETD.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.ETD.Value, TimeZoneInfo.FindSystemTimeZoneById(ISTTimeZoneId)) : (DateTime?)null,
                    HBL_No = x.HBL_No,
                    ActivityId = x.ActivityId,
                    StatusId = x.StatusId,
                    Comment = x.Comment,
                    UserId = x.UserId,
                    EnterDate = x.EnterDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.EnterDate.Value, TimeZoneInfo.FindSystemTimeZoneById(ISTTimeZoneId)) : (DateTime?)null,
                    StartDate = x.StartDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.StartDate.Value, TimeZoneInfo.FindSystemTimeZoneById(ISTTimeZoneId)) : (DateTime?)null,
                    EndDate = x.EndDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.EndDate.Value, TimeZoneInfo.FindSystemTimeZoneById(ISTTimeZoneId)) : (DateTime?)null,
                }).ToList();


                filedt = ToDataTable(filedata.Where(x => x.UserId == userid).ToList());
                fileactivity = ToDataTable(fileactivtydata.Where(x => x.UserId == userid).ToList());
                hbldt = ToDataTable(HBLdata);

            }
            else
            {
                var AdhocHBLactivitydata = (from ha in _context.AdhocHBLActivityLog
                                            join hm in _context.AdhocHBL
                                            on ha.AdhocHBLId equals hm.Id
                                            //where (hm.EnterDate>= Convert.ToDateTime(report.start_date) && hm.EnterDate <= Convert.ToDateTime(report.end_date))
                                            join am in _context.ActivityMaster
                                            on ha.ActivityId equals am.Id
                                            join um in _context.Users
                                            on ha.UserId equals um.Id
                                            join sm in _context.StatusMaster
                                            on ha.StatusId equals sm.Id
                                            join ca in _context.CountryMaster
                                            on hm.AdhocCountryId equals ca.Id
                                            select new AdhocReportModel
                                            {
                                                AdhocFileNumber = hm.AdhocFileNumber,
                                                AdhocContainer = hm.AdhocContainer,
                                                AdhocBooking = hm.AdhocBooking,
                                                AdhocHBLNumber = hm.AdhocHBLNumber,
                                                Activity = am.NameOfActivity,
                                                Status = sm.Status,
                                                Comment = ha.Comment,
                                                User = um.UserName,
                                                EnterDate = hm.EnterDate,
                                                StartDate = ha.StartDate,
                                                EndDate = ha.EndDate
                                            }).ToList();


                AdhocHBLactivitydata = AdhocHBLactivitydata.Select(x => new AdhocReportModel
                {
                    AdhocFileNumber = x.AdhocFileNumber,
                    AdhocContainer = x.AdhocContainer,
                    AdhocBooking = x.AdhocBooking,
                    AdhocHBLNumber = x.AdhocHBLNumber,
                    Activity = x.Activity,
                    Status = x.Status,
                    Comment = x.Comment,
                    User = x.User,
                    EnterDate = x.EnterDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.EnterDate.Value, TimeZoneInfo.FindSystemTimeZoneById(ISTTimeZoneId)) : (DateTime?)null,
                    StartDate = x.StartDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.StartDate.Value, TimeZoneInfo.FindSystemTimeZoneById(ISTTimeZoneId)) : (DateTime?)null,
                    EndDate = x.EndDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.EndDate.Value, TimeZoneInfo.FindSystemTimeZoneById(ISTTimeZoneId)) : (DateTime?)null,
                }).ToList();

                adhochblActivity = ToDataTable(AdhocHBLactivitydata.Where(x => x.User == userId).ToList());

                var fileactivitylog = _context.AdhocFileActivityLog.Include(x => x.Activity)
                                       .Include(x => x.Status)
                                       .Include(x => x.ApplicationUser)
                                       .Where(x => x.AdhocFile.EnterDate.Value.Date >= Convert.ToDateTime(report.start_date).Date && x.AdhocFile.EnterDate.Value.Date <= Convert.ToDateTime(report.end_date).Date)
                                       .Select(x => new AdhocFileActivityLog
                                       {
                                           AdhocFileId = x.AdhocFile.AdhocFileNumber,
                                           ActivityId = x.Activity.NameOfActivity,
                                           StatusId = x.Status.Status,
                                           UserId = x.ApplicationUser.UserName,
                                           Comment = x.Comment,
                                           StartDate = x.StartDate,
                                           EndDate = x.EndDate
                                       })
                                       .Where(x => x.UserId == userid)
                                       .ToList();

                fileactivitylog = fileactivitylog.Select(x => new AdhocFileActivityLog
                {
                    AdhocFileId = x.AdhocFileId,
                    ActivityId = x.ActivityId,
                    StatusId = x.StatusId,
                    UserId = x.StatusId,
                    Comment = x.Comment,
                    StartDate = x.StartDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.StartDate.Value, TimeZoneInfo.FindSystemTimeZoneById(ISTTimeZoneId)) : (DateTime?)null,
                    EndDate = x.EndDate.HasValue ? TimeZoneInfo.ConvertTimeFromUtc(x.EndDate.Value, TimeZoneInfo.FindSystemTimeZoneById(ISTTimeZoneId)) : (DateTime?)null,
                })
                                      .Where(x => x.UserId == userid)
                                      .ToList();


                adhocfileActivity = ToDataTable(fileactivitylog);
            }

            //saveFile.Filter = "Excel files (*.xlsx)|*.xlsx";
            //saveFile.Filter = "Excel files (*.xlsx)";
            string filename = "";
            //filename = saveFile.FileName;
            string apath = filename + ".xlsx";
            using (XLWorkbook wb = new XLWorkbook())
            {
                if (report.ReportType == "MainReport")
                {
                    filedt.TableName = "File Data";
                    fileactivity.TableName = "File Activity Data";
                    hbldt.TableName = "Hbl Activity Data";
                    var wsFileData = wb.Worksheets.Add(filedt);
                    var wsfileactivitydata = wb.Worksheets.Add(fileactivity);
                    var wsHblData = wb.Worksheets.Add(hbldt);
                }
                else
                {
                    adhochblActivity.TableName = "adhochblActivity";
                    adhocfileActivity.TableName = "adhocfileActivity";

                    var wsFileData = wb.Worksheets.Add(adhochblActivity);
                    var wsfileactivity = wb.Worksheets.Add(adhocfileActivity);

                }



                try
                {
                    using (MemoryStream stream = new MemoryStream())
                    {
                        wb.SaveAs(stream);
                        string excelname = $"UserReport-{DateTime.Now.ToString("ddmmyyyy hh:mm:ss")}.xlsx";
                        return File(stream.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", excelname);
                    }
                }
                catch (Exception ex)
                {

                }
            }
            return View();
        }


        //List convert into datatable
        public DataTable ToDataTable<T>(List<T> items)
        {
            DataTable dataTable = new DataTable(typeof(T).Name);
            //Get all the properties by using reflection   
            PropertyInfo[] Props = typeof(T).GetProperties(BindingFlags.Public | BindingFlags.Instance);
            foreach (PropertyInfo prop in Props)
            {
                //Setting column names as Property names  
                dataTable.Columns.Add(prop.Name);
            }
            foreach (T item in items)
            {
                var values = new object[Props.Length];
                for (int i = 0; i < Props.Length; i++)
                {

                    values[i] = Props[i].GetValue(item, null);
                }
                dataTable.Rows.Add(values);
            }

            return dataTable;
        }

        //Get hbl's data 
        [HttpPost]
        public IActionResult GetHBLs(string hblnumber, string bookingno, string filenumber)
        {
            int totalRecord = 0;
            int filterRecord = 0;
            int hblrecord = 0;
            var draw = Request.Form["draw"].FirstOrDefault();
            var sortColumn = Request.Form["columns[" + Request.Form["order[0][column]"].FirstOrDefault() + "][name]"].FirstOrDefault();
            var sortColumnDirection = Request.Form["order[0][dir]"].FirstOrDefault();
            var searchValue = Request.Form["search[value]"].FirstOrDefault();
            int pageSize = Convert.ToInt32(Request.Form["length"].FirstOrDefault() ?? "0");
            int skip = Convert.ToInt32(Request.Form["start"].FirstOrDefault() ?? "0");
            string key = "";
            string value = "";

            List<HBLUserViewModel> hBLDashModel = new List<HBLUserViewModel>();
            var data = _context.HBLMaster.Include(x => x.HBLActivityLogs).Include(x => x.File).ThenInclude(x => x.Country).Select(x => new HBLUserViewModel
            {
                Id = x.Id,
                CountryName = x.File.Country.CountryName,
                HBL_No = x.HBLNumber,
                Container = x.Container,
                BookingNo = x.Booking,
                CustomerName = x.CustomerName,
                FileNo = x.File.FileNumber
            }).ToList();

            //Sorting data
            IQueryable<HBLUserViewModel> SortedData = data.AsQueryable();

            if (!string.IsNullOrEmpty(hblnumber))
            {
                SortedData = SortedData.Where(x => x.HBL_No == hblnumber).AsQueryable();
            }
            if (!string.IsNullOrEmpty(bookingno))
            {
                SortedData = SortedData.Where(x => x.BookingNo == bookingno).AsQueryable();
            }
            if (!string.IsNullOrEmpty(filenumber))
            {
                SortedData = SortedData.Where(x => x.FileNo == filenumber).AsQueryable();
            }

            if (!string.IsNullOrEmpty(sortColumn) && !string.IsNullOrEmpty(sortColumnDirection))
            {
                SortedData = SortedData.OrderBy(sortColumn + " " + sortColumnDirection).AsQueryable();
            }

            var returnObj = new
            {
                draw = draw,
                recordsTotal = hBLDashModel.Count(),
                recordsFiltered = SortedData.Count(),
                data = SortedData.AsQueryable(),
            };

            return Json(returnObj);
        }
        public ActionResult GetCountofUser(DateTime? StartDate, DateTime? EndDate, string ActivityId)
        {
            List<UserDashboardViewModel> userdashboardModel = new List<UserDashboardViewModel>();
            ViewData["Activity"] = _context.ActivityMaster.Where(x => x.IsActive == true && x.IsDelete == false).OrderBy(x => x.Id).ToList();
            ViewData["User"] = _context.Users.Where(x => x.IsActive == true && x.IsDelete == false).OrderBy(x => x.CitrixId).ToList();
            ViewData["Status"] = _context.StatusMaster.Where(x => x.IsActive == true && x.IsDelete == false).OrderBy(x => x.Status).ToList();
            var userid = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
            var citrixId = _context.Users.Where(x => x.Id == userid && x.IsActive == true && x.IsDelete == false).Select(x => x.CitrixId).FirstOrDefault();
            var activityList = _context.ActivityMaster.Where(x => x.IsActive == true && x.IsDelete == false).OrderBy(x => x.Id).ToList();
            List<StatusMaster> _status = _context.StatusMaster.Where(x => x.IsActive == true && x.IsDelete == false).ToList();

            string completed = _status.Where(x => x.Status == "Completed" && x.IsActive == true && x.IsDelete == false).Select(x => x.Id).FirstOrDefault();
            string pending = _status.Where(x => x.Status == "Pending" && x.IsActive == true && x.IsDelete == false).Select(x => x.Id).FirstOrDefault();
            string query = _status.Where(x => x.Status == "Query" && x.IsActive == true && x.IsDelete == false).Select(x => x.Id).FirstOrDefault();
            string wip = _status.Where(x => x.Status == "WIP" && x.IsActive == true && x.IsDelete == false).Select(x => x.Id).FirstOrDefault();
            string followup1 = _status.Where(x => x.Status == "Followup1" && x.IsActive == true && x.IsDelete == false).Select(x => x.Id).FirstOrDefault();
            string followup2 = _status.Where(x => x.Status == "Processed by FO" && x.IsActive == true && x.IsDelete == false).Select(x => x.Id).FirstOrDefault();
            //string followup3 = _status.Where(x => x.Status == "Followup3").Select(x => x.Id).FirstOrDefault();
            if (StartDate != null && EndDate != null)
            {
                var data = _context.HBLActivityLog.Where(x => x.StartDate.Value.Date >= StartDate.Value.Date && x.StartDate.Value.Date <= EndDate.Value.Date && x.UserId == userid).Include(x => x.Hbl).GroupBy(x => new
                {
                    x.ApplicationUser.CitrixId,
                }).Select(x => new UserDashboardViewModel
                {
                    User = x.Key.CitrixId,
                    Count = x.Count(),
                }).ToList();

                foreach (UserDashboardViewModel dashboard in data.Where(x => x.User == citrixId))
                {
                    dashboard.HBLCount = _context.HBLActivityLog.Where(x => x.ApplicationUser.CitrixId == dashboard.User && x.StartDate.Value.Date >= StartDate.Value.Date && x.StartDate.Value.Date <= EndDate.Value.Date).Include(x => x.Hbl).Include(x => x.Activity)
                    .GroupBy(x =>
                    new
                    {
                        x.Activity.Id,
                        x.StatusId,
                    }).Select(x => new HBLCount
                    {
                        Count = x.Count(),
                        Status = x.Key.StatusId,
                        ActivityId = x.Key.Id,
                    }).ToList();

                    foreach (ActivityMaster activityMaster in activityList.Where(x => x.IsActive == true))
                    {
                        dashboard.Completed = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status.Contains(completed)).Sum(x => x.Count);
                        dashboard.Pending = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status.Contains(pending)).Sum(x => x.Count);
                        dashboard.Query = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status.Contains(query)).Sum(x => x.Count);
                        dashboard.WIP = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status.Contains(wip)).Sum(x => x.Count);
                        dashboard.Followup1 = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status.Contains(followup1)).Sum(x => x.Count);
                        dashboard.Followup2 = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status.Contains(followup2)).Sum(x => x.Count);
                        //dashboard.Followup3 = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status.Contains(followup3)).Sum(x => x.Count);


                        dashboard.HBLStatusCount.Add(new HBLStatusCount
                        {
                            Completed = dashboard.Completed,
                            Pending = dashboard.Pending + dashboard.Followup1 + dashboard.Followup2 + dashboard.Followup3,
                            Query = dashboard.Query,
                            WIP = dashboard.WIP
                        });

                        dashboard.TotalCompleted = dashboard.TotalCompleted + dashboard.Completed;
                        dashboard.TotalPending += dashboard.Pending;
                        dashboard.TotalQuery += dashboard.Query;
                        dashboard.TotalWIP += dashboard.WIP;
                    }
                }

                userdashboardModel.AddRange(data);
                return Json(userdashboardModel);
            }
            else
            {
                var data = _context.HBLActivityLog.Where(x => x.UserId == userid).Include(x => x.Hbl).GroupBy(x => new
                {
                    x.ApplicationUser.CitrixId,

                }).Select(x => new UserDashboardViewModel
                {
                    User = x.Key.CitrixId,
                    Count = x.Count()

                }).ToList();

                foreach (UserDashboardViewModel dashboard in data.Where(x => x.User == citrixId))
                {
                    dashboard.HBLCount = _context.HBLActivityLog.Where(x => x.ApplicationUser.CitrixId == dashboard.User).Include(x => x.Hbl).Include(x => x.Activity)
                    .GroupBy(x =>
                    new
                    {
                        x.ApplicationUser.CitrixId,
                        x.Activity.Id,
                        x.StatusId,
                    }).Select(x => new HBLCount
                    {
                        Count = x.Count(),
                        Status = x.Key.StatusId,
                        ActivityId = x.Key.Id,
                    }).ToList();

                    foreach (ActivityMaster activityMaster in activityList.Where(x => x.IsActive == true))
                    {
                        dashboard.Completed = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status.Contains(completed)).Sum(x => x.Count);
                        dashboard.Pending = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status.Contains(pending)).Sum(x => x.Count);
                        dashboard.Query = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status.Contains(query)).Sum(x => x.Count);
                        dashboard.WIP = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status.Contains(wip)).Sum(x => x.Count);
                        dashboard.Followup1 = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status.Contains(followup1)).Sum(x => x.Count);
                        dashboard.Followup2 = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status.Contains(followup2)).Sum(x => x.Count);
                        //dashboard.Followup3 = dashboard.HBLCount.Where(x => x.ActivityId == activityMaster.Id && x.Status.Contains(followup3)).Sum(x => x.Count);


                        dashboard.HBLStatusCount.Add(new HBLStatusCount
                        {
                            Completed = dashboard.Completed,
                            Pending = dashboard.Pending + dashboard.Followup1 + dashboard.Followup2 + dashboard.Followup3,
                            Query = dashboard.Query,
                            WIP = dashboard.WIP
                        });

                        dashboard.TotalCompleted = dashboard.TotalCompleted + dashboard.Completed;
                        dashboard.TotalPending += dashboard.Pending + dashboard.Followup1 + dashboard.Followup2 + dashboard.Followup3;
                        dashboard.TotalQuery += dashboard.Query;
                        dashboard.TotalWIP += dashboard.WIP;
                    }
                }

                userdashboardModel.AddRange(data);
            }
            return View(userdashboardModel);
        }

        //Report
        public ActionResult UserReport()
        {

            return View();
        }
        //Report Download
        [HttpPost]
        public ActionResult UserReport(ReportViewModel report)
        {
            var UserId = _httpContextAccessor.HttpContext.User.FindFirstValue(ClaimTypes.NameIdentifier);
            List<ReportTemplateModel> HBLdata = new List<ReportTemplateModel>();

            if (report.start_date.ToShortDateString() != "1/1/0001")
            {
                HBLdata = (from ha in _context.HBLActivityLog
                           where (ha.StartDate.Value.Date >= Convert.ToDateTime(report.start_date).Date && ha.StartDate.Value.Date <= Convert.ToDateTime(report.end_date).Date)
                           join hm in _context.HBLMaster
                           on ha.HBLId equals hm.Id
                           join fa in _context.FileMaster
                           on hm.FileId equals fa.Id
                           join am in _context.ActivityMaster
                           on ha.ActivityId equals am.Id
                           join um in _context.Users
                           on ha.UserId equals um.Id
                           where (um.Id == UserId)
                           select new ReportTemplateModel
                           {
                               CountryName = fa.Country.CountryName,
                               FileNumber = fa.FileNumber,
                               Container = hm.Container,
                               BookingNo = hm.Booking,
                               ETD = fa.Etd,
                               HBL_No = hm.HBLNumber,
                               ActivityId = am.NameOfActivity,
                               StatusId = ha.Status.Status,
                               Comment = ha.Comment,
                               UserId = um.UserName,
                               EnterDate = hm.EnterDate,
                               StartDate = ha.StartDate,
                               EndDate = ha.EndDate
                               //AES_UN = ha.AES_UN,
                               //QUOTE_NUMBER = ha.QUOTE_NUMBER,
                               //MblNumber = ha.MblNumber
                           }).ToList();
            }
            else
            {
                HBLdata = (from ha in _context.HBLActivityLog
                           join hm in _context.HBLMaster
                           on ha.HBLId equals hm.Id
                           join fa in _context.FileMaster
                           on hm.FileId equals fa.Id
                           join am in _context.ActivityMaster
                           on ha.ActivityId equals am.Id
                           join um in _context.Users
                           on ha.UserId equals um.Id
                           where (um.Id == UserId)
                           select new ReportTemplateModel
                           {
                               CountryName = fa.Country.CountryName,
                               FileNumber = fa.FileNumber,
                               Container = hm.Container,
                               BookingNo = hm.Booking,
                               ETD = fa.Etd,
                               HBL_No = hm.HBLNumber,
                               ActivityId = am.NameOfActivity,
                               StatusId = ha.Status.Status,
                               Comment = ha.Comment,
                               UserId = um.UserName,
                               EnterDate = hm.EnterDate,
                               StartDate = ha.StartDate,
                               EndDate = ha.EndDate
                               //AES_UN = ha.AES_UN,
                               //QUOTE_NUMBER = ha.QUOTE_NUMBER,
                               //MblNumber = ha.MblNumber
                           }).ToList();
            }

            DataTable hbldt = ToDataTable(HBLdata);

            //saveFile.Filter = "Excel files (*.xlsx)|*.xlsx";
            //saveFile.Filter = "Excel files (*.xlsx)";
            string filename = "";
            //filename = saveFile.FileName;
            string apath = filename + ".xlsx";
            using (XLWorkbook wb = new XLWorkbook())
            {
                var wsHblData = wb.Worksheets.Add(hbldt);

                try
                {
                    using (MemoryStream stream = new MemoryStream())
                    {
                        wb.SaveAs(stream);
                        string excelname = $"UserReport-{DateTime.Now.ToString("ddmmyyyy hh:mm:ss")}.xlsx";
                        return File(stream.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", excelname);
                    }

                    // System.Windows.Forms.MessageBox.Show("File Save Successfully.!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    // System.Windows.Forms.MessageBox.Show("Something went wrong.!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            return View();
        }
    }
}

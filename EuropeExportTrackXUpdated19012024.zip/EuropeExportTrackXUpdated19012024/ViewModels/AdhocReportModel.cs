﻿namespace EuropeTrackX.ViewModels
{
    public class AdhocReportModel
    {
        public string Id { get; set; }       
        public string? AdhocFileNumber { get; set; }
        public string? AdhocContainer { get; set; }
        public string? AdhocHBLNumber { get; set; }
        public string? AdhocBooking { get; set; }
        public DateTime? EnterDate { get; set; }   
        public string? Activity { get; set; }
        public string? Status { get; set; }
        public string? Comment { get; set; }
        public string? User { get; set; } = null!;
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public string ArrivedCBM { get; set; }
        public string BookingCBM { get; set; }
        public string ShippingType { get; set; }
    }
}

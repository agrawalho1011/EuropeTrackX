﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace EuropeTrackX.DataModel
{

    public partial class FileMaster
    {
        public string Id { get; set; } = Guid.NewGuid().ToString(); 

        public string CountryId { get; set; }

        public string FileNumber { get; set; } = null!;

        public DateTime? Etd { get; set; }

        public DateTime? DraftCutoff { get; set; }

        public DateTime? EnterDate { get; set; }

        
        public bool? IsActive { get; set; } = true;
        public bool IsDelete { get; set; } = false;
                
        [ForeignKey("CountryId")]
        public virtual CountryMaster Country { get; set; } = null!;

        public virtual ICollection<FileActivityLog> FileActivityLogs { get; } = new List<FileActivityLog>();

        public virtual ICollection<HBLMaster> HBLMasters { get; } = new List<HBLMaster>();
    }
}
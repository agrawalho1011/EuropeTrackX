﻿using EuropeTrackX.DataModel;

namespace EuropeTrackX.ViewModels
{
	public class UploadViewModel
	{
		public int CountryId { get; set; }
		public IFormFile File { get; set; }
	}
}

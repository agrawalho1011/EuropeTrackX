﻿using System;
using System.Collections.Generic;

namespace EuropeTrackX.DataModel
{

    public partial class HBLMaster
    {
        public string Id { get; set; } = Guid.NewGuid().ToString(); 

        public string HBLNumber { get; set; } = null!;

        public string FileId { get; set; }

        public string CustomerName { get; set; } = null!;

        public string Container { get; set; } = null!;

        public string Booking { get; set; } = null!;

        public DateTime EnterDate { get; set; }

        public bool? IsActive { get; set; } = true;
        public bool IsDelete { get; set; } = false;
        public virtual FileMaster File { get; set; } = null!;

        public virtual ICollection<HBLActivityLog> HBLActivityLogs { get; } = new List<HBLActivityLog>();
    }
}
﻿using DocumentFormat.OpenXml.Spreadsheet;

namespace EuropeTrackX.DataModel
{
    public class ResetPasswordViewModel
    {
        public IEnumerable<ApplicationUser> Users { get; set; }
        public string SelectedUserId { get; set; }
    }
}
